﻿$(document).ready(function () {
   
    $(function () {
        var values1 = $("#Data").val();
        
        if (values1 != undefined && values1 != "") {
            var obj = JSON.parse(values1);
            Highcharts.chart('graph', {
                chart: {
                    type: 'column'
                },
                title: {
                    text: 'Application Wise Data'
                },
                subtitle: {
                    text: 'Source: Amdocs'
                },
                xAxis: {
                    categories: [
                       'ADM',
                       'SOM',
                       'GiTech',
                       'PSG'
                    ],
                    crosshair: true
                },
                yAxis: {
                    min:30,
                    max:1500,
                    title: {
                        text: 'Numbers'
                    }
                },
                tooltip: {
                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                        '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
                },
                plotOptions: {
                    column: {
                        pointPadding: 0.5,
                        borderWidth: 2
                    }
                },
                series: getseries(obj)
            });
            
        }
            
        
    });







    

    function getseries(obj) {
        var series = [];
        var i = 0;
        for (var key in obj) {

            if (key != "CC_Desc") {
                var tempseries = {
                    name: key,
                    data: strSplit(obj[key])
                }
                series.push(tempseries);
            }
        }


        console.log(series);
        return series;
    }

    function strSplit(str) {
        str = str.toString();
        var strArr = str.split(',');
        var intArr = [];
        for (var i = 0; i < strArr.length; i++) {
            str1 = strArr[i].replace("[", "");
            str1 = str1.replace("]", "");
            intArr.push(parseFloat(str1));
        }
        return intArr;
    }


});


