﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            lblErrorMsg.Text = string.Empty;
            
            StringBuilder sbErrorMessages = new StringBuilder();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            if (username == string.Empty || password == string.Empty)
                sbErrorMessages.Append("Username or Password cannot be null");
            if (username != string.Empty && password != string.Empty)
            {
                if ((username == "Test") && (password == "123"))
                {

                    Session["id"] = txtUsername.Text;
                    Response.Redirect("Upload.aspx");
                    Session.RemoveAll();
                }


                else
                {
                    sbErrorMessages.Append("The password does not match with the username");
                }
                
               
            }
            //Session.Add("UserDetails", loginDetails);

            lblErrorMsg.Text = sbErrorMessages.ToString();
            lblErrorMsg.CssClass = "error";
            lblErrorMsg.Visible = true;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            lblErrorMsg.Text = "";
        }
    }
}