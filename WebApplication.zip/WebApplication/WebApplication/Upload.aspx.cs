﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication
{
    public partial class Upload : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["id"] != null)
            {

            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Default.aspx");
        }

        protected void UploadBtn_Click(object sender, EventArgs e)
        {

            string folderPath = Server.MapPath("~/Files/");
            if (FileUpLoad1.HasFile)
            {
                string ext = Path.GetExtension(FileUpLoad1.FileName);
                if (ext == ".xlx" || ext == ".xlsx" || ext == ".XLX" || ext == ".XLSX")
                {


                    //Check whether Directory (Folder) exists.
                    if (!Directory.Exists(folderPath))
                    {
                        //If Directory (Folder) does not exists. Create it.
                        Directory.CreateDirectory(folderPath);
                    }

                    //Save the File to the Directory (Folder).
                    string filePath = folderPath + Path.GetFileName(FileUpLoad1.FileName);
                    FileUpLoad1.SaveAs(filePath);
                    ReadExcel(filePath);
                    //Display the success message.
                    lblMessage.Text = Path.GetFileName(FileUpLoad1.FileName) + " has been uploaded.";

                }
                else
                {
                    lblMessage.Text = Path.GetFileName(FileUpLoad1.FileName) + " has not been excel file.";
                }
            }
            else
            {
                lblMessage.Text = "No File Uploaded.";
            }

        }

        protected void ReadExcel(string filepath)
        {
            
            using (SpreadsheetDocument doc = SpreadsheetDocument.Open(filepath, false))
            {
                WorkbookPart wbPart = doc.WorkbookPart;

                //statement to get the count of the worksheet  
                int worksheetcount = doc.WorkbookPart.Workbook.Sheets.Count();
                //Array of datatable
                DataTable[] dt = new DataTable[worksheetcount];
                //Read the first Sheet from Excel file.
                Sheets sheetCollection = wbPart.Workbook.GetFirstChild<Sheets>();
                //Datatable count
                int count = 0;
                foreach (Sheet sheet in sheetCollection)
                {
                    //Get the Worksheet instance.
                    Worksheet worksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;

                    //Fetch all the rows present in the Worksheet.
                    IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Descendants<Row>();

                    //Create a new DataTable.
                    dt[count] = new DataTable();

                    //Loop through the Worksheet rows.
                    foreach (Row row in rows)
                    {
                        //Use the first row to add columns to DataTable.
                        if (row.RowIndex.Value == 1)
                        {
                            foreach (Cell cell in row.Descendants<Cell>())
                            {
                                string column = GetValue(doc, cell).Replace('\'', '_');
                                column = column.Replace(' ', '_');
                                dt[count].Columns.Add(column);
                            }
                        }
                        else
                        {
                            //Add rows to DataTable.
                            dt[count].Rows.Add();
                            int i = 0;
                            foreach (Cell cell in row.Descendants<Cell>())
                            {
                                dt[count].Rows[dt[count].Rows.Count - 1][i] = GetValue(doc, cell);
                                i++;
                            }
                        }
                    }
                    count++;
                }
                //store value of datatale in view state
                GridView1.DataSource= ViewState["Grid1"] = dt[0];
               GridView2.DataSource=ViewState["Grid2"] = dt[1];
               GridView1.DataBind();
               GridView2.DataBind();
               BindGrid3();
            }

        }


        private string GetValue(SpreadsheetDocument doc, Cell cell)
        {
            string value = cell.CellValue.InnerText;
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return doc.WorkbookPart.SharedStringTablePart.SharedStringTable.ChildElements.GetItem(int.Parse(value)).InnerText;
            }
            return value;
        }

        protected void GridView1_RowCancelingEdit(  object sender, GridViewCancelEditEventArgs e)
        {

            GridView1.EditIndex = -1;
            gvbind1();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            gvbind1();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Label lbl_ID = (Label)GridView1.Rows[e.RowIndex].FindControl("lbl_ID");
            TextBox txt_oct_15 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_Oct_15");
            TextBox txt_Nov_15 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_Nov_15");
            TextBox txt_YTD_Nov_15 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_Nov_15");
            TextBox txt_Dec_15 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_Dec_15");
            TextBox txt_YTD_Q1_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_Q1_16");
            TextBox txt_Jan_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_Jan_16");
            TextBox txt_YTD_Jan_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_Jan_16");
            TextBox txt_Feb_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_Feb_16");
            TextBox txt_YTD_Feb_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_Feb_16");
            TextBox txt_Mar_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_Mar_16");
            TextBox txt_YTD_Q2_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_Q2_16");
            TextBox txt_Apr_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_Apr_16");
            TextBox txt_YTD_Apr_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_Apr_16");
            TextBox txt_May_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_May_16");
            TextBox txt_YTD_May_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_May_16");
            TextBox txt_June_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_June_16");
            TextBox txt_YTD_Q3_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_Q3_16");
            TextBox txt_July_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_July_16");
            TextBox txt_YTD_July_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_July_16");
            TextBox txt_Aug_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_Aug_16");
            TextBox txt_YTD_Aug_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_YTD_Aug_16");
            TextBox txt_Sep_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_Sep_16");
            TextBox txt_FY_16 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txt_FY_16");
            DataTable dttemp = new DataTable();
            dttemp.Columns.Add("CC_Desc");
            dttemp.Columns.Add("Oct_15");
            dttemp.Columns.Add("Nov_15");
            dttemp.Columns.Add("YTD_Nov_15");
            dttemp.Columns.Add("Dec_15");
            dttemp.Columns.Add("YTD_Q1_16");
            dttemp.Columns.Add("Jan_16");
            dttemp.Columns.Add("YTD_Jan_16");
            dttemp.Columns.Add("Feb_16");
            dttemp.Columns.Add("YTD_Feb_16");
            dttemp.Columns.Add("Mar_16");
            dttemp.Columns.Add("YTD_Q2_16");
            dttemp.Columns.Add("Apr_16");
            dttemp.Columns.Add("YTD_Apr_16");
            dttemp.Columns.Add("May_16");
            dttemp.Columns.Add("YTD_May_16");
            dttemp.Columns.Add("June_16");
            dttemp.Columns.Add("YTD_Q3_16");
            dttemp.Columns.Add("July_16");
            dttemp.Columns.Add("YTD_July_16");
            dttemp.Columns.Add("Aug_16");
            dttemp.Columns.Add("YTD_Aug_16");
            dttemp.Columns.Add("Sep_16");
            dttemp.Columns.Add("FY_16");
            DataRow r = dttemp.NewRow();
            r[0] = lbl_ID.Text;
            r[1] = txt_oct_15.Text;
            r[2] = txt_Nov_15.Text;
            r[3] = txt_YTD_Nov_15.Text;
            r[4] = txt_Dec_15.Text;
            r[5] = txt_YTD_Q1_16.Text;
            r[6] = txt_Jan_16.Text;
            r[7] = txt_YTD_Jan_16.Text;
            r[8] = txt_Feb_16.Text;
            r[9] = txt_YTD_Feb_16.Text;
            r[10] = txt_Mar_16.Text;
            r[11] = txt_YTD_Q2_16.Text;
            r[12] = txt_Apr_16.Text;
            r[13] = txt_YTD_Apr_16.Text;
            r[14] = txt_May_16.Text;
            r[15] = txt_YTD_May_16.Text;
            r[16] = txt_June_16.Text;
            r[17] = txt_YTD_Q3_16.Text;
            r[18] = txt_July_16.Text;
            r[19] = txt_YTD_July_16.Text;
            r[20] = txt_Aug_16.Text;
            r[21] = txt_YTD_Aug_16.Text;
            r[22] = txt_Sep_16.Text;
            r[23] = txt_FY_16.Text;
            dttemp.Rows.Add(r);
            DataTable dtloop = (DataTable)ViewState["Grid1"];

            for (int i = 0; i < dttemp.Rows.Count; i++)
            {
                for (int j = 0; j< dtloop.Rows.Count; j++)
                {
                    if (Convert.ToString(dttemp.Rows[i]["CC_Desc"]) == Convert.ToString(dtloop.Rows[j]["CC_Desc"]))
                    {
                        dtloop.Rows[i]["CC_Desc"] = Convert.ToString(dttemp.Rows[j]["CC_Desc"]);
                        dtloop.Rows[i]["Oct_15"] = Convert.ToDecimal(dttemp.Rows[j]["Oct_15"]);
                        dtloop.Rows[i]["Nov_15"] = Convert.ToDecimal(dttemp.Rows[j]["Nov_15"]);
                        dtloop.Rows[i]["YTD_Nov_15"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Nov_15"]);
                        dtloop.Rows[i]["Dec_15"] = Convert.ToDecimal(dttemp.Rows[j]["Dec_15"]);
                        dtloop.Rows[i]["YTD_Q1_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Q1_16"]);
                        dtloop.Rows[i]["Jan_16"] = Convert.ToDecimal(dttemp.Rows[j]["Jan_16"]);
                        dtloop.Rows[i]["YTD_Jan_16"] = Convert.ToDecimal(dttemp.Rows[i]["YTD_Jan_16"]);
                        dtloop.Rows[i]["Feb_16"] = Convert.ToDecimal(dttemp.Rows[j]["Feb_16"]);
                        dtloop.Rows[i]["YTD_Feb_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Feb_16"]);
                        dtloop.Rows[i]["Mar_16"] = Convert.ToDecimal(dttemp.Rows[j]["Mar_16"]);
                        dtloop.Rows[i]["YTD_Q2_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Q2_16"]);
                        dtloop.Rows[i]["Apr_16"] = Convert.ToDecimal(dttemp.Rows[j]["Apr_16"]);
                        dtloop.Rows[i]["YTD_Apr_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Apr_16"]);
                        dtloop.Rows[i]["May_16"] = Convert.ToDecimal(dttemp.Rows[j]["May_16"]);
                        dtloop.Rows[i]["YTD_May_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_May_16"]);
                        dtloop.Rows[i]["June_16"] = Convert.ToDecimal(dttemp.Rows[j]["June_16"]);
                        dtloop.Rows[i]["YTD_Q3_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Q3_16"]);
                        dtloop.Rows[i]["July_16"] = Convert.ToDecimal(dttemp.Rows[j]["July_16"]);
                        dtloop.Rows[i]["YTD_July_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_July_16"]);
                        dtloop.Rows[i]["Aug_16"] = Convert.ToDecimal(dttemp.Rows[j]["Aug_16"]);
                        dtloop.Rows[i]["YTD_Aug_16"] = Convert.ToDecimal(dttemp.Rows[i]["YTD_Aug_16"]);
                        dtloop.Rows[i]["Sep_16"] = Convert.ToDecimal(dttemp.Rows[j]["Sep_16"]);
                        dtloop.Rows[i]["FY_16"] = Convert.ToDecimal(dttemp.Rows[j]["FY_16"]);

                    }
                }
            }
            e.Cancel = true;
            GridView1.EditIndex = -1;
            GridView1.DataSource = dtloop;
            GridView1.DataBind();
            ViewState["Grid1"] = dtloop;
            BindGrid3();
        }

        protected void gvbind1()
        {
            GridView1.DataSource = ViewState["Grid1"];
           
            GridView1.DataBind();
        }

        protected void gvbind2()
        {
            GridView2.DataSource = ViewState["Grid2"];

            GridView2.DataBind();
        }

        protected void GridView1_RowDataBound(  object sender, GridViewRowEventArgs e)
        {

           
        }

        protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void GridView2_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView2.EditIndex = -1;
            gvbind2();

        }

        protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView2.EditIndex = e.NewEditIndex;
            gvbind2();
        }

        protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Label lbl_ID = (Label)GridView2.Rows[e.RowIndex].FindControl("lbl_ID");
            TextBox txt_oct_15 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_Oct_15");
            TextBox txt_Nov_15 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_Nov_15");
            TextBox txt_YTD_Nov_15 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_Nov_15");
            TextBox txt_Dec_15 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_Dec_15");
            TextBox txt_YTD_Q1_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_Q1_16");
            TextBox txt_Jan_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_Jan_16");
            TextBox txt_YTD_ian_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_Jan_16");
            TextBox txt_Feb_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_Feb_16");
            TextBox txt_YTD_Feb_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_Feb_16");
            TextBox txt_Mar_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_Mar_16");
            TextBox txt_YTD_Q2_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_Q2_16");
            TextBox txt_Apr_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_Apr_16");
            TextBox txt_YTD_Apr_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_Apr_16");
            TextBox txt_May_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_May_16");
            TextBox txt_YTD_May_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_May_16");
            TextBox txt_June_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_June_16");
            TextBox txt_YTD_Q3_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_Q3_16");
            TextBox txt_July_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_July_16");
            TextBox txt_YTD_July_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_July_16");
            TextBox txt_Aug_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_Aug_16");
            TextBox txt_YTD_Aug_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_YTD_Aug_16");
            TextBox txt_Sep_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_Sep_16");
            TextBox txt_FY_16 = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txt_FY_16");
            DataTable dttemp = new DataTable();
            dttemp.Columns.Add("CC_Desc");
            dttemp.Columns.Add("Oct_15");
            dttemp.Columns.Add("Nov_15");
            dttemp.Columns.Add("YTD_Nov_15");
            dttemp.Columns.Add("Dec_15");
            dttemp.Columns.Add("YTD_Q1_16");
            dttemp.Columns.Add("Jan_16");
            dttemp.Columns.Add("YTD_Jan_16");
            dttemp.Columns.Add("Feb_16");
            dttemp.Columns.Add("YTD_Feb_16");
            dttemp.Columns.Add("Mar_16");
            dttemp.Columns.Add("YTD_Q2_16");
            dttemp.Columns.Add("Apr_16");
            dttemp.Columns.Add("YTD_Apr_16");
            dttemp.Columns.Add("May_16");
            dttemp.Columns.Add("YTD_May_16");
            dttemp.Columns.Add("June_16");
            dttemp.Columns.Add("YTD_Q3_16");
            dttemp.Columns.Add("July_16");
            dttemp.Columns.Add("YTD_July_16");
            dttemp.Columns.Add("Aug_16");
            dttemp.Columns.Add("YTD_Aug_16");
            dttemp.Columns.Add("Sep_16");
            dttemp.Columns.Add("FY_16");
            DataRow r = dttemp.NewRow();
            r[0] = lbl_ID.Text;
            r[1] = txt_oct_15.Text;
            r[2] = txt_Nov_15.Text;
            r[3] = txt_YTD_Nov_15.Text;
            r[4] = txt_Dec_15.Text;
            r[5] = txt_YTD_Q1_16.Text;
            r[6] = txt_Jan_16.Text;
            r[7] = txt_YTD_ian_16.Text;
            r[8] = txt_Feb_16.Text;
            r[9] = txt_YTD_Feb_16.Text;
            r[10] = txt_Mar_16.Text;
            r[11] = txt_YTD_Q2_16.Text;
            r[12] = txt_Apr_16.Text;
            r[13] = txt_YTD_Apr_16.Text;
            r[14] = txt_May_16.Text;
            r[15] = txt_YTD_May_16.Text;
            r[16] = txt_June_16.Text;
            r[17] = txt_YTD_Q3_16.Text;
            r[18] = txt_July_16.Text;
            r[19] = txt_YTD_July_16.Text;
            r[20] = txt_Aug_16.Text;
            r[21] = txt_YTD_Aug_16.Text;
            r[22] = txt_Sep_16.Text;
            r[23] = txt_FY_16.Text;
            dttemp.Rows.Add(r);
            DataTable dtloop = (DataTable)ViewState["Grid2"];

            for (int i = 0; i < dttemp.Rows.Count; i++)
            {
                for (int j = 0; j < dtloop.Rows.Count; j++)
                {
                    if (Convert.ToString(dttemp.Rows[i]["CC_Desc"]) == Convert.ToString(dtloop.Rows[j]["CC_Desc"]))
                    {
                       
                        dtloop.Rows[i]["CC_Desc"] = Convert.ToString(dttemp.Rows[j]["CC_Desc"]);
                        dtloop.Rows[i]["Oct_15"] = Convert.ToDecimal(dttemp.Rows[j]["Oct_15"]);
                        dtloop.Rows[i]["Nov_15"] = Convert.ToDecimal(dttemp.Rows[j]["Nov_15"]);
                        dtloop.Rows[i]["YTD_Nov_15"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Nov_15"]);
                        dtloop.Rows[i]["Dec_15"] = Convert.ToDecimal(dttemp.Rows[j]["Dec_15"]);
                        dtloop.Rows[i]["YTD_Q1_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Q1_16"]);
                        dtloop.Rows[i]["Jan_16"] = Convert.ToDecimal(dttemp.Rows[j]["Jan_16"]);
                        dtloop.Rows[i]["YTD_Jan_16"] = Convert.ToDecimal(dttemp.Rows[i]["YTD_Jan_16"]);
                        dtloop.Rows[i]["Feb_16"] = Convert.ToDecimal(dttemp.Rows[j]["Feb_16"]);
                        dtloop.Rows[i]["YTD_Feb_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Feb_16"]);
                        dtloop.Rows[i]["Mar_16"] = Convert.ToDecimal(dttemp.Rows[j]["Mar_16"]);
                        dtloop.Rows[i]["YTD_Q2_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Q2_16"]);
                        dtloop.Rows[i]["Apr_16"] = Convert.ToDecimal(dttemp.Rows[j]["Apr_16"]);
                        dtloop.Rows[i]["YTD_Apr_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Apr_16"]);
                        dtloop.Rows[i]["May_16"] = Convert.ToDecimal(dttemp.Rows[j]["May_16"]);
                        dtloop.Rows[i]["YTD_May_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_May_16"]);
                        dtloop.Rows[i]["June_16"] = Convert.ToDecimal(dttemp.Rows[j]["June_16"]);
                        dtloop.Rows[i]["YTD_Q3_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_Q3_16"]);
                        dtloop.Rows[i]["July_16"] = Convert.ToDecimal(dttemp.Rows[j]["July_16"]);
                        dtloop.Rows[i]["YTD_July_16"] = Convert.ToDecimal(dttemp.Rows[j]["YTD_July_16"]);
                        dtloop.Rows[i]["Aug_16"] = Convert.ToDecimal(dttemp.Rows[j]["Aug_16"]);
                        dtloop.Rows[i]["YTD_Aug_16"] = Convert.ToDecimal(dttemp.Rows[i]["YTD_Aug_16"]);
                        dtloop.Rows[i]["Sep_16"] = Convert.ToDecimal(dttemp.Rows[j]["Sep_16"]);
                        dtloop.Rows[i]["FY_16"] = Convert.ToDecimal(dttemp.Rows[j]["FY_16"]);
                        
                    }
                }
            }
            e.Cancel = true;
            GridView2.EditIndex = -1;
            GridView2.DataSource = dtloop;
            GridView2.DataBind();
            ViewState["Grid2"] = dtloop;
            BindGrid3();

        }

        protected void BindGrid3()
        {
            DataTable dt1 = (DataTable) ViewState["Grid1"];
            DataTable dt2 = (DataTable)ViewState["Grid2"];
            DataTable dttemp = new DataTable();
            dttemp.Columns.Add("CC_Desc");
            dttemp.Columns.Add("Oct_15");
            dttemp.Columns.Add("Nov_15");
            dttemp.Columns.Add("YTD_Nov_15");
            dttemp.Columns.Add("Dec_15");
            dttemp.Columns.Add("YTD_Q1_16");
            dttemp.Columns.Add("Jan_16");
            dttemp.Columns.Add("YTD_Jan_16");
            dttemp.Columns.Add("Feb_16");
            dttemp.Columns.Add("YTD_Feb_16");
            dttemp.Columns.Add("Mar_16");
            dttemp.Columns.Add("YTD_Q2_16");
            dttemp.Columns.Add("Apr_16");
            dttemp.Columns.Add("YTD_Apr_16");
            dttemp.Columns.Add("May_16");
            dttemp.Columns.Add("YTD_May_16");
            dttemp.Columns.Add("June_16");
            dttemp.Columns.Add("YTD_Q3_16");
            dttemp.Columns.Add("July_16");
            dttemp.Columns.Add("YTD_July_16");
            dttemp.Columns.Add("Aug_16");
            dttemp.Columns.Add("YTD_Aug_16");
            dttemp.Columns.Add("Sep_16");
            dttemp.Columns.Add("FY_16");

            for(int i=0; i<dt1.Rows.Count;i++)
            {
                if (Convert.ToString(dt1.Rows[i]["CC_Desc"]) == Convert.ToString(dt2.Rows[i]["CC_Desc"]))
                {
                    DataRow r = dttemp.NewRow();
                    r["CC_Desc"] = Convert.ToString(dt1.Rows[i]["CC_Desc"]);
                    r["Oct_15"] = Convert.ToDecimal(dt1.Rows[i]["Oct_15"]) + Convert.ToDecimal(dt2.Rows[i]["Oct_15"]);
                    r["Nov_15"] = Convert.ToDecimal(dt1.Rows[i]["Nov_15"]) + Convert.ToDecimal(dt2.Rows[i]["Nov_15"]);
                    r["YTD_Nov_15"] = Convert.ToDecimal(dt1.Rows[i]["YTD_Nov_15"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_Nov_15"]);
                    r["Dec_15"] = Convert.ToDecimal(dt1.Rows[i]["Dec_15"]) + Convert.ToDecimal(dt2.Rows[i]["Dec_15"]);
                    r["YTD_Q1_16"] = Convert.ToDecimal(dt1.Rows[i]["YTD_Q1_16"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_Q1_16"]);
                    r["Jan_16"] = Convert.ToDecimal(dt1.Rows[i]["Jan_16"]) + Convert.ToDecimal(dt2.Rows[i]["Jan_16"]);
                    r["YTD_Jan_16"] = Convert.ToDecimal(dt1.Rows[i]["YTD_Jan_16"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_Jan_16"]);
                    r["Feb_16"] = Convert.ToDecimal(dt1.Rows[i]["Feb_16"]) + Convert.ToDecimal(dt2.Rows[i]["Feb_16"]);
                    r["YTD_Feb_16"] = Convert.ToDecimal(dt1.Rows[i]["YTD_Feb_16"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_Feb_16"]);
                    r["Mar_16"] = Convert.ToDecimal(dt1.Rows[i]["Mar_16"]) + Convert.ToDecimal(dt2.Rows[i]["Mar_16"]);
                    r["YTD_Q2_16"] = Convert.ToDecimal(dt1.Rows[i]["YTD_Q2_16"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_Q2_16"]);
                    r["Apr_16"] = Convert.ToDecimal(dt1.Rows[i]["Apr_16"]) + Convert.ToDecimal(dt2.Rows[i]["Apr_16"]);

                    r["YTD_Apr_16"] = Convert.ToDecimal(dt1.Rows[i]["YTD_Apr_16"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_Apr_16"]);
                    r["May_16"] = Convert.ToDecimal(dt1.Rows[i]["May_16"]) + Convert.ToDecimal(dt2.Rows[i]["May_16"]);
                    r["YTD_May_16"] = Convert.ToDecimal(dt1.Rows[i]["YTD_May_16"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_May_16"]);
                    r["June_16"] = Convert.ToDecimal(dt1.Rows[i]["June_16"]) + Convert.ToDecimal(dt2.Rows[i]["June_16"]);
                    r["YTD_Q3_16"] = Convert.ToDecimal(dt1.Rows[i]["YTD_Q3_16"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_Q3_16"]);
                    r["July_16"] = Convert.ToDecimal(dt1.Rows[i]["July_16"]) + Convert.ToDecimal(dt2.Rows[i]["July_16"]);
                    r["YTD_July_16"] = Convert.ToDecimal(dt1.Rows[i]["YTD_July_16"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_July_16"]);
                    r["Aug_16"] = Convert.ToDecimal(dt1.Rows[i]["Aug_16"]) + Convert.ToDecimal(dt2.Rows[i]["Aug_16"]);
                    r["YTD_Aug_16"] = Convert.ToDecimal(dt1.Rows[i]["YTD_Aug_16"]) + Convert.ToDecimal(dt2.Rows[i]["YTD_Aug_16"]);
                    r["Sep_16"] = Convert.ToDecimal(dt1.Rows[i]["Sep_16"]) + Convert.ToDecimal(dt2.Rows[i]["Sep_16"]);
                    r["FY_16"] = Convert.ToDecimal(dt1.Rows[i]["FY_16"]) + Convert.ToDecimal(dt2.Rows[i]["FY_16"]);
                    dttemp.Rows.Add(r);
                }
            }

            GridView3.DataSource = dttemp;
            GridView3.DataBind();
           
            
        }

       
 
    }
}