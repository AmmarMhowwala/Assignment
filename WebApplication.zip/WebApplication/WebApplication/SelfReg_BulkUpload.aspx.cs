﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;



public partial class Default4 : System.Web.UI.Page
{
    ITSecurity ITSec = new ITSecurity();
    string strIsProduction = ConfigurationManager.AppSettings["IsProduction"].ToString();
    Object oMissing = System.Reflection.Missing.Value;

    protected void Page_Load(object sender, EventArgs e)
    {
        //string loginID = string.Empty;
        //if (Session["UniqueID"] != null)
        //{
        //    loginID = Session["UniqueID"].ToString();
        //}
        DataSet dsperiod = new DataSet();
        int cntcheck = 0;
        dsperiod = ITSec.GetLatestPeriod();
        if (dsperiod != null && dsperiod.Tables[0].Rows.Count > 0)
        {
            cntcheck = ITSec.UID_Check_Self_ON_OFF(dsperiod.Tables[0].Rows[0][0].ToString());
        }
        if (cntcheck != 0)
        {
            divUpload.Visible = true;
            divMsg.Visible = false;
        }
        else
        {
            divMsg.Visible = true;
            divUpload.Visible = false;
        }
        if (!IsPostBack)
        {
            btnConfirm.Attributes.Add("OnClick", "javascript:return validateCheckBoxes();");
        }

    }
    protected void IbtnUpload_Click(object sender, EventArgs e)
    {
        gvSelfBulk.EditIndex = -1;
        btnConfirm.Enabled = true;
        ExcelUpload();
    }
    protected void gvSelfBulk_OnRowEditing(object sender, GridViewEditEventArgs e)
    {

        Label lblCircle = gvSelfBulk.Rows[e.NewEditIndex].FindControl("lblCircle") as Label;
        Label lblPOIType = gvSelfBulk.Rows[e.NewEditIndex].FindControl("lblPOIType") as Label;
        gvSelfBulk.EditIndex = e.NewEditIndex;
        gvSelfBulk.DataSource = (DataTable)ViewState["GridData"];
        gvSelfBulk.DataBind();
        DropDownList ddlCircle = gvSelfBulk.Rows[e.NewEditIndex].FindControl("ddlCircle") as DropDownList;
        DropDownList ddlPOIType = gvSelfBulk.Rows[e.NewEditIndex].FindControl("ddlPoiType") as DropDownList;
        ddlCircle.SelectedValue = lblCircle.Text;
        ddlPOIType.SelectedValue = lblPOIType.Text;
        btnConfirm.Enabled = false;
    }
    protected void gvSelfBulk_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvSelfBulk.EditIndex = -1;
        btnConfirm.Enabled = true;
        gvSelfBulk.DataSource = (DataTable)ViewState["GridData"];
        gvSelfBulk.DataBind();
    }
    protected void gvSelfBulk_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        DropDownList ddlUserSubType = (DropDownList)gvSelfBulk.Rows[e.RowIndex].FindControl("ddlUserSubType");
        TextBox txtFirstName = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtFirstName");
        TextBox txtLastName = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtLastName");
        // TextBox txtFullName = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtFullName");
        TextBox txtLocation = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtLocation");
        DropDownList txtCircle = (DropDownList)gvSelfBulk.Rows[e.RowIndex].FindControl("ddlCircle");
        DropDownList ddlGender = (DropDownList)gvSelfBulk.Rows[e.RowIndex].FindControl("ddlGender");
        TextBox txtMobileNo = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtMobileNo");
        TextBox txtEmailID = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtEmailID");
        TextBox txtDesignation = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtDesignation");
        TextBox txtOrgaName = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtOrgaName");
        TextBox txtVodaDoID = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtVodaDoID");
        TextBox txtEmpOrgID = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtEmpOrgID");
        TextBox txtStreet = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtStreet");
        TextBox txtCity = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtCity");
        TextBox txtState = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtState");
        TextBox txtPostalCode = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtPostalCode");
        TextBox txtCountry = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtCountry");
        TextBox txtCountryCode = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtCountryCode");
        DropDownList txtPOIType = (DropDownList)gvSelfBulk.Rows[e.RowIndex].FindControl("ddlPoiType");
        TextBox txtPOIValue = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtPOIValue");
        DropDownList ddlPhysicalAccess = (DropDownList)gvSelfBulk.Rows[e.RowIndex].FindControl("ddlPhysicalAccess");
        DropDownList ddlWoked = (DropDownList)gvSelfBulk.Rows[e.RowIndex].FindControl("ddlWoked");
        TextBox txtReviewer = (TextBox)gvSelfBulk.Rows[e.RowIndex].FindControl("txtReviewer");
        HiddenField rownum = (HiddenField)gvSelfBulk.Rows[e.RowIndex].FindControl("Psponsor");
        Label errormsg = (Label)gvSelfBulk.Rows[e.RowIndex].FindControl("lblErrorMsg");

        if (ddlUserSubType.SelectedValue.ToString() == "Select")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Please Select user Subtype');</script>");
            return;
        }

        if (txtCircle.SelectedValue.ToString() == "Select")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Please Select Circle');</script>");
            return;
        }

        if (ddlGender.SelectedValue.ToString() == "Select")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Please Select Gender');</script>");
            return;
        }

        if (txtPOIType.SelectedValue.ToString() == "Select")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Please Select POI Type');</script>");
            return;
        }
        if (ddlPhysicalAccess.SelectedValue.ToString() == "Select")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Please Select Physical Access');</script>");
            return;
        }

        if (ddlWoked.SelectedValue.ToString() == "Select")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Please Select Employee worked with VF');</script>");
            return;
        }


        btnConfirm.Enabled = true;
        DataTable dtloop = (DataTable)ViewState["GridData"];
        DataTable dt = new DataTable();
        dt.Columns.Add("USERSUBTYPE");
        dt.Columns.Add("FIRSTNAME");
        dt.Columns.Add("LASTNAME");
        dt.Columns.Add("FULLNAME");
        dt.Columns.Add("LOCATION");
        dt.Columns.Add("CIRCLE");
        dt.Columns.Add("GENDER");
        dt.Columns.Add("MOBILENO");
        dt.Columns.Add("EMAILID");
        dt.Columns.Add("DESIGNATION");
        dt.Columns.Add("ORAGANIZATIONNAME");
        dt.Columns.Add("VODAFONEDOMAINID");
        dt.Columns.Add("EMPIDINUSERSORGANIZATION");
        dt.Columns.Add("STREET");
        dt.Columns.Add("CITY");
        dt.Columns.Add("STATE");
        dt.Columns.Add("POSTALCODE");
        dt.Columns.Add("COUNTRY");
        dt.Columns.Add("COUNTRYCODE");
        dt.Columns.Add("POITYPE");
        dt.Columns.Add("POIVALUE");
        dt.Columns.Add("PHYSICALACCESS");
        dt.Columns.Add("WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF");
        dt.Columns.Add("REVIEWERUNIQUEID");
        dt.Columns.Add("RECORDCNT");
        dt.Columns.Add("ERRORMESSAGE");

        DataRow r = dt.NewRow();
        r[0] = ddlUserSubType.SelectedValue.ToString();
        r[1] = txtFirstName.Text;
        r[2] = txtLastName.Text;
        r[3] = txtFirstName.Text + " " + txtLastName.Text;
        r[4] = txtLocation.Text;
        r[5] = txtCircle.SelectedValue.ToString();
        r[6] = ddlGender.SelectedValue.ToString();
        r[7] = txtMobileNo.Text;
        r[8] = txtEmailID.Text;
        r[9] = txtDesignation.Text;
        r[10] = txtOrgaName.Text;
        r[11] = txtVodaDoID.Text;
        r[12] = txtEmpOrgID.Text;
        r[13] = txtStreet.Text;
        r[14] = txtCity.Text;
        r[15] = txtState.Text;
        r[16] = txtPostalCode.Text;
        r[17] = txtCountry.Text;
        r[18] = txtCountryCode.Text;
        r[19] = txtPOIType.SelectedValue.ToString();
        r[20] = txtPOIValue.Text;
        r[21] = ddlPhysicalAccess.SelectedValue.ToString();
        r[22] = ddlWoked.SelectedValue.ToString();
        r[23] = txtReviewer.Text;
        r[24] = rownum.Value;
        r[25] = errormsg.Text;

        dt.Rows.Add(r);

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            for (int j = 0; j < dtloop.Rows.Count; j++)
            {
                if (Convert.ToString(dt.Rows[i]["RECORDCNT"]) == Convert.ToString(dtloop.Rows[j]["RECORDCNT"]))
                {
                    int cntdomain = 0;
                    int cntdomain1 = 0;
                    int mailcount = 0;
                    string email = string.Empty;
                    DataSet dsmailcheck = new DataSet();
                    string _errorM = string.Empty;
                    int cntat = 0;
                    int cntat1 = 0;
                    int revcnt = 0;
                    dtloop.Rows[j]["ERRORMESSAGE"] = null;

                    var newString = Convert.ToString(txtEmailID.Text).Remove(0, Convert.ToString(txtEmailID.Text).IndexOf('@') + 1);
                    cntdomain = ITSec.Uid_GetDomain(newString);
                    mailcount = ITSec.Check_Email_EMP_Master(txtEmailID.Text.ToString());
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["USERSUBTYPE"])) && Convert.ToString(dt.Rows[i]["USERSUBTYPE"]) != "Select")
                    {
                        dtloop.Rows[j]["USERSUBTYPE"] = Convert.ToString(dt.Rows[i]["USERSUBTYPE"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {

                        dtloop.Rows[j]["USERSUBTYPE"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " User SubType cannot be empty ";
                    }

                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["FIRSTNAME"])))
                    {
                        dtloop.Rows[j]["FIRSTNAME"] = Convert.ToString(dt.Rows[i]["FIRSTNAME"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["FIRSTNAME"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " First name cannot be empty ";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["LASTNAME"])))
                    {
                        dtloop.Rows[j]["LASTNAME"] = Convert.ToString(dt.Rows[i]["LASTNAME"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["LASTNAME"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Last name cannot be empty ";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["FULLNAME"])))
                    {
                        dtloop.Rows[j]["FULLNAME"] = Convert.ToString(dt.Rows[i]["FULLNAME"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["FULLNAME"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Full name cannot be empty ";
                    }

                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["LOCATION"])))
                    {
                        dtloop.Rows[j]["LOCATION"] = Convert.ToString(dt.Rows[i]["LOCATION"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["LOCATION"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Location cannot be empty ";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["CIRCLE"])) && Convert.ToString(dt.Rows[i]["CIRCLE"]) != "Select")
                    {
                        dtloop.Rows[j]["CIRCLE"] = Convert.ToString(dt.Rows[i]["CIRCLE"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["CIRCLE"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Circle cannot be empty ";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["GENDER"])) && Convert.ToString(dt.Rows[i]["GENDER"]) != "Select")
                    {
                        dtloop.Rows[j]["GENDER"] = Convert.ToString(dt.Rows[i]["GENDER"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["GENDER"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Gender cannot be empty ";
                    }

                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["MOBILENO"])))
                    {
                        dtloop.Rows[j]["MOBILENO"] = Convert.ToString(dt.Rows[i]["MOBILENO"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["MOBILENO"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Mobile No. cannot be empty ";
                    }

                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["EMAILID"])))
                    {
                        char[] mail = Convert.ToString(dt.Rows[i]["EMAILID"]).ToCharArray();
                        for (int k = 0; k < mail.Length; k++)
                        {
                            if (mail[k].ToString() == "@")
                            {
                                cntat++;
                            }
                        }
                        if (cntat == 1)
                        {
                            if (cntdomain > 0)
                            {
                                if (mailcount == 1)
                                {
                                    dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Email Id already exist ";
                                    dtloop.Rows[j]["EMAILID"] = Convert.ToString(dt.Rows[i]["EMAILID"]);
                                }
                                else
                                {
                                    dtloop.Rows[j]["EMAILID"] = Convert.ToString(dt.Rows[i]["EMAILID"]);
                                }
                            }
                            else
                            {
                                dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Email Id invalid ";
                                dtloop.Rows[j]["EMAILID"] = Convert.ToString(dt.Rows[i]["EMAILID"]);
                            }

                        }
                        else if (cntat > 1)
                        {
                            dtloop.Rows[j]["EMAILID"] = Convert.ToString(dt.Rows[i]["EMAILID"]);
                            dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Email-Id cannot contain two @ symbol ";
                        }
                        else
                        {
                            dtloop.Rows[j]["EMAILID"] = Convert.ToString(dt.Rows[i]["EMAILID"]);
                            dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Email-Id not valid ";
                        }

                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["EMAILID"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Email Id cannot be empty ";
                    }

                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["DESIGNATION"])))
                    {
                        dtloop.Rows[j]["DESIGNATION"] = Convert.ToString(dt.Rows[i]["DESIGNATION"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["DESIGNATION"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Designation cannot be empty ";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["ORAGANIZATIONNAME"])))
                    {
                        dtloop.Rows[j]["ORAGANIZATIONNAME"] = Convert.ToString(dt.Rows[i]["ORAGANIZATIONNAME"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["ORAGANIZATIONNAME"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Oraganization name cannot be empty ";
                    }
                    //if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["VODAFONEDOMAINID"])))
                    //{
                    //    dtloop.Rows[j]["VODAFONEDOMAINID"] = Convert.ToString(dt.Rows[i]["VODAFONEDOMAINID"]);
                    //    if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                    //    {
                    //        dtloop.Rows[j]["ERRORMESSAGE"] = "";
                    //    }
                    //}
                    //else
                    //{
                    //    dtloop.Rows[j]["VODAFONEDOMAINID"] = "";
                    //    dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Vodafone domain id cannot be empty";
                    //}
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["EMPIDINUSERSORGANIZATION"])))
                    {
                        dtloop.Rows[j]["EMPIDINUSERSORGANIZATION"] = Convert.ToString(dt.Rows[i]["EMPIDINUSERSORGANIZATION"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["EMPIDINUSERSORGANIZATION"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Emp id in user organization cannot be empty ";
                    }
                    dtloop.Rows[j]["STREET"] = Convert.ToString(dt.Rows[i]["STREET"]);
                    dtloop.Rows[j]["CITY"] = Convert.ToString(dt.Rows[i]["CITY"]);
                    dtloop.Rows[j]["STATE"] = Convert.ToString(dt.Rows[i]["STATE"]);
                    dtloop.Rows[j]["POSTALCODE"] = Convert.ToString(dt.Rows[i]["POSTALCODE"]);
                    dtloop.Rows[j]["COUNTRY"] = Convert.ToString(dt.Rows[i]["COUNTRY"]);
                    dtloop.Rows[j]["COUNTRYCODE"] = Convert.ToString(dt.Rows[i]["COUNTRYCODE"]);

                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["POITYPE"])) && Convert.ToString(dt.Rows[i]["POITYPE"]) != "Select")
                    {
                        dtloop.Rows[j]["POITYPE"] = Convert.ToString(dt.Rows[i]["POITYPE"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["POITYPE"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " POI type cannot be empty ";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["POIVALUE"])))
                    {
                        dtloop.Rows[j]["POIVALUE"] = Convert.ToString(dt.Rows[i]["POIVALUE"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["POIVALUE"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " POI value cannot be empty ";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["PHYSICALACCESS"])) && Convert.ToString(dt.Rows[i]["PHYSICALACCESS"]) != "Select")
                    {
                        dtloop.Rows[j]["PHYSICALACCESS"] = Convert.ToString(dt.Rows[i]["PHYSICALACCESS"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["PHYSICALACCESS"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Physical access cannot be empty ";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF"])) && Convert.ToString(dt.Rows[i]["WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF"]) != "Select")
                    {
                        dtloop.Rows[j]["WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF"] = Convert.ToString(dt.Rows[i]["WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF"]);
                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Employee has already worked with vf cannot be empty ";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"])))
                    {
                        dsmailcheck = ITSec.uidselectreviewer(Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]), out _errorM);
                        if (dsmailcheck != null && dsmailcheck.Tables.Count > 0 && dsmailcheck.Tables[0].Rows.Count > 0 && dsmailcheck.Tables[0].Rows[0][0].ToString() != "")
                        {
                            email = Convert.ToString(dsmailcheck.Tables[0].Rows[0]["owner_email_id"]);
                            if (email != "")
                            {
                                char[] mail = email.ToCharArray();
                                for (int k = 0; k < mail.Length; k++)
                                {
                                    if (mail[k].ToString() == "@")
                                    {
                                        cntat1++;
                                    }
                                }
                                var newString1 = email.ToString().Remove(0, email.IndexOf('@') + 1);
                                cntdomain1 = ITSec.Uid_GetDomain(newString1);
                                if (cntat1 == 1)
                                {

                                    if (cntdomain1 == 0)
                                    {
                                        dtloop.Rows[j]["REVIEWERUNIQUEID"] = Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]);
                                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Reviewer email id not valid. ";
                                    }
                                    else
                                    {
                                        revcnt = ITSec.Check_Band(Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]).ToUpper());
                                        if (revcnt == 1)
                                        {
                                            dtloop.Rows[j]["REVIEWERUNIQUEID"] = Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]);
                                            dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " You have either entered a wrong details or the person searched cannot be marked as reviewer. Please select another reviewer or contact circle HR or IT head. ";
                                        }
                                        else if (revcnt == 0)
                                        {
                                            dtloop.Rows[j]["REVIEWERUNIQUEID"] = Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]);
                                            dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Person searched cannot be marked as reviewer ";
                                        }
                                        else
                                        {
                                            dtloop.Rows[j]["REVIEWERUNIQUEID"] = Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]);

                                            if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                                            {
                                                dtloop.Rows[j]["ERRORMESSAGE"] = "";
                                            }
                                        }

                                    }
                                }
                                else if (cntat1 > 1)
                                {
                                    dtloop.Rows[j]["REVIEWERUNIQUEID"] = Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]);
                                    dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Reviewer email id has more then one @ symbol. ";
                                }
                                else
                                {
                                    dtloop.Rows[j]["REVIEWERUNIQUEID"] = Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]);
                                    dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Reviewer email id invalid. ";
                                }
                            }
                            else
                            {
                                dtloop.Rows[j]["REVIEWERUNIQUEID"] = Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]);
                                dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Reviewer doesnot have valid email. Hence, please contact the user to update the details";
                            }

                        }
                        else
                        {
                            dtloop.Rows[j]["REVIEWERUNIQUEID"] = Convert.ToString(dt.Rows[i]["REVIEWERUNIQUEID"]);
                            dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Reviewer unique ID not valid ";
                        }

                        if (dtloop.Rows[j]["ERRORMESSAGE"] == null)
                        {
                            dtloop.Rows[j]["ERRORMESSAGE"] = "";
                        }
                    }
                    else
                    {
                        dtloop.Rows[j]["REVIEWERUNIQUEID"] = "";
                        dtloop.Rows[j]["ERRORMESSAGE"] = dtloop.Rows[j]["ERRORMESSAGE"] + " Reviewer uniqueid cannot be empty ";
                    }
                    if (Convert.ToString(dtloop.Rows[j]["ERRORMESSAGE"]) == "" || dtloop.Rows[j]["ERRORMESSAGE"] == null)
                    {
                        dtloop.Rows[j]["ERRORMESSAGE"] = "Updated Successfully";
                    }


                    //dtloop.Rows[j]["ERRORMESSAGE"] = Convert.ToString(dt.Rows[i]["ERRORMESSAGE"]);
                }
            }
        }
        e.Cancel = true;
        gvSelfBulk.EditIndex = -1;
        gvSelfBulk.DataSource = dtloop;
        gvSelfBulk.DataBind();
        ViewState["GridData"] = dtloop;
    }

    protected void ExcelUpload()
    {
        gvSelfBulk.Visible = true;
        gvdBulkError.Visible = false;
        gvSelfBulk.DataSource = null;
        gvSelfBulk.DataBind();
        tr_CnlConf.Visible = false;
        int i = 1;

        DataTable dt = new DataTable();
        dt.Columns.Add("USERSUBTYPE");
        dt.Columns.Add("FIRSTNAME");
        dt.Columns.Add("LASTNAME");
        dt.Columns.Add("FULLNAME");
        dt.Columns.Add("LOCATION");
        dt.Columns.Add("CIRCLE");
        dt.Columns.Add("GENDER");
        dt.Columns.Add("MOBILENO");
        dt.Columns.Add("EMAILID");
        dt.Columns.Add("DESIGNATION");
        dt.Columns.Add("ORAGANIZATIONNAME");
        dt.Columns.Add("VODAFONEDOMAINID");
        dt.Columns.Add("EMPIDINUSERSORGANIZATION");
        dt.Columns.Add("STREET");
        dt.Columns.Add("CITY");
        dt.Columns.Add("STATE");
        dt.Columns.Add("POSTALCODE");
        dt.Columns.Add("COUNTRY");
        dt.Columns.Add("COUNTRYCODE");
        dt.Columns.Add("POITYPE");
        dt.Columns.Add("POIVALUE");
        dt.Columns.Add("PHYSICALACCESS");
        dt.Columns.Add("WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF");
        dt.Columns.Add("REVIEWERUNIQUEID");
        dt.Columns.Add("RECORDCNT");
        dt.Columns.Add("ERRORMESSAGE");

        DataTable dt1 = new DataTable();
        dt1.Columns.Add("USERSUBTYPE");
        dt1.Columns.Add("FIRSTNAME");
        dt1.Columns.Add("LASTNAME");
        dt1.Columns.Add("FULLNAME");
        dt1.Columns.Add("LOCATION");
        dt1.Columns.Add("CIRCLE");
        dt1.Columns.Add("GENDER");
        dt1.Columns.Add("MOBILENO");
        dt1.Columns.Add("EMAILID");
        dt1.Columns.Add("DESIGNATION");
        dt1.Columns.Add("ORAGANIZATIONNAME");
        dt1.Columns.Add("VODAFONEDOMAINID");
        dt1.Columns.Add("EMPIDINUSERSORGANIZATION");
        dt1.Columns.Add("STREET");
        dt1.Columns.Add("CITY");
        dt1.Columns.Add("STATE");
        dt1.Columns.Add("POSTALCODE");
        dt1.Columns.Add("COUNTRY");
        dt1.Columns.Add("COUNTRYCODE");
        dt1.Columns.Add("POITYPE");
        dt1.Columns.Add("POIVALUE");
        dt1.Columns.Add("PHYSICALACCESS");
        dt1.Columns.Add("WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF");
        dt1.Columns.Add("REVIEWERUNIQUEID");
        dt1.Columns.Add("RECORDCNT");
        dt1.Columns.Add("ERRORMESSAGE");

        string PrmPathExcelFile = string.Empty;
        Excel.Application ExlApplication = null;
        Excel.Workbook ExlWorkbook = null;
        Excel.Sheets ExlSheet = null;
        Excel.Worksheet ExlWorksheet = null;
        System.Collections.Generic.List<int> excelPID = new System.Collections.Generic.List<int>();
        string prefix = DateTime.Now.Ticks.ToString();
        try
        {
            #region AllExcelValidation

            if (FileUploadExcel.PostedFile.FileName == "")//File Uploaded or not
            {
                Double filesize = 0;
                filesize = FileUploadExcel.PostedFile.ContentLength;
                filesize = (filesize / 1048576);
                if (filesize > 3) // Checking file size 
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Your file size should not exceed 3 MB');</script>");
                    FileUploadExcel.Focus();
                    gvSelfBulk.DataSource = null;
                    gvSelfBulk.DataBind();
                    tr_CnlConf.Visible = false;
                    return;
                }
                ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Please upload the file.!!');</script>");
                gvSelfBulk.DataSource = null;
                gvSelfBulk.DataBind();
                tr_CnlConf.Visible = false;
                return;
            }
            if (FileUploadExcel.PostedFile.FileName.EndsWith("xlsx") == false && FileUploadExcel.PostedFile.FileName.EndsWith("xls") == false)// valid excel file or not
            {

                ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Please upload only .xls or .xlsx files.!!');</script>");
                gvSelfBulk.DataSource = null;
                gvSelfBulk.DataBind();
                tr_CnlConf.Visible = false;
                return;
            }

            PrmPathExcelFile = "";
            PrmPathExcelFile = Server.MapPath("");
            PrmPathExcelFile = PrmPathExcelFile + "\\Uploads\\";
            PrmPathExcelFile = PrmPathExcelFile + prefix + "_" + FileUploadExcel.FileName;
            FileUploadExcel.PostedFile.SaveAs(PrmPathExcelFile);

            System.Diagnostics.Process[] prs = System.Diagnostics.Process.GetProcesses();
            foreach (System.Diagnostics.Process p in prs)
                if (p.ProcessName == "EXCEL")
                {
                    excelPID.Add(p.Id);
                }
            ExlApplication = new Excel.Application();
            try
            {
                ExlWorkbook = ExlApplication.Workbooks.Open(PrmPathExcelFile, 0, false, 5, "", "", false, Excel.XlPlatform.xlWindows, "\t", true, true, 0, true);
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language=javascript>alert('" + Resources.ITSecurity.ErrorMsgForExcel + "');</script>");
                return;
            }


            ExlSheet = ExlWorkbook.Sheets;
            ExlWorksheet = (Excel.Worksheet)ExlSheet.get_Item(1);
            string strSheetName = ExlWorksheet.Name;
            int usedcolumns = ExlWorksheet.UsedRange.Columns.Count;
            string[] arrExcelColumn = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W" };

            Excel.Range col1 = (Excel.Range)ExlWorksheet.get_Range("A1", "A1");
            Excel.Range col2 = (Excel.Range)ExlWorksheet.get_Range("B1", "B1");
            Excel.Range col3 = (Excel.Range)ExlWorksheet.get_Range("C1", "C1");
            Excel.Range col4 = (Excel.Range)ExlWorksheet.get_Range("D1", "D1");
            Excel.Range col5 = (Excel.Range)ExlWorksheet.get_Range("E1", "E1");
            Excel.Range col6 = (Excel.Range)ExlWorksheet.get_Range("F1", "F1");
            Excel.Range col7 = (Excel.Range)ExlWorksheet.get_Range("G1", "G1");
            Excel.Range col8 = (Excel.Range)ExlWorksheet.get_Range("H1", "H1");
            Excel.Range col9 = (Excel.Range)ExlWorksheet.get_Range("I1", "I1");
            Excel.Range col10 = (Excel.Range)ExlWorksheet.get_Range("J1", "J1");
            Excel.Range col11 = (Excel.Range)ExlWorksheet.get_Range("K1", "K1");
            Excel.Range col12 = (Excel.Range)ExlWorksheet.get_Range("L1", "L1");
            Excel.Range col13 = (Excel.Range)ExlWorksheet.get_Range("M1", "M1");
            Excel.Range col14 = (Excel.Range)ExlWorksheet.get_Range("N1", "N1");
            Excel.Range col15 = (Excel.Range)ExlWorksheet.get_Range("O1", "O1");
            Excel.Range col16 = (Excel.Range)ExlWorksheet.get_Range("P1", "P1");
            Excel.Range col17 = (Excel.Range)ExlWorksheet.get_Range("Q1", "Q1");
            Excel.Range col18 = (Excel.Range)ExlWorksheet.get_Range("R1", "R1");
            Excel.Range col19 = (Excel.Range)ExlWorksheet.get_Range("S1", "S1");
            Excel.Range col20 = (Excel.Range)ExlWorksheet.get_Range("T1", "T1");
            Excel.Range col21 = (Excel.Range)ExlWorksheet.get_Range("U1", "U1");
            Excel.Range col22 = (Excel.Range)ExlWorksheet.get_Range("V1", "V1");
            Excel.Range col23 = (Excel.Range)ExlWorksheet.get_Range("W1", "W1");
            //Excel.Range col24 = (Excel.Range)ExlWorksheet.get_Range("X1", "X1");

            if ((col1.Text.ToString().Trim().ToUpper() != "USERSUBTYPE") || (col2.Text.ToString().Trim().ToUpper() != "FIRSTNAME")
                || (col3.Text.ToString().Trim().ToUpper() != "LASTNAME") || (col4.Text.ToString().Trim().ToUpper() != "LOCATION")
                || (col5.Text.ToString().Trim().ToUpper() != "CIRCLE") || (col6.Text.ToString().Trim().ToUpper() != "GENDER")
                || (col7.Text.ToString().Trim().ToUpper() != "MOBILENO") || (col8.Text.ToString().Trim().ToUpper() != "EMAILID")
                || (col9.Text.ToString().Trim().ToUpper() != "DESIGNATION") || (col10.Text.ToString().Trim().ToUpper() != "ORAGANIZATIONNAME")
                || (col11.Text.ToString().Trim().ToUpper() != "VODAFONEDOMAINID") || (col12.Text.ToString().Trim().ToUpper() != "EMPIDINUSERSORGANIZATION")
                || (col13.Text.ToString().Trim().ToUpper() != "STREET") || (col14.Text.ToString().Trim().ToUpper() != "CITY")
                || (col15.Text.ToString().Trim().ToUpper() != "STATE") || (col16.Text.ToString().Trim().ToUpper() != "POSTALCODE")
                || (col17.Text.ToString().Trim().ToUpper() != "COUNTRY") || (col18.Text.ToString().Trim().ToUpper() != "COUNTRYCODE")
                || (col19.Text.ToString().Trim().ToUpper() != "POITYPE") || (col20.Text.ToString().Trim().ToUpper() != "POIVALUE")
                || (col21.Text.ToString().Trim().ToUpper() != "PHYSICALACCESS") || (col22.Text.ToString().Trim().ToUpper() != "WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF")
                || (col23.Text.ToString().Trim().ToUpper() != "REVIEWERUNIQUEID"))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language=javascript>alert('Columns in the excel are not accurate please check the template for Sheet1.!!');</script>");
                ExlWorkbook.Close(false, oMissing, oMissing);
                ExlApplication.Quit();
                return;
            }
            try
            {

                if (ExlWorksheet.UsedRange.Rows.Count == 1)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language=javascript>alert('The uploaded file is empty.!!');</script>");
                    ExlWorkbook.Close(false, oMissing, oMissing);
                    ExlApplication.Quit();
                    return;
                }
                if (ExlWorksheet.UsedRange.Rows.Count > 101)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "MyAlert", "<script language='javascript'>alert('Please upload 100 Records at a time.!!');</script>");
                    gvSelfBulk.DataSource = null;
                    gvSelfBulk.DataBind();
                    tr_CnlConf.Visible = false;
                    return;
                }
            #endregion AllExcelValidation


                for (int rowNo = 2; rowNo <= ExlWorksheet.UsedRange.Rows.Count; rowNo++)
                {
                    string strusersubtype = string.Empty;
                    string strfirstname = string.Empty;
                    string strlastname = string.Empty;
                    string strfullname = string.Empty;
                    string strlocation = string.Empty;
                    string strcircle = string.Empty;
                    string strgender = string.Empty;
                    string strmobileno = string.Empty;
                    string stremailid = string.Empty;
                    string strdesignation = string.Empty;
                    string stroranganizationname = string.Empty;
                    string strvodaDomainID = string.Empty;
                    string strempidinusersorga = string.Empty;
                    string strstreet = string.Empty;
                    string strcity = string.Empty;
                    string strstate = string.Empty;
                    string strpostalcode = string.Empty;
                    string strcountry = string.Empty;
                    string strcountrycode = string.Empty;
                    string strPOItype = string.Empty;
                    string strPOIVale = string.Empty;
                    string strphysicalaccess = string.Empty;
                    string strworkedVF = string.Empty;
                    string strrevieweruniqueid = string.Empty;
                    string errmsg = string.Empty;
                    int cntat = 0;
                    int cntdomain = 0;
                    bool valid = true;
                    Excel.Range usersubtype = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[0] + rowNo, arrExcelColumn[0] + rowNo);
                    Excel.Range firstname = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[1] + rowNo, arrExcelColumn[1] + rowNo);
                    Excel.Range lastname = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[2] + rowNo, arrExcelColumn[2] + rowNo);
                    Excel.Range location = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[3] + rowNo, arrExcelColumn[3] + rowNo);
                    Excel.Range circle = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[4] + rowNo, arrExcelColumn[4] + rowNo);
                    Excel.Range gender = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[5] + rowNo, arrExcelColumn[5] + rowNo);
                    Excel.Range mobileno = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[6] + rowNo, arrExcelColumn[6] + rowNo);
                    Excel.Range emailid = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[7] + rowNo, arrExcelColumn[7] + rowNo);
                    Excel.Range designation = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[8] + rowNo, arrExcelColumn[8] + rowNo);
                    Excel.Range oranganizationname = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[9] + rowNo, arrExcelColumn[9] + rowNo);
                    Excel.Range vodaDomainID = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[10] + rowNo, arrExcelColumn[10] + rowNo);
                    Excel.Range empidinusersorganization = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[11] + rowNo, arrExcelColumn[11] + rowNo);
                    Excel.Range street = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[12] + rowNo, arrExcelColumn[12] + rowNo);
                    Excel.Range city = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[13] + rowNo, arrExcelColumn[13] + rowNo);
                    Excel.Range state = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[14] + rowNo, arrExcelColumn[14] + rowNo);
                    Excel.Range postalcode = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[15] + rowNo, arrExcelColumn[15] + rowNo);
                    Excel.Range country = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[16] + rowNo, arrExcelColumn[16] + rowNo);
                    Excel.Range countrycode = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[17] + rowNo, arrExcelColumn[17] + rowNo);
                    Excel.Range POItype = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[18] + rowNo, arrExcelColumn[18] + rowNo);
                    Excel.Range POIVale = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[19] + rowNo, arrExcelColumn[19] + rowNo);
                    Excel.Range physicalaccess = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[20] + rowNo, arrExcelColumn[20] + rowNo);
                    Excel.Range workedVF = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[21] + rowNo, arrExcelColumn[21] + rowNo);
                    Excel.Range revieweruniqueid = (Excel.Range)ExlWorksheet.get_Range(arrExcelColumn[22] + rowNo, arrExcelColumn[22] + rowNo);

                    if (usersubtype.Value == null && firstname.Value == null && lastname.Value == null &&
                                      location.Value == null && circle.Value == null && gender.Value == null && mobileno.Value == null && emailid.Value == null
                                      && designation.Value == null && oranganizationname.Value == null && vodaDomainID.Value == null
                                      && empidinusersorganization.Value == null && street.Value == null && city.Value == null && state.Value == null
                                      && postalcode.Value == null && country.Value == null && countrycode.Value == null && POItype.Value == null
                                      && POIVale.Value == null && physicalaccess.Value == null && workedVF.Value == null && revieweruniqueid.Value == null)
                    {
                        break;
                    }
                    //DataRow r = dt.NewRow();
                    if (usersubtype.Value != null)
                    {
                        strusersubtype = usersubtype.Value.ToString();
                    }
                    else
                    {
                        errmsg = errmsg + "User SubType cannot be empty";
                    }
                    if (firstname.Value != null)
                    {
                        valid = CheckString(firstname.Value.ToString().Trim());
                        if (valid == true)
                        {
                            strfirstname = firstname.Value.ToString();
                        }
                        else
                        {
                            strfirstname = firstname.Value.ToString();
                            errmsg = errmsg + "First name should contain only alphabets";
                        }
                    }
                    else
                    {
                        errmsg = errmsg + " First name cannot be empty";
                    }
                    if (lastname.Value != null)
                    {
                        valid = CheckString(lastname.Value.ToString().Trim());
                        if (valid == true)
                        {
                            strlastname = lastname.Value.ToString();
                        }
                        else
                        {
                            strlastname = lastname.Value.ToString();
                            errmsg = errmsg + " Last name should contain only alphabets ";
                        }
                    }
                    else
                    {
                        errmsg = errmsg + "Last name cannot be empty";
                    }
                    if (firstname.Value != null && lastname.Value != null)
                    {
                        strfullname = firstname.Value.ToString() + " " + lastname.Value.ToString();
                    }
                    else
                    {
                        if (firstname.Value != null || lastname.Value != null)
                        {
                            if (firstname.Value != null)
                            {
                                strfullname = firstname.Value.ToString();
                            }
                            else
                            {
                                strfullname = lastname.Value.ToString();
                            }
                        }
                        else
                        {
                            strfullname = "";
                        }
                    }

                    if (location.Value != null)
                    {
                        valid = CheckStringAlphaNum(location.Value.ToString().Trim());
                        if (valid == true)
                        {
                            strlocation = location.Value.ToString();
                        }
                        else
                        {
                            strlocation = location.Value.ToString();
                            errmsg = errmsg + " Location should contain only alphanumeric ";
                        }

                    }
                    else
                    {
                        errmsg = errmsg + "Location cannot be empty";
                    }
                    if (circle.Value != null)
                    {
                        strcircle = circle.Value.ToString();
                    }
                    else
                    {
                        errmsg = errmsg + "Circle cannot be empty";
                    }
                    if (gender.Value != null)
                    {
                        strgender = gender.Value.ToString();
                    }
                    else
                    {
                        errmsg = errmsg + "Gender cannot be empty";
                    }
                    if (mobileno.Value != null)
                    {
                        strmobileno = mobileno.Value.ToString();
                    }
                    else
                    {
                        errmsg = errmsg + "Mobile no. cannot be empty";
                    }
                    if (emailid.Value != null)
                    {
                        var newString = emailid.Value.ToString().Remove(0, emailid.Value.ToString().IndexOf('@') + 1);
                        cntdomain = ITSec.Uid_GetDomain(newString);
                        int mailcount = 0;
                        if (EmailContains(emailid.Value.ToString()))
                        {
                            if (usersubtype.Value != null)
                            {
                                if (usersubtype.Value.ToString().Trim() != "Call Center Agents")
                                {
                                    mailcount = ITSec.Check_Email_EMP_Master(emailid.Value.ToString());
                                    if (mailcount == 1)
                                    {
                                        errmsg = errmsg + "Email-Id already exist";
                                        stremailid = emailid.Value.ToString();
                                    }
                                    else
                                    {
                                        char[] mail = Convert.ToString(emailid.Value).ToCharArray();

                                        for (int k = 0; k < mail.Length; k++)
                                        {
                                            if (mail[k].ToString() == "@")
                                            {
                                                cntat++;
                                            }
                                        }
                                        if (cntat == 1)
                                        {

                                            if (cntdomain > 0)
                                            {
                                                stremailid = emailid.Value.ToString();
                                            }
                                            else
                                            {
                                                errmsg = errmsg + " Email Id is invalid. ";
                                                stremailid = emailid.Value.ToString();
                                            }


                                        }
                                        else if (cntat > 1)
                                        {
                                            stremailid = emailid.Value.ToString();
                                            errmsg = errmsg + " Email-Id cannot contain two @ symbol ";
                                        }
                                        else
                                        {
                                            stremailid = emailid.Value.ToString();
                                            errmsg = errmsg + " Email-Id is not valid ";
                                        }
                                    }
                                }
                                else
                                {
                                    char[] mail = Convert.ToString(emailid.Value).ToCharArray();
                                    for (int k = 0; k < mail.Length; k++)
                                    {
                                        if (mail[k].ToString() == "@")
                                        {
                                            cntat++;
                                        }
                                    }
                                    if (cntat == 1)
                                    {
                                        if (cntdomain > 0)
                                        {
                                            stremailid = emailid.Value.ToString();
                                        }
                                        else
                                        {
                                            errmsg = errmsg + " Email Id is invalid ";
                                            stremailid = emailid.Value.ToString();
                                        }
                                    }
                                    else if (cntat > 1)
                                    {
                                        stremailid = emailid.Value.ToString();
                                        errmsg = errmsg + " Email-Id cannot contain two @ symbol";
                                    }
                                    else
                                    {
                                        stremailid = emailid.Value.ToString();
                                        errmsg = errmsg + " Email-Id is not valid ";
                                    }
                                }
                            }
                            else
                            {
                                char[] mail = Convert.ToString(emailid.Value).ToCharArray();
                                for (int k = 0; k < mail.Length; k++)
                                {
                                    if (mail[k].ToString() == "@")
                                    {
                                        cntat++;
                                    }
                                }
                                if (cntat == 1)
                                {
                                    if (cntdomain > 0)
                                    {
                                        stremailid = emailid.Value.ToString();
                                    }
                                    else
                                    {
                                        errmsg = errmsg + "Domain Id is invalid ";
                                        stremailid = emailid.Value.ToString();
                                    }
                                }
                                else if (cntat > 1)
                                {
                                    stremailid = emailid.Value.ToString();
                                    errmsg = errmsg + " Email-Id cannot contain two @ symbol ";
                                }
                                else
                                {
                                    stremailid = emailid.Value.ToString();
                                    errmsg = errmsg + " Email-Id not valid ";
                                }
                            }

                        }
                        else
                        {
                            stremailid = emailid.Value.ToString();
                            errmsg = errmsg + "Email is not in a correct format";
                        }

                    }
                    else
                    {
                        errmsg = errmsg + "Email id cannot be empty";
                    }
                    if (designation.Value != null)
                    {
                        valid = CheckStringAlphaNum(designation.Value.ToString().Trim());
                        if (valid == true)
                        {
                            strdesignation = designation.Value.ToString();
                        }
                        else
                        {
                            strdesignation = designation.Value.ToString();
                            errmsg = errmsg + " Designation should contain only alphanumeric ";
                        }
                    }
                    else
                    {
                        errmsg = errmsg + "Designation cannot be empty";
                    }
                    if (oranganizationname.Value != null)
                    {
                        valid = CheckStringAlphaNum(oranganizationname.Value.ToString().Trim());
                        if (valid == true)
                        {
                            stroranganizationname = oranganizationname.Value.ToString();
                        }
                        else
                        {
                            stroranganizationname = oranganizationname.Value.ToString();
                            errmsg = errmsg + " Organization name should contain only alphanumeric ";
                        }

                    }
                    else
                    {

                        errmsg = errmsg + "Organization name cannot be empty";
                    }
                    if (vodaDomainID.Value != null)
                    {
                        valid = CheckStringAlphaNum(vodaDomainID.Value.ToString().Trim());
                        if (valid == true)
                        {
                            strvodaDomainID = vodaDomainID.Value.ToString();
                        }
                        else
                        {
                            strvodaDomainID = vodaDomainID.Value.ToString();
                            //errmsg = errmsg + " Vodafone domain id should contain only alphanumeric ";
                        }

                    }
                    else
                    {

                        strvodaDomainID = "";
                    }
                    if (empidinusersorganization.Value != null)
                    {
                        valid = CheckStringAlphaNumSpecial(empidinusersorganization.Value.ToString().Trim());
                        if (valid == true)
                        {
                            strempidinusersorga = empidinusersorganization.Value.ToString();
                        }
                        else
                        {
                            strempidinusersorga = empidinusersorganization.Value.ToString();
                            errmsg = errmsg + " Emp. ID in user's organization should contain only alphanumeric ";
                        }

                    }
                    else
                    {

                        errmsg = errmsg + "Emp. ID in user's organization cannot be empty";
                    }
                    if (street.Value != null)
                    {
                        strstreet = street.Value.ToString();

                    }

                    if (city.Value != null)
                    {
                        strcity = city.Value.ToString();


                    }

                    if (state.Value != null)
                    {
                        strstate = state.Value.ToString();


                    }
                    if (postalcode.Value != null)
                    {
                        strpostalcode = postalcode.Value.ToString();
                    }
                    if (country.Value != null)
                    {
                        strcountry = country.Value.ToString();

                    }

                    if (countrycode.Value != null)
                    {
                        strcountrycode = countrycode.Value.ToString();

                    }

                    if (POItype.Value != null)
                    {

                        strPOItype = POItype.Value.ToString();


                    }
                    else
                    {
                        errmsg = errmsg + "POI type cannot be empty";
                    }
                    if (POIVale.Value != null)
                    {
                        valid = CheckStringAlphaNumSpecial(POIVale.Value.ToString().Trim());
                        if (valid == true)
                        {
                            strPOIVale = POIVale.Value.ToString();
                        }
                        else
                        {
                            strPOIVale = POIVale.Value.ToString();
                            errmsg = errmsg + " POI Value should contain alphanumeric, dash(-) and forward slash (/)  ";
                        }
                    }
                    else
                    {

                        errmsg = errmsg + "POI Value cannot be empty";
                    }
                    if (physicalaccess.Value != null)
                    {
                        strphysicalaccess = physicalaccess.Value.ToString();
                    }
                    else
                    {

                        errmsg = errmsg + "Physical access cannot be empty";
                    }
                    if (workedVF.Value != null)
                    {
                        strworkedVF = workedVF.Value.ToString();
                    }
                    else
                    {
                        errmsg = errmsg + "Whether the employee has already worked with vf cannot be empty";
                    }
                    int revcnt = 0;
                    if (revieweruniqueid.Value != null)
                    {
                        revcnt = ITSec.Check_Band(revieweruniqueid.Value.ToString().ToUpper());
                        if (revcnt == 1)
                        {
                            strrevieweruniqueid = revieweruniqueid.Value.ToString();
                            errmsg = errmsg + "You have either entered a wrong details or the person searched cannot be marked as reviewer. Please select another reviewer or contact circle HR or IT head.";
                        }
                        else if (revcnt == 0)
                        {
                            strrevieweruniqueid = revieweruniqueid.Value.ToString();
                            errmsg = errmsg + "Person searched cannot be marked as reviewer";
                        }
                        else
                        {
                            strrevieweruniqueid = revieweruniqueid.Value.ToString();
                        }

                    }
                    else
                    {
                        errmsg = errmsg + "Reviewer unique id cannot be empty";
                    }


                    if (!string.IsNullOrEmpty(errmsg))
                    {
                        DataRow r = dt.NewRow();
                        if (strusersubtype == "")
                        {
                            strusersubtype = "Select";
                        }
                        r[0] = strusersubtype;
                        r[1] = strfirstname;
                        r[2] = strlastname;
                        r[3] = strfullname;
                        r[4] = strlocation;
                        if (strcircle == "")
                        {
                            strcircle = "Select";
                        }
                        r[5] = strcircle;
                        if (strgender == "")
                        {
                            strgender = "Select";
                        }
                        r[6] = strgender;
                        r[7] = strmobileno;
                        r[8] = stremailid;
                        r[9] = strdesignation;
                        r[10] = stroranganizationname;
                        r[11] = strvodaDomainID;
                        r[12] = strempidinusersorga;
                        r[13] = strstreet;
                        r[14] = strcity;
                        r[15] = strstate;
                        r[16] = strpostalcode;
                        r[17] = strcountry;
                        r[18] = strcountrycode;
                        if (strPOItype == "")
                        {
                            strPOItype = "Select";
                        }
                        r[19] = strPOItype;
                        r[20] = strPOIVale;
                        if (strphysicalaccess == "")
                        {
                            strphysicalaccess = "Select";
                        }
                        r[21] = strphysicalaccess;
                        if (strworkedVF == "")
                        {
                            strworkedVF = "Select";
                        }
                        r[22] = strworkedVF;
                        r[23] = strrevieweruniqueid;
                        r[24] = i;
                        r["ERRORMESSAGE"] = errmsg;
                        dt.Rows.Add(r);
                        i++;
                    }
                    else
                    {
                        DataRow r1 = dt1.NewRow();
                        r1[0] = strusersubtype;
                        r1[1] = strfirstname;
                        r1[2] = strlastname;
                        r1[3] = strfullname;
                        r1[4] = strlocation;
                        r1[5] = strcircle;
                        r1[6] = strgender;
                        r1[7] = strmobileno;
                        r1[8] = stremailid;
                        r1[9] = strdesignation;
                        r1[10] = stroranganizationname;
                        r1[11] = strvodaDomainID;
                        r1[12] = strempidinusersorga;
                        r1[13] = strstreet;
                        r1[14] = strcity;
                        r1[15] = strstate;
                        r1[16] = strpostalcode;
                        r1[17] = strcountry;
                        r1[18] = strcountrycode;
                        r1[19] = strPOItype;
                        r1[20] = strPOIVale;
                        r1[21] = strphysicalaccess;
                        r1[22] = strworkedVF;
                        r1[23] = strrevieweruniqueid;
                        r1[24] = i;
                        r1["ERRORMESSAGE"] = errmsg + "Uploaded Successfully";
                        dt1.Rows.Add(r1);
                        i++;
                    }

                }
                if (dt.Rows.Count > 0 || dt1.Rows.Count > 0)
                {
                    dt1.Merge(dt);
                    gvSelfBulk.Visible = true;
                    gvSelfBulk.DataSource = dt1;
                    gvSelfBulk.DataBind();
                    ViewState["GridData"] = dt1;
                    tr_CnlConf.Visible = true;
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {

                ExlWorkbook.Close(false, oMissing, oMissing);
                ExlApplication.Quit();
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(ExlSheet);
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(ExlWorksheet);
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(ExlWorkbook);
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(ExlApplication);
                ExlApplication = null;
                prs = System.Diagnostics.Process.GetProcesses();
                foreach (System.Diagnostics.Process p in prs)
                    if (p.ProcessName == "EXCEL" && !excelPID.Contains(p.Id))
                    {
                        p.Kill();
                    }
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void btnConfirm_OnClick(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        DataSet dsuser = new DataSet();
        DataSet dstoken = new DataSet();
        DataSet dslocation = new DataSet();
        DataSet dsmailcheck = new DataSet();
        DataTable dt1 = new DataTable();
        int count = 0;
        int userSubTypeInt = 0;
        int emailcnt = 0;
        bool valid = true;
        string usersubtype = string.Empty;
        string firstname = string.Empty;
        string lastname = string.Empty;
        string fullname = string.Empty;
        string location = string.Empty;
        string circle = string.Empty;
        string gender = string.Empty;
        string mobileno = string.Empty;
        string emailid = string.Empty;
        string designation = string.Empty;
        string oraganizationname = string.Empty;
        string vodaDomainId = string.Empty;
        string empidinuserorag = string.Empty;
        string street = string.Empty;
        string city = string.Empty;
        string state = string.Empty;
        string postalcode = string.Empty;
        string country = string.Empty;
        string countrycode = string.Empty;
        string poitype = string.Empty;
        string poivalue = string.Empty;
        string physicalaccess = string.Empty;
        string empworkedwithvf = string.Empty;
        string revieweruniqueid = string.Empty;
        string errormessage = string.Empty;

        gvSelfBulk.EditIndex = -1;
        dt.Columns.Add("USERSUBTYPE");
        dt.Columns.Add("FIRSTNAME");
        dt.Columns.Add("LASTNAME");
        dt.Columns.Add("FULLNAME");
        dt.Columns.Add("LOCATION");
        dt.Columns.Add("CIRCLE");
        dt.Columns.Add("GENDER");
        dt.Columns.Add("MOBILENO");
        dt.Columns.Add("EMAILID");
        dt.Columns.Add("DESIGNATION");
        dt.Columns.Add("ORAGANIZATIONNAME");
        dt.Columns.Add("VODAFONEDOMAINID");
        dt.Columns.Add("EMPIDINUSERSORGANIZATION");
        dt.Columns.Add("STREET");
        dt.Columns.Add("CITY");
        dt.Columns.Add("STATE");
        dt.Columns.Add("POSTALCODE");
        dt.Columns.Add("COUNTRY");
        dt.Columns.Add("COUNTRYCODE");
        dt.Columns.Add("POITYPE");
        dt.Columns.Add("POIVALUE");
        dt.Columns.Add("PHYSICALACCESS");
        dt.Columns.Add("WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF");
        dt.Columns.Add("REVIEWERUNIQUEID");
        dt.Columns.Add("ERRORMESSAGE");


        dt1.Columns.Add("USERSUBTYPE");
        dt1.Columns.Add("FIRSTNAME");
        dt1.Columns.Add("LASTNAME");
        dt1.Columns.Add("FULLNAME");
        dt1.Columns.Add("LOCATION");
        dt1.Columns.Add("CIRCLE");
        dt1.Columns.Add("GENDER");
        dt1.Columns.Add("MOBILENO");
        dt1.Columns.Add("EMAILID");
        dt1.Columns.Add("DESIGNATION");
        dt1.Columns.Add("ORAGANIZATIONNAME");
        dt1.Columns.Add("VODAFONEDOMAINID");
        dt1.Columns.Add("EMPIDINUSERSORGANIZATION");
        dt1.Columns.Add("STREET");
        dt1.Columns.Add("CITY");
        dt1.Columns.Add("STATE");
        dt1.Columns.Add("POSTALCODE");
        dt1.Columns.Add("COUNTRY");
        dt1.Columns.Add("COUNTRYCODE");
        dt1.Columns.Add("POITYPE");
        dt1.Columns.Add("POIVALUE");
        dt1.Columns.Add("PHYSICALACCESS");
        dt1.Columns.Add("WHETHERTHEEMPLOYEEHASALREADYWORKEDWITHVF");
        dt1.Columns.Add("REVIEWERUNIQUEID");
        dt1.Columns.Add("ERRORMESSAGE");



        foreach (GridViewRow gvr in gvSelfBulk.Rows)
        {
            try
            {
                HtmlInputCheckBox chk = (HtmlInputCheckBox)gvr.FindControl("chkDetailsSS");
                if (chk != null)
                {
                    string errmsg = string.Empty;
                    if (chk.Checked)
                    {
                        int counterror = 0;
                        string email = string.Empty;
                        int cntdomain = 0;
                        string _errorM = string.Empty;
                        int cntat = 0;
                        usersubtype = (gvr.Cells[2].FindControl("lblUserSubType") as Label).Text;
                        firstname = (gvr.Cells[3].FindControl("lblFirstName") as Label).Text;
                        lastname = (gvr.Cells[4].FindControl("lblLastName") as Label).Text;
                        fullname = firstname + " " + lastname;
                        location = (gvr.Cells[6].FindControl("lblLocation") as Label).Text;
                        circle = (gvr.Cells[7].FindControl("lblCircle") as Label).Text;
                        gender = (gvr.Cells[8].FindControl("lblGender") as Label).Text;
                        mobileno = (gvr.Cells[9].FindControl("lblMobileNo") as Label).Text;
                        emailid = (gvr.Cells[10].FindControl("lblEmailID") as Label).Text;
                        designation = (gvr.Cells[11].FindControl("lblDesignation") as Label).Text;
                        oraganizationname = (gvr.Cells[12].FindControl("lblOrgaName") as Label).Text;
                        vodaDomainId = (gvr.Cells[13].FindControl("lblVodaDoID") as Label).Text;
                        empidinuserorag = (gvr.Cells[14].FindControl("lblEmpOrgID") as Label).Text;
                        poitype = (gvr.Cells[21].FindControl("lblPOIType") as Label).Text;
                        poivalue = (gvr.Cells[22].FindControl("lblPOIValue") as Label).Text;
                        physicalaccess = (gvr.Cells[23].FindControl("lblPhysicalAccess") as Label).Text;
                        errormessage = (gvr.Cells[26].FindControl("lblErrorMsg") as Label).Text;
                        if (physicalaccess == "Yes")
                        {
                            physicalaccess = "Y";
                        }
                        else
                        {
                            physicalaccess = "N";
                        }
                        empworkedwithvf = (gvr.Cells[24].FindControl("lblWoked") as Label).Text;
                        if (empworkedwithvf == "Yes")
                        {
                            empworkedwithvf = "Y";
                        }
                        else
                        {
                            empworkedwithvf = "N";
                        }
                        revieweruniqueid = (gvr.Cells[25].FindControl("lblReviewer") as Label).Text;
                        if (usersubtype == "Document Processing Agents")
                        {
                            userSubTypeInt = 1;
                        }
                        else if (usersubtype == "Call Center Agents")
                        {
                            userSubTypeInt = 2;
                        }
                        else if (usersubtype == "Back Office Agents")
                        {
                            userSubTypeInt = 3;
                        }
                        else if (usersubtype == "Service Partners - Network")
                        {
                            userSubTypeInt = 4;
                        }
                        else if (usersubtype == "Dealers")
                        {
                            userSubTypeInt = 5;
                        }
                        else if (usersubtype == "Service Partners - IT")
                        {
                            userSubTypeInt = 6;
                        }
                        else if (usersubtype == "Off roll employees")
                        {
                            userSubTypeInt = 7;
                        }

                        count = ITSec.CheckSAMBulkUpload_Validation(usersubtype, location, circle, street, city, state, postalcode, country, countrycode, poitype, revieweruniqueid);


                        dsmailcheck = ITSec.uidselectreviewer(revieweruniqueid, out _errorM);

                        if (dsmailcheck != null && dsmailcheck.Tables.Count > 0 && dsmailcheck.Tables[0].Rows.Count > 0 && dsmailcheck.Tables[0].Rows[0][0].ToString() != "")
                        {
                            email = Convert.ToString(dsmailcheck.Tables[0].Rows[0]["owner_email_id"]);
                            if (email != "")
                            {
                                char[] mail = email.ToCharArray();
                                for (int k = 0; k < mail.Length; k++)
                                {
                                    if (mail[k].ToString() == "@")
                                    {
                                        cntat++;
                                    }
                                }
                                var newString = email.ToString().Remove(0, email.IndexOf('@') + 1);
                                cntdomain = ITSec.Uid_GetDomain(newString);
                                if (cntat == 1)
                                {

                                    if (cntdomain == 0)
                                    {
                                        errmsg = errmsg + " Reviewer email id not valid ";
                                    }
                                }
                                else if (cntat > 1)
                                {
                                    errmsg = errmsg + " Reviewer email id has more then one @ symbol ";
                                }
                                else
                                {
                                    errmsg = errmsg + " Reviewer email id is not valid ";
                                }
                            }
                            else
                            {
                                errmsg = errmsg + "Selected Reviewer does not have valid email ID. Hence, please contact the reviewer to update email ID.";
                            }

                        }
                        else
                        {
                            errmsg = errmsg + " Reviewer unique id is not valid. ";
                        }

                        if (count == 11 || count == 22)
                        {

                            errmsg = errmsg + " User SubType or Location not exist ";
                            counterror++;
                        }
                        else
                        {
                            dslocation = ITSec.GetLocationDetails(userSubTypeInt, location);
                            if (dslocation == null || dslocation.Tables[0].Rows.Count == 0)
                            {
                                errmsg = errmsg + " User SubType and Location not mapped ";
                                count = 444;
                                counterror++;
                            }
                            else
                            {
                                street = Convert.ToString(dslocation.Tables[0].Rows[0]["STREET"]);
                                city = Convert.ToString(dslocation.Tables[0].Rows[0]["CITY"]);
                                state = Convert.ToString(dslocation.Tables[0].Rows[0]["STATE"]);
                                postalcode = Convert.ToString(dslocation.Tables[0].Rows[0]["POSTAL_CODE"]);
                                country = Convert.ToString(dslocation.Tables[0].Rows[0]["COUNTRY"]);
                                countrycode = Convert.ToString(dslocation.Tables[0].Rows[0]["COUNTRY_CODE"]);

                            }
                        }

                        if (count == 33)
                        {

                            errmsg = errmsg + " Circle not exist ";
                            counterror++;

                        }

                        if (userSubTypeInt != 2)
                        {
                            emailcnt = ITSec.Check_OwnerMail_In_UserregTemp(emailid);
                            if (emailcnt > 0)
                            {
                                errmsg = errmsg + " Email Id already exist ";
                                counterror++;
                                count = 555;
                            }
                        }
                        if (count == 100)
                        {

                            errmsg = errmsg + " POI Type not exist ";
                            counterror++;
                        }
                        if (count == 101)
                        {

                            errmsg = errmsg + " Reviewer UniqueId not exist ";
                            counterror++;
                        }
                        if (count == 102)
                        {

                            errmsg = errmsg + " You have either entered a wrong details or the person searched cannot be marked as reviewer. Please select another reviewer or contact circle HR or IT head. ";
                            counterror++;
                        }
                        else
                        {
                            DataSet dsrev = new DataSet();
                            string _errorMsgs = string.Empty;
                            dsrev = ITSec.uid_select_reviewer(revieweruniqueid, out _errorMsgs);
                            if ((dsrev != null && dsrev.Tables[0].Rows.Count > 0) || !string.IsNullOrEmpty(_errorMsgs))
                            {
                                if (!string.IsNullOrEmpty(_errorMsgs))
                                {
                                    errmsg = errmsg + " Please contact Circle HR ";
                                    counterror++;
                                    count = 333;

                                }
                                else if (dsrev != null && dsrev.Tables[0].Rows.Count > 0)
                                {
                                    if (revieweruniqueid.ToUpper() != dsrev.Tables[0].Rows[0]["UNIQUE_ID"].ToString())
                                    {
                                        errmsg = errmsg + " You have selected invalid reviewer as  he/she does not have VIL employee as a Reviewer. Please select " + dsrev.Tables[0].Rows[0]["owner_name"] + " as your reviewer ";
                                        counterror++;
                                        count = 333;

                                    }
                                }
                            }
                        }

                        if (count == 1 && string.IsNullOrEmpty(errmsg) && (errormessage == "Uploaded Successfully" || errormessage == "Updated Successfully"))
                        {
                            string _errorMsg = string.Empty;
                            string strLocalIP = string.Empty;
                            string rname = string.Empty;
                            string rvname = string.Empty;
                            string rdept = string.Empty;
                            string rSubdept = string.Empty;
                            string rcircle = string.Empty;
                            string revmobile = string.Empty;
                            string rmobile = string.Empty;
                            string remail = string.Empty;
                            string rOrgName = string.Empty;
                            //Get User SubType ID from Name start                        
                            dsuser = ITSec.GetUserSubTypeID(usersubtype);
                            //Get User SubType ID from Name end
                            strLocalIP = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                            if (strLocalIP == "" || strLocalIP == null)
                            {
                                strLocalIP = Request.ServerVariables["REMOTE_ADDR"];
                            }
                            string Added_by_Domain_id = Request.ServerVariables["LOGON_USER"].ToString();
                            ds = ITSec.uidselectreviewer(revieweruniqueid, out _errorMsg);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                rname = Convert.ToString(ds.Tables[0].Rows[0]["owner_name"]);
                                rvname = Convert.ToString(ds.Tables[0].Rows[0]["owner_name"]);
                                rdept = Convert.ToString(ds.Tables[0].Rows[0]["DEPARTMENT"]);
                                rSubdept = Convert.ToString(ds.Tables[0].Rows[0]["SUB_DEPARTMENT"]);
                                rcircle = Convert.ToString(ds.Tables[0].Rows[0]["CIRCLE"]);
                                revmobile = Convert.ToString(ds.Tables[0].Rows[0]["MOBILE_NO"]);
                                rmobile = Convert.ToString(ds.Tables[0].Rows[0]["MOB_NO"]);
                                remail = Convert.ToString(ds.Tables[0].Rows[0]["owner_email_id"]);
                                rOrgName = Convert.ToString(ds.Tables[0].Rows[0]["ORGANIZATION"]);
                                //Session["dept"].ToString()//Need to check
                            }

                            dstoken = ITSec.InsertIDMSelfEmp(fullname, emailid, circle, location, "", rSubdept, designation,
                                mobileno, "NON-VEL", oraganizationname, vodaDomainId, Added_by_Domain_id, 0, "CURRENT", rname, rvname, rdept, rcircle,
                                rmobile, remail, Added_by_Domain_id, revieweruniqueid, Added_by_Domain_id, strLocalIP, revieweruniqueid, firstname,
                                lastname, state, city, street, postalcode, poitype, poivalue, Convert.ToString(dsuser.Tables[0].Rows[0]["USERTYPE_ID"]), gender, country, countrycode, empidinuserorag,
                                physicalaccess, empworkedwithvf, "");
                            if (dstoken != null && dstoken.Tables[0].Rows.Count != 0)
                            {
                                if (!string.IsNullOrEmpty(dstoken.Tables[0].Rows[0][0].ToString())
                                    && !string.IsNullOrEmpty(dstoken.Tables[0].Rows[0][1].ToString())
                                    && !string.IsNullOrEmpty(dstoken.Tables[0].Rows[0][2].ToString()))
                                {
                                    string temp_Unique_id = dstoken.Tables[0].Rows[0][0].ToString();
                                    string token_No = dstoken.Tables[0].Rows[0][1].ToString();
                                    SendMail_ForEmailvalidation(emailid, "Self Registration", fullname,
                                                         temp_Unique_id.ToString().Trim(), token_No.ToString().Trim());
                                    errmsg = errmsg + "Data inserted successfully";
                                    DataRow r = dt.NewRow();
                                    r[0] = usersubtype;
                                    r[1] = firstname;
                                    r[2] = lastname;
                                    r[3] = fullname;
                                    r[4] = location;
                                    r[5] = circle;
                                    r[6] = gender;
                                    r[7] = mobileno;
                                    r[8] = emailid;
                                    r[9] = designation;
                                    r[10] = oraganizationname;
                                    r[11] = vodaDomainId;
                                    r[12] = empidinuserorag;
                                    r[13] = street;
                                    r[14] = city;
                                    r[15] = state;
                                    r[16] = postalcode;
                                    r[17] = country;
                                    r[18] = countrycode;
                                    r[19] = poitype;
                                    r[20] = poivalue;
                                    if (physicalaccess == "N")
                                    {
                                        physicalaccess = "NO";
                                    }
                                    if (physicalaccess == "Y")
                                    {
                                        physicalaccess = "YES";
                                    }

                                    r[21] = physicalaccess;
                                    if (empworkedwithvf == "N")
                                    {
                                        empworkedwithvf = "NO";
                                    }
                                    if (empworkedwithvf == "Y")
                                    {
                                        empworkedwithvf = "YES";
                                    }
                                    r[22] = empworkedwithvf;
                                    r[23] = revieweruniqueid;
                                    r["ERRORMESSAGE"] = errmsg;
                                    dt.Rows.Add(r);
                                }
                                else
                                {

                                    errmsg = errmsg + "Mobile No./Email ID already exist.";
                                    DataRow r = dt.NewRow();
                                    r[0] = usersubtype;
                                    r[1] = firstname;
                                    r[2] = lastname;
                                    r[3] = fullname;
                                    r[4] = location;
                                    r[5] = circle;
                                    r[6] = gender;
                                    r[7] = mobileno;
                                    r[8] = emailid;
                                    r[9] = designation;
                                    r[10] = oraganizationname;
                                    r[11] = vodaDomainId;
                                    r[12] = empidinuserorag;
                                    r[13] = street;
                                    r[14] = city;
                                    r[15] = state;
                                    r[16] = postalcode;
                                    r[17] = country;
                                    r[18] = countrycode;
                                    r[19] = poitype;
                                    r[20] = poivalue;
                                    if (physicalaccess == "N")
                                    {
                                        physicalaccess = "NO";
                                    }
                                    if (physicalaccess == "Y")
                                    {
                                        physicalaccess = "YES";
                                    }
                                    r[21] = physicalaccess;
                                    if (empworkedwithvf == "N")
                                    {
                                        empworkedwithvf = "NO";
                                    }
                                    if (empworkedwithvf == "Y")
                                    {
                                        empworkedwithvf = "YES";
                                    }
                                    r[22] = empworkedwithvf;
                                    r[23] = revieweruniqueid;
                                    r["ERRORMESSAGE"] = errmsg;
                                    dt.Rows.Add(r);

                                }

                            }
                        }
                    }
                    else
                    {
                        DataRow r1 = dt1.NewRow();
                        r1[0] = usersubtype;
                        r1[1] = firstname;
                        r1[2] = lastname;
                        r1[3] = fullname;
                        r1[4] = location;
                        r1[5] = circle;
                        r1[6] = gender;
                        r1[7] = mobileno;
                        r1[8] = emailid;
                        r1[9] = designation;
                        r1[10] = oraganizationname;
                        r1[11] = vodaDomainId;
                        r1[12] = empidinuserorag;
                        r1[13] = street;
                        r1[14] = city;
                        r1[15] = state;
                        r1[16] = postalcode;
                        r1[17] = country;
                        r1[18] = countrycode;
                        r1[19] = poitype;
                        r1[20] = poivalue;
                        if (physicalaccess == "N")
                        {
                            physicalaccess = "NO";
                        }
                        if (physicalaccess == "Y")
                        {
                            physicalaccess = "YES";
                        }
                        r1[21] = physicalaccess;
                        if (empworkedwithvf == "N")
                        {
                            empworkedwithvf = "NO";
                        }
                        if (empworkedwithvf == "Y")
                        {
                            empworkedwithvf = "YES";
                        }
                        r1[22] = empworkedwithvf;
                        r1[23] = revieweruniqueid;
                        r1["ERRORMESSAGE"] = errmsg;
                        dt1.Rows.Add(r1);
                    }
                }

            }
            catch (Exception ex)
            {
                CreateLogFiles.CreateErrorLogEntry("BindUserDetails", ex.ToString());
            }
        }

        if (dt.Rows.Count > 0 || dt1.Rows.Count > 0)
        {
            dt1.Merge(dt);
            gvdBulkError.Visible = true;
            gvdBulkError.DataSource = dt1;
            gvdBulkError.DataBind();
            tr_CnlConf.Visible = false;
            gvSelfBulk.Visible = false;
        }
    }

    protected void btnCancel_OnClick(object sender, EventArgs e)
    {
        Response.Redirect("SelfReg_BulkUpload.aspx");
    }
    public void SendMail_ForEmailvalidation(string To, string Subject, string uname, string Temp_uniqueid, string TokenNo)
    {
        try
        {
            string UName = uname;
            string srlink;
            string ApplicationLink;
            if (strIsProduction.ToUpper().ToString() == "TRUE")
            {
                srlink = ConfigurationManager.AppSettings["SRLink"].ToString();
                ApplicationLink = ConfigurationManager.AppSettings["AppPath"].ToString();
            }
            else
            {
                srlink = ConfigurationManager.AppSettings["SRLinkSIT"].ToString();
                ApplicationLink = ConfigurationManager.AppSettings["SRLinkSIT"].ToString();
            }
            string ccaddress = "Security.AccessManager@vodafone.com";
            string ApplicationName = "Validate Self-Registration Email";
            string Body = string.Empty;
            StringBuilder mailBody = new StringBuilder();
            //   ApplicationLink = "https://10.87.137.219//SAM_PREPROD//ValidateSelfRegistration.aspx";
            //SAM Enhancement
            mailBody.Append("<div>Hi " + UName + " , </div>");
            mailBody.Append("<div>&nbsp;</div>");
            mailBody.Append("<div> Your self-registration request has been submitted in SAM.</div>");
            mailBody.Append("<div> To proceed further with the registration process, you need to validate your email address.</div>");
            mailBody.Append("<div> You can do that by selecting the following link <a href='[Link]' target='_blank'>[AppName]</a> Upon Self Registration landing page</div>");
            mailBody.Append("<div> Please enter the following details :- </div>");
            mailBody.Append("<div> 1) Name : " + UName + "</div>");
            mailBody.Append("<div> 2) Temporary Unique ID : " + Temp_uniqueid + "</div>");
            mailBody.Append("<div> 3) Token :  " + TokenNo + " </div>");
            mailBody.Append("<div>4) Registration Email ID :  " + To + "</div>");
            mailBody.Append("<div>&nbsp;</div>");
            mailBody.Append("<div>Best Regards,</div>");
            mailBody.Append("<div>Security Access Manager</div>");
            mailBody = mailBody.Replace("[Link]", ApplicationLink);
            mailBody = mailBody.Replace("[AppName]", ApplicationName);
            mailBody = mailBody.Replace("[SRLink]", srlink);
            //to send mail omn msg form
            Session["mailBody"] = mailBody.ToString();
            ITSec.MailSend(To, "", "", Resources.ITSecurity.FromMailID.Trim(), Subject, mailBody.ToString());
            ITSec.InsertReminderMailsHistory(Subject, To, To, "", Convert.ToInt32(Resources.ITSecurity.MailID));
        }
        catch (Exception ex)
        {
            //CreateLogFiles.CreateErrorLogEntry("SendMail_ForEmailvalidation", ex.ToString());
        }
        finally
        {

        }
    }


    public bool EmailContains(string email)
    {

        if (System.Text.RegularExpressions.Regex.IsMatch(email, "[^a-zA-Z0-9-_@.]"))
        {
            return false;
        }

        return true;
    }
    protected void gvdBulkError_OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (e.Row.Cells[24].Text != "")
            {
                if (e.Row.Cells[24].Text == "Data inserted successfully")
                {
                    e.Row.Cells[24].ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    e.Row.Cells[24].ForeColor = System.Drawing.Color.Red;
                }
            }
            for (int i = 0; i < e.Row.Cells.Count; i++)
            {
                if (e.Row.Cells[i].Text != "" && e.Row.Cells[i].Text != "&nbsp;")
                {
                    e.Row.Cells[i].Text = e.Row.Cells[i].Text.ToUpper();
                }
            }
        }
    }
    public bool CheckString(string strValue)
    {

        if (System.Text.RegularExpressions.Regex.IsMatch(strValue, @"^[a-zA-Z]+$"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public bool CheckStringAlphaNum(string strValue)
    {

        if (System.Text.RegularExpressions.Regex.IsMatch(strValue, @"^[a-zA-Z0-9 ]+$"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public bool CheckStringAlphaNumSpecial(string strValue)
    {

        if (System.Text.RegularExpressions.Regex.IsMatch(strValue, @"^[a-zA-Z\d-/]+$"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    protected void gvSelfBulk_OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState & DataControlRowState.Edit) == DataControlRowState.Edit)
            {

                DropDownList lblUserSubType = (e.Row.FindControl("ddlUserSubType") as DropDownList);
                DropDownList lblCircle = (e.Row.FindControl("ddlCircle") as DropDownList);
                DropDownList lblGender = (e.Row.FindControl("ddlGender") as DropDownList);
                DropDownList lblPOIType = (e.Row.FindControl("ddlPoiType") as DropDownList);
                DropDownList lblPhyAccess = (e.Row.FindControl("ddlPhysicalAccess") as DropDownList);
                DropDownList lblWorked = (e.Row.FindControl("ddlWoked") as DropDownList);

                DataSet ds = new DataSet();
                DataSet dspoi = new DataSet();

                DropDownList Circle = (e.Row.FindControl("ddlCircle") as DropDownList);
                DropDownList POI = (e.Row.FindControl("ddlPoiType") as DropDownList);

                dspoi = ITSec.GetPOIValues();
                ds = ITSec.GetVariableDetails_selfreg(Convert.ToInt32(Resources.ITSecurity.CircleVariableValue));

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    Circle.DataSource = ds.Tables[0];
                    Circle.DataTextField = ds.Tables[0].Columns["Variable_Name"].ToString();
                    Circle.DataValueField = ds.Tables[0].Columns["Variable_Name"].ToString();
                    Circle.DataBind();
                    Circle.Items.Insert(0, new ListItem(Resources.ITSecurity.SelectText, Resources.ITSecurity.SelectText));
                    Circle.SelectedIndex = 0;
                }
                else
                {
                    Circle.Items.Insert(0, new ListItem(Resources.ITSecurity.SelectText, Resources.ITSecurity.SelectText));
                    Circle.SelectedIndex = 0;
                }

                if (dspoi != null && dspoi.Tables.Count > 0 && dspoi.Tables[0].Rows.Count > 0)
                {
                    POI.DataSource = dspoi.Tables[0];
                    POI.DataTextField = dspoi.Tables[0].Columns["POI_NAME"].ToString();
                    POI.DataValueField = dspoi.Tables[0].Columns["POI_NAME"].ToString();
                    POI.DataBind();
                    POI.Items.Insert(0, new ListItem(Resources.ITSecurity.SelectText, Resources.ITSecurity.SelectText));
                    POI.SelectedIndex = 0;
                }
                else
                {
                    POI.Items.Insert(0, new ListItem(Resources.ITSecurity.SelectText, Resources.ITSecurity.SelectText));
                    POI.SelectedIndex = 0;
                }

            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label UserSubType = e.Row.FindControl("lblUserSubType") as Label;
                Label Circle = e.Row.FindControl("lblCircle") as Label;
                Label Gender = e.Row.FindControl("lblGender") as Label;
                Label POIType = e.Row.FindControl("lblPOIType") as Label;
                Label PhyAccess = e.Row.FindControl("lblPhysicalAccess") as Label;
                Label Worked = e.Row.FindControl("lblWoked") as Label;
                if (UserSubType == null)
                {
                    UserSubType.Text = "Select";
                }
                else
                {
                    if (UserSubType.Text == "Select")
                    {
                        UserSubType.Text = "";
                    }

                }
                if (Circle == null)
                {
                    Circle.Text = "Select";
                }
                else
                {
                    if (Circle.Text == "Select")
                    {
                        Circle.Text = "";
                    }

                }
                if (Gender == null)
                {
                    Gender.Text = "Select";
                }
                else
                {
                    if (Gender.Text == "Select")
                    {
                        Gender.Text = "";
                    }
                }
                if (POIType == null)
                {
                    POIType.Text = "Select";
                }
                else
                {
                    if (POIType.Text == "Select")
                    {
                        POIType.Text = "";
                    }
                }
                if (PhyAccess == null)
                {
                    PhyAccess.Text = "Select";
                }
                else
                {
                    if (PhyAccess.Text == "Select")
                    {
                        PhyAccess.Text = "";
                    }
                }
                if (Worked == null)
                {
                    Worked.Text = "Select";
                }
                else
                {
                    if (Worked.Text == "Select")
                    {
                        Worked.Text = "";
                    }
                }
            }
        }
        catch (Exception ex)
        {
            //CreateLogFiles.CreateErrorLogEntry("BindPOIValues", ex.ToString());

        }
    }
}
