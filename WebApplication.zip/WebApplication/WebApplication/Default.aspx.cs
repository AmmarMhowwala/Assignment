﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            if ((txtUserName.Text=="Test") && (txtPassword.Text=="123"))
            {
                Session["id"] = txtUserName.Text;
                Response.Redirect("Upload.aspx");
                Session.RemoveAll();
                
            }
            else
            {
                Label1.Text = "your username and Password is incorrect";
                Label1.ForeColor = System.Drawing.Color.Red;

            }  
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtUserName.Text = "";
            txtPassword.Text = "";
            Label1.Text = "";
        }
    }
}