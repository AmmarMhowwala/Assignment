﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace CreateList
{
    class Program
    {
        static void Main(string[] args)
        {
            string webUrl = string.Empty;
            string listName = string.Empty;
            string password = string.Empty;
            string username = string.Empty;
           
            string domain = string.Empty;
            webUrl = ConfigurationManager.AppSettings["WebUrl"];
            listName = ConfigurationManager.AppSettings["ListName"];
            password = ConfigurationManager.AppSettings["Password"];
            username = ConfigurationManager.AppSettings["UserName"];
            domain = ConfigurationManager.AppSettings["Domain"];

            CreateList(webUrl, listName,username,password,domain);
        }
        static void CreateList(string webUrl, string listName, string userName, string password, string domain)
        {
            NetworkCredential credentials =
                           new NetworkCredential(userName, password, domain);
            ClientContext context = new ClientContext(webUrl);
            context.Credentials = credentials;
            Web web = context.Web;
            //provide the list creation information as Title and Description  
            ListCreationInformation createlist = new ListCreationInformation();
            createlist.Title = listName;
            createlist.Description = "My Attachment List";
            //choose a template as Generic List.  
            createlist.TemplateType = (int)ListTemplateType.GenericList;
            //add list to SharePoint  
            web.Lists.Add(createlist);
            context.ExecuteQuery();
            Console.WriteLine("List Created");
            Console.ReadKey();  
        }
    }
}
