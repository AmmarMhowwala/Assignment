﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ReadAttachment
{
    class Program
    {
        static void Main(string[] args)
        {
            string webUrl = string.Empty;
            string listName = string.Empty;
            string password = string.Empty;
            string username = string.Empty;
            string path=string.Empty;
            string domain = string.Empty;
            webUrl = ConfigurationManager.AppSettings["WebUrl"];
            listName = ConfigurationManager.AppSettings["ListName"];
            password = ConfigurationManager.AppSettings["Password"];
            username = ConfigurationManager.AppSettings["UserName"];
            domain = ConfigurationManager.AppSettings["Domain"];
            path = ConfigurationManager.AppSettings["FolderPath"];
            Download(webUrl, listName, username, password, domain,path);
            Console.ReadKey();
        }



         static void Download(string webUrl, string listName, string userName, string password, string domain, string path)
        {
            try
            {
              
                NetworkCredential credentials =
                           new NetworkCredential(userName, password, domain);

                using (ClientContext clientContext = new ClientContext(webUrl))
                {
                    Console.WriteLine("Started Attachment Download " + webUrl);

                    clientContext.Credentials = credentials;

                   
                    // Get the Web
                    Web oWeb = clientContext.Web;
                    clientContext.Load(oWeb);
                    clientContext.ExecuteQuery();

                    CamlQuery query = new CamlQuery();
                    query.ViewXml = @"";

                    List oList = clientContext.Web.Lists.GetByTitle(listName);
                    clientContext.Load(oList);
                    clientContext.ExecuteQuery();

                    ListItemCollection items = oList.GetItems(query);
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    foreach (ListItem listItem in items)
                    {
                        int id=Convert.ToInt32(listItem["ID"]);
                       
                            Console.WriteLine("Process Attachments for ID " +
                                  listItem["ID"].ToString());

                            Folder folder =
                                  oWeb.GetFolderByServerRelativeUrl(webUrl + "/Lists/" + listName + "/Attachments/" + listItem["ID"]);

                            clientContext.Load(folder);
                            if (listItem["Attachments"].ToString() == "True")
                            {

                                try
                                {
                                    clientContext.ExecuteQuery();
                                    FileCollection attachments = folder.Files;
                                    clientContext.Load(attachments);
                                    clientContext.ExecuteQuery();

                                    foreach (Microsoft.SharePoint.Client.File oFile in folder.Files)
                                    {


                                        Console.WriteLine("Found Attachment for ID " +
                                              listItem["ID"].ToString());

                                        FileInfo myFileinfo = new FileInfo(oFile.Name);
                                        WebClient client1 = new WebClient();
                                        client1.Credentials = credentials;


                                        Console.WriteLine("Downloading " +
                                              oFile.ServerRelativeUrl);

                                        byte[] fileContents =
                                              client1.DownloadData(webUrl +
                                              oFile.ServerRelativeUrl);
                                        FileStream fStream = new FileStream(@path + "\\" + listItem["Title"].ToString() + "_" + oFile.Name, FileMode.Create);

                                        fStream.Write(fileContents, 0, fileContents.Length);
                                        fStream.Close();
                                    }
                                    DeleteAttachmentFiles(clientContext, listName, id);
                                }
                                catch (ServerException ex)
                                {
                                    Console.WriteLine(ex.Message);
                                    Console.WriteLine("No Attachment for ID " + listItem["ID"].ToString());
                                }

                            }
                            else
                            {
                                Console.WriteLine("No Attachment for ID " + listItem["ID"].ToString());
                            }
                        }
                    }
                
            }
            catch (Exception e)
            {
              
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
            }
        }

         public static void DeleteAttachmentFiles(ClientContext context, string listTitle, int listItemId)
         {
             var list = context.Web.Lists.GetByTitle(listTitle);
             var listItem = list.GetItemById(listItemId);
             context.Load(listItem, li => li.AttachmentFiles);
             context.ExecuteQuery();
             listItem.AttachmentFiles.ToList().ForEach(a => a.DeleteObject());
             context.ExecuteQuery();
         }
    }
}
