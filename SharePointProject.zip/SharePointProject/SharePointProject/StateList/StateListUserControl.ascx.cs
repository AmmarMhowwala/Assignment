﻿using Microsoft.SharePoint;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace SharePointProject.StateList
{
    public partial class StateListUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                SPSite site = SPContext.Current.Site;


                using (SPWeb web = site.OpenWeb())
                {

                    SPList list = web.Lists["Country"];

                    ddlCountry.DataSource = list.Items;
                    ddlCountry.DataValueField = "Title";
                    ddlCountry.DataTextField = "Title";
                    ddlCountry.DataBind();
                    string value = ddlCountry.SelectedValue;
                    Bindgrid(web, value);

                }
            }
        }

        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            SPSite site = SPContext.Current.Site;
            using (SPWeb web = site.OpenWeb())
            {
            Bindgrid(web,ddlCountry.SelectedValue);
            }
        }

        void Bindgrid(SPWeb web, string value)
        {
            SPList listState = web.Lists["State"];
            var query = new SPQuery();

            query.ViewFields =
               "<FieldRef Name='Title' />" +
               "<FieldRef Name='Country' />";

            query.Query =

               "<Where>" +
               " <Eq>" +
               " <FieldRef Name='Country' />" +
               " <Value Type='Lookup'>" + value + "</Value>" +
               " </Eq>" +
               "</Where>";
            SPListItemCollection spListItemCollection = listState.GetItems(query);
            grdState.DataSource = spListItemCollection.GetDataTable();
            grdState.DataBind();
        }
    }
}
