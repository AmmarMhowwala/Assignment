﻿$(document).ready(function () {
   

    $(function () {
        
        var values = $("#DefectDtls").val();

        if (values != undefined && values != "") {

            var obj = JSON.parse(values);

            var dataArrayFinal = Array();

            for (j = 0; j < obj.length; j++) {
                var temp = new Array(obj[j].name, parseInt(obj[j].y));
                dataArrayFinal[j] = temp;

            }
           

            $('#divDefectDtls').highcharts({
                chart: {
                    type: 'pie',

                    options3d: {
                        enabled: true,
                        // alpha: 15,
                        // beta: 15,
                        depth: 50,
                        viewDistance: 20
                    }
                },
                title: {
                    text: 'Defect Dashboard'
                },

                xAxis: {
                    type: 'Type of Defects',
                    max: dataArrayFinal.length - 1,
                    title: {
                        text: ""
                    }
                },

                yAxis: {
                    title: {
                        text: 'No. of Defects'
                    }
                },
                tooltip: {
                    headerFormat: '<b><span style="color:{series.color}">\u25CF</span> Application: {point.key}</b><br>',
                    pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.Application}:<b>{point.percentage:.1f}%</b>'
                },

                subtitle: {

                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                            style: {
                                color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                            }
                        }
                    }
                    
                },
                series: [{
                    name: 'Defects',
                    data: dataArrayFinal,
                    pointWidth: 27,
                    groupPadding: 0


                }]
            });

        }
        else {

            $("#divDefectDtls").append('<div id="msgBox"  class="text-center"  style="height:100%; width:100%"><label for="name"><br/><br/><br/><h4>No data to display</h4></label></div>');
            
       
            

        }
    });


  $('#divDefectDtls').click(function(e) {
  
       
        var causal = $("#masterData").val();
         var dropdownchange= $("#DropdownChange").val();
         if(dropdownchange=="true")
         causal=undefined;
        $("#divDefectDtls").hide();
        $("divDefectGraph").addClass("graphStyle");
        $("#btnGetInfo").hide();
        $("#grdGetInfo").hide();
        $("#grdDiv").hide();
         
     var baData = [];
     var sitData = [];
     var vfQaData = [];
     var uatData = [];
     var postProdData = [];
    

     var categories=[];
     var colors = Highcharts.getOptions().colors;
     
   //  var values = $("#masterData").val();
    
    // var total_result = result.split('---break---');
    if(causal !=undefined && causal !="")
     var defect_result = causal.split('---');
      
        else
        var defect_result="";

//         var applicationName;
//          applicationName = obj[d].Application;
        if (causal != undefined && causal != "") 
        {
        debugger;
           for (fr = 0; fr < defect_result.length; fr++)
        {
         
            if (defect_result[fr] != undefined && defect_result[fr] != "")
            {
                var obj = JSON.parse(defect_result[fr])
               
                for (fd = 0; fd < obj.length; fd++)
                 {
                 
                    var a = categories.indexOf(obj[fd].Causal);
                    if(a==-1)
                    categories.push(obj[fd].Causal);
                    if (obj[fd].name == "BA Defects") 
                    {
                        baData.push({
                            name: obj[fd].name,
                            y: obj[fd].y,
                        });
                    }
                 
                    if (obj[fd].name == "SIT Defects")
                     {
                        sitData.push({
                            name: obj[fd].name,
                            y: obj[fd].y,
                        });
                    }
                  
                    if (obj[fd].name == "VF-QA Defects")
                     {
                        vfQaData.push({
                            name: obj[fd].name,
                            y: obj[fd].y,
                        });
                    }
                 
                    if (obj[fd].name == "UAT Defects")
                     {
                        uatData.push({
                            name: obj[fd].name,
                            y: obj[fd].y,
                        });
                    }
                 
                    if (obj[fd].name == "POST PROD Defects") 
                    {
                        postProdData.push({
                            name: obj[fd].name,
                            y: obj[fd].y,
                        });
                    }
                
                   
               } 
           }
        }
   

        //chart
         $('#divDefectGraph').highcharts({
        //Highcharts.chart('divDefectGraph', {
            chart: {
            
                type: 'column',
                height:580,
                options3d: {
                enabled: true,
              
                beta: 15
               // viewDistance: 25,
              
                }
            },
            title: {
                text: 'Causal wise Defect Analysis'
            },
            xAxis: {
                categories: categories
//                 labels: {
//            staggerLines: 2
//            }
                },
            yAxis: {
                min: 0,
                title: {
                    text: 'Total Number of Defects'
               }//,
//                stackLabels: {
//                    enabled: true,
//                    style: {
//                        fontWeight: 'bold',
//                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
//                    }
//                }
            },
            legend: {
            
        reversed: true
    
//                align: 'right',
//                x: -30,
//                verticalAlign: 'top',
//                y: 25,
//                floating: true,
//                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
//                borderColor: '#CCC',
//                borderWidth: 1,
//                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b><br/>',
                pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
            },
            plotOptions: {
                series: {
                    stacking: 'normal',
//                    dataLabels: {
//                        enabled: true,
//                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
//                    }
                  events: {
                            legendItemClick: function () {
                               return false;
                         }
                      }
                }
               
            },
            series: [{
                 name: 'BA Defects',
                 color: colors[0],
                 data: baData
            }, 
            {
                name: 'SIT Defects',
                color: colors[1],
                 data: sitData
            }, 
            {
                name: 'UAT Defects',
                color: colors[2],
                 data: uatData
            }, 
            {
                name: 'VF-QA Defects',
                color: colors[3],
                 data: vfQaData
            },
             {
                name: 'POST PROD Defects',
                color: colors[4],
                 data: postProdData
            }]
        });
         }
        else
        {
               $("#divDefectGraph").append('<div id="msgBox"  class="text-center"  style="height:100%; width:100%"><label for="name"><br/><br/><br/><h4>No data to display</h4></label></div>'); 
        }

    });
   
});

