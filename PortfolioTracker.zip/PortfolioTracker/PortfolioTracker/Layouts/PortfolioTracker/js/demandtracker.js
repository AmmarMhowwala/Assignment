﻿//var month=[];
$(document).ready(function () {
    debugger;
    $(function () {


        var values1 = $("#TotalDemands").val();
        var app = $("#Application").val();

        if (values1 != undefined && values1 != "") {
            var obj = JSON.parse(values1)    
            $('#demandschart').highcharts({
                chart: {
                    type: 'column',

                    options3d: {
                        enabled: true,
                        // alpha: 15,
                        // beta: 15,
                        depth: 50,
                        viewDistance: 25
                    }
                },
                title: {
                    text: 'CR-Demand Month Wise Count'
                },

                xAxis: {

                    categories: ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec','Jan', 'Feb', 'Mar' ]
                },

                yAxis: {
                    allowDecimals: false,
                    min: 0,
                    title: {
                        text: 'No. of CR-Demands Deployed'
                    }
                },
                tooltip: {
                    headerFormat: '<b><span style="color:{series.color}">\u25CF</span> Month: {point.key}</b><br>',
                    pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: {point.y}'
                },

                subtitle: {

                },
                plotOptions: {
                    column: {
                        stacking: 'normal',
                        depth: 25,

                       events: {
                            legendItemClick: function () {
                               return false;
                         }
                      }
                    }
                },


                series: getseries(obj, app)

            });

        }
        else {
            $("#demandschart").append('<div id="msgBox"  class="text-center"  style="height:100%; width:100%"><label for="name"><br/><br/><br/><h4>No data to display</h4></label></div>');
        }
    });

    function getseries(obj, app) {
        var series = [];
        for (i = 0; i < obj.length; i++) {
            console.log(obj[i].Count);
            if (app.toLowerCase() == "all") {

                var tempseries = {
                    name: obj[i].Application,
                    data: strSplit(obj[i].Count)
                }
                series.push(tempseries);
            }
            else {
                if (app.toUpperCase() == obj[i].Application.toUpperCase()) {

                    var tempseries = {
                        name: obj[i].Application,
                        data: strSplit(obj[i].Count)
                    }
                    series.push(tempseries);
                }
            }
        }
        console.log(series);
        return series;
    }

    function strSplit(str) {
        str = str.toString();

        var strArr = str.split(',');
        var intArr = [];
        for (var i = 0; i < strArr.length; i++)
            intArr.push(parseInt(strArr[i]));

        return intArr;
    }


}); 