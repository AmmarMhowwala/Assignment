﻿//$(document).ready(function () {
//    $('.main').css('height', $(window).height());
//    $('.main').css('width', $(window).width());
//    $('.leftSec').css('height', $(window).height());
//});
//$(window).resize(function () {
//    $('.main').css('height', $(window).height());
//    $('.main').css('width', $(window).width());
//    $('.leftSec').css('height', $(window).height());

//});
function preventDefault() {
    window.history.forward();
}   

//function popup(title, url) {

//    var options = SP.UI.$create_DialogOptions();

//    options.title = title;
//    options.width = 400;
//    options.height = 600;
//    options.url = url;

//    SP.UI.ModalDialog.showModalDialog(options);

//   

////}
//function portal_modalDialogClosedCallback(TITLE, URL) {
//    var options = SP.UI.$create_DialogOptions();
//    options.width = 800;
//    options.height = 600;
//    options.allowMaximize = false;
//    options.title = TITLE;
//    options.url = URL;
//    options.dialogReturnValueCallback = Function.createDelegate(null, portal_modalDialogClosedCallback);
//    SP.UI.ModalDialog.showModalDialog(options);
//}