﻿
$(document).ready(function () {

    $(function () {

        var values = $("#TotalEfforts").val();
        var values1 = $("#ApplicationEfforts").val();
        var applicationName = $("#ApplicationName").val();
        var values2 = $("#RoleWiseEfforts").val();
        var CRDemandNo = $("#CRDemandNo").val();


        if (values != undefined && values != "") {
            if (values != "null") {
                var obj = JSON.parse(values)
                var Application;
                var TotalEfforts = Array();
                var dataArrayFinal = [];
                var drilldowndata;
                var currentPage;


                for (j = 0; j < obj.length; j++) {

                    //var temp = new Array(obj[j].Application, parseFloat(obj[j].TotalEfforts), true);
                    var temp = { name: obj[j].Application, y: parseFloat(obj[j].TotalEfforts), drilldown: obj[j].DrillDown };
                    //dataArrayFinal[j] = temp;
                    dataArrayFinal.push(temp);

                }


                $('#effortsChart').highcharts({


                    chart: {
                        type: 'pie',
                        events: {
                            drilldown: function (e) {

                                if (!e.seriesOptions) {
                                    var chart = this;
                                    var category = this.options.series[0].name;
                                    document.getElementById('grdGetInfo').style.display = "none";
                                    Application = e.point.name;

                                    chart.showLoading('simulating');
                                    currentPage = "DrillDownPage";
                                    drilldowndata = FetchDrillDownData(e.point.name);
                                    chart.setTitle({
                                        text: e.point.name + " category wise data"
                                    });
                                    

                                    //                                drilldowns = {
                                    //                                    Application: {
                                    //                                        name: e.point.name,
                                    //                                        data: drilldowndata
                                    //                                    }
                                    //                                }

                                    data = {
                                        name: e.point.name,
                                        data: drilldowndata
                                    }
                                    //series = drilldowns[e.point.name];


                                    setTimeout(function () {
                                        chart.hideLoading();
                                        chart.addSeriesAsDrilldown(e.point, data);

                                    }, 1000);
                                }
                            },

                            drillup: function (e) {
                                var chart = this;
                                currentPage = "DrillUpPage";
                                chart.setTitle({ text: "Sharepoint Applications Efforts Dashboard" });
                                var empty = FetchDrillDownData(currentPage);
                                document.getElementById('grdGetInfo').style.display = "none";
                                

                            }
                        },
                        options3d: {
                            enabled: true,
                            // alpha: 15,
                            // beta: 15,
                            depth: 50,
                            viewDistance: 20
                        }
                    },
                    colors: ['#0000FF', '#0066FF', '#00CCFF'],
                    title: {
                        text: 'Sharepoint Applications Efforts Dashboard'
                    },

                    xAxis: {
                        type: 'category',
                        max: dataArrayFinal.length - 1,
                        title: {
                            text: ""
                        }
                    },

                    yAxis: {
                        title: {
                            text: 'Efforts in PDs'
                        }
                    },
                    tooltip: {
                        headerFormat: '<b><span style="color:{series.color}">\u25CF</span> Category: {point.key}</b><br>',
                        pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.Application}:<b>{point.percentage:.1f}%</b>'
                    },

                    subtitle: {

                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                                style: {
                                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                                }
                            }
                        }
                    },
                    series: [{
                        name: 'Efforts',
                        data: dataArrayFinal,
                        pointWidth: 27,
                        groupPadding: 0


                    }],

                    drilldown: {
                        series: []


                    }

                });

            }
            else {
                //dataArrayFinalApp = null;
                dataArrayFinal = null;
                //dataArrayFinalRole = null;
                $("#effortsChart").append('<div id="msgBox"  class="text-center"  style="height:100%; width:100%"><label for="name"><br/><br/><br/><h4>No data to display</h4></label></div>');
                //$("#barchartRenewal").children().bind('click', function () { return false; });
            }
        }


        else if (values1 != undefined && values1 != "") {
            if (values1 != "null") {
                var obj = JSON.parse(values1)
                var Application = Array();
                var TotalEfforts = Array();
                var dataArrayFinalApp = Array();

                for (j = 0; j < obj.length; j++) {

                    var temp = new Array(obj[j].CRDemandNo, parseFloat(obj[j].TotalEfforts));
                    dataArrayFinalApp[j] = temp;
                }


                $('#effortsChart').highcharts({
                    chart: {
                        type: 'pie',

                        options3d: {
                            enabled: true,
                            // alpha: 15,
                            // beta: 15,
                            depth: 50,
                            viewDistance: 20
                        }
                    },
                    title: {
                        text: applicationName + ' Efforts Dashboard'
                    },

                    xAxis: {
                        type: 'category',
                        max: dataArrayFinalApp.length - 1,
                        title: {
                            text: ""
                        }
                    },

                    yAxis: {
                        title: {
                            text: 'Efforts in PDs'
                        }
                    },
                    tooltip: {
                        headerFormat: '<b><span style="color:{series.color}">\u25CF</span> CR/Demand No: {point.key}</b><br>',
                        pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.CRDemandNo}:<b>{point.percentage:.1f}%</b>'
                    },

                    subtitle: {

                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                                style: {
                                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                                }
                            }
                        }
                    },

                    series: [{
                        name: 'Efforts',
                        data: dataArrayFinalApp,
                        pointWidth: 27,
                        groupPadding: 0


                    }]
                });

            }

            else {
                dataArrayFinalApp = null;
                // dataArrayFinal = null;
                // dataArrayFinalRole = null;
                $("#effortsChart").append('<div id="msgBox"  class="text-center"  style="height:100%; width:100%"><label for="name"><br/><br/><br/><h4>No data to display</h4></label></div>');
                //$("#barchartRenewal").children().bind('click', function () { return false; });
            }
        }
        else if (values2 != undefined && values2 != "") {
            if (values2 != "null") {
                var obj1 = JSON.parse(values2)
                var Application = Array();
                var TotalEfforts = Array();
                var dataArrayFinalRole = Array();

                for (j = 0; j < obj1.length; j++) {

                    var temp = new Array(obj1[j].Category, parseFloat(obj1[j].Efforts));
                    dataArrayFinalRole[j] = temp;
                }


                $('#effortsChart').highcharts({
                    chart: {
                        type: 'pie',

                        options3d: {
                            enabled: true,
                            // alpha: 15,
                            // beta: 15,
                            depth: 50,
                            viewDistance: 20
                        }
                    },
                    title: {
                        text: CRDemandNo + ' Efforts Dashboard'
                    },

                    xAxis: {
                        type: 'category',
                        max: dataArrayFinalRole.length - 1,
                        title: {
                            text: ""
                        }
                    },

                    yAxis: {
                        title: {
                            text: 'Efforts in PDs'
                        }
                    },
                    tooltip: {
                        headerFormat: '<b><span style="color:{series.color}">\u25CF</span> Category: {point.key}</b><br>',
                        pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.Role}:<b>{point.percentage:.1f}%</b>'
                    },

                    subtitle: {

                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                                style: {
                                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                                }
                            }
                        }
                    },
                    series: [{
                        name: 'Efforts',
                        data: dataArrayFinalRole,
                        pointWidth: 27,
                        groupPadding: 0


                    }]
                });

            }
            else {
                // dataArrayFinalApp = null;
                // dataArrayFinal = null;
                // dataArrayFinalRole = null;
                $("#effortsChart").append('<div id="msgBox"  class="text-center"  style="height:100%; width:100%"><label for="name"><br/><br/><br/><h4>No data to display</h4></label></div>');
                //$("#barchartRenewal").children().bind('click', function () { return false; });
            }
        }
        else {
            dataArrayFinalApp = null;
            dataArrayFinal = null;
            dataArrayFinalRole = null;
            $("#effortsChart").append('<div id="msgBox"  class="text-center"  style="height:100%; width:100%"><label for="name"><br/><br/><br/><h4>No data to display</h4></label></div>');
            //$("#barchartRenewal").children().bind('click', function () { return false; });
        }




    });

});

function FetchDrillDownData(app) {
    var drilldownArray = [];
    var inputArray = JSON.stringify({ category: name });
    var inputArra2 = "{category:'" + name + "'}";
    //PageMethods.GetDrillDownData1(e, success, failure)
    $.ajax({
        type: "POST",
        url: "EffortsManagement.aspx/GetDrillDownData1",
        data: '{category:"' + app + '"}',
        dataType: "json",
        contentType: "application/json",
        success: function (Result) {
           
            // Result = Result.d;
            var obj3 = JSON.parse(Result.d);
            for (j = 0; j < obj3.length; j++) {
             
                //var temp = new Array(obj[j].Application, parseFloat(obj[j].TotalEfforts), true);
                var temp = { name: obj3[j].Category, y: parseFloat(obj3[j].TotalEfforts)};
                //dataArrayFinal[j] = temp;
                drilldownArray.push(temp);

            }
        },
        error: function (Result) {
            alert("error " + result);
        }
    })
    return drilldownArray;

}