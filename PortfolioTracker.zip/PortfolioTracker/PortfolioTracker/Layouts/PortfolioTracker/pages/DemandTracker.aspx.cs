﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Data;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web;
using System.Linq;
using System.Web.Script.Serialization;
using System.Text;
using System.Web.UI;





namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
    public partial class DemandTracker : LayoutsPageBase
    {
        string userRole = string.Empty;
        string userName = string.Empty;
        DataTable userSession = new DataTable();
        BusinessClass userstore = new BusinessClass();
        string portfolioId = string.Empty;
        static string CurrentPage = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserDetails"] == null)
            {
                Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/ErrorPage.aspx");
            }
            if (!IsPostBack)
            {
                if (Session["UserDetails"] != null)
                {
                    userSession = (DataTable)Session["UserDetails"];
                    if (userSession != null)
                    {
                        if (userSession.Rows.Count > 0)
                        {
                            userRole = userSession.Rows[0]["Role"].ToString();
                            userName = userSession.Rows[0]["Name"].ToString();
                            portfolioId = userSession.Rows[0]["Title"].ToString();

                            lblloggedInUser.Text = "Welcome," + userName + " | " + userRole;
                        }
                    }
                    //BindYearDropdown();
                }
                //Session["PortfolioID"] = "1";
                //if (Session["PortfolioID"] != null)
                //{
                //    portfolioId = Session["PortfolioID"].ToString();
                //}
                BindPortfolio();
                btnInfo.Visible = false;
            }
        }
        protected void BindPortfolio()
        {

            DataTable portfolioOptions = userstore.FetchPortfolioData(portfolioId);
            ddlPortfolio.Items.Clear();
            ddlPortfolio.Items.Add("Select");

            if (ddlPortfolio != null)
            {
                if (portfolioOptions.Rows.Count > 0)
                {
                    foreach (DataRow dr in portfolioOptions.Rows)
                    {
                        ddlPortfolio.Items.Add(new ListItem(dr[0].ToString()));

                    }

                    ddlPortfolio.SelectedIndex = 0;
                }
            }
            ListItem item = new ListItem("Select");
            ddlApplication.Items.Insert(0, item);
        }
        protected void portfoliochanged(object sender, EventArgs e)
        {
            Session["DefectCausalData"] = null;
            BindApplication();
            btnInfo.Visible = false;
            grdinfo.Visible = false;


        }
        protected void applicationchanged(object sender, EventArgs e)
        {
            Session["DefectCausalData"] = null;
            btnInfo.Visible = false;
            grdinfo.Visible = false;


        }
        protected void BindApplication()
        {
            try
            {

                
                ddlApplication.Items.Clear();
                ddlApplication.Items.Insert(0, "Select");

                if (ddlPortfolio.SelectedValue.ToString() != "Select")
                {
                    DataTable applicationOptions = userstore.FetchApplicationData(ddlPortfolio.SelectedValue.ToString());
                    if (ddlApplication != null)
                    {
                        ddlApplication.Items.Add("All");
                        if (applicationOptions.Rows.Count > 0)
                        {
                            foreach (DataRow dr in applicationOptions.Rows)
                            {
                                ddlApplication.Items.Add(new ListItem(dr[0].ToString()));

                            }

                            ddlApplication.SelectedIndex = 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            { }
        }
        private string ddlSelectionCheck()
        {

            StringBuilder msg = new StringBuilder();
            try
            {
                if (ddlPortfolio.SelectedValue == "Select" || ddlApplication.SelectedValue == "Select")
                {
                    msg.Append("Please select dropdown values before proceeding.");
                }
                else
                {
                    msg.Append(string.Empty);
                }
            }
            catch (Exception ex) { }

            return msg.ToString();
        }
        //protected void btn_demandclick(Object sender, EventArgs e)
        //{
        //    string msg = ddlSelectionCheck();
        //    if(msg == string.Empty)
        //    {
        //    if (HttpContext.Current.Request.HttpMethod == "POST")
        //    {
        //        //if (ddlApplication.SelectedValue.ToString() == "All")
        //        //{

        //        string values = FetchAllDemandsforPortfolio(ddlPortfolio.SelectedValue.ToString());
        //        ClientScript.RegisterHiddenField("TotalDemands", values);
        //        ClientScript.RegisterHiddenField("Application", ddlApplication.SelectedValue);
        //        if (values == string.Empty)
        //        {
        //            btnInfo.Visible = false;
        //        }
        //        else
        //        {
        //            btnInfo.Visible = true;
        //            grdinfo.Visible = false;
        //        }

        //        //ClientScript.RegisterHiddenField("ApplicationName", ddlApplication.SelectedValue.ToString());
        //        // }
        //        //else if (ddlApplication.SelectedValue.ToString() != "All")
        //        //{
        //        //    FetchSingleApplicationData(ddlPortfolio.SelectedValue.ToString(), ddlApplication.SelectedValue.ToString());
        //        //}
        //    }
        //}
        //    else
        //    {
        //        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msg + "');</script>", false);
        //    }
        //}
        //protected void BindYearDropdown()
        //{
        //    btnInfo.Visible = false;
        //    grdinfo.Visible = false;
        //    CurrentPage = string.Empty;            
        //    ddlYear.Items.Clear();
        //    ddlYear.Items.Add("Select");
        //    Int32 currentYear = DateTime.Now.Year;
      
            
        //    int count = 5;
        //    while (count > 0)
        //    {
        //        ddlYear.Items.Add(new ListItem(currentYear.ToString()));
        //        currentYear--;
        //        count--;
        //    }
            
        //}

        protected void btn_demandclick(Object sender, EventArgs e)
        {
            string msg = ddlSelectionCheck();
            if (msg == string.Empty)
            {
                if (HttpContext.Current.Request.HttpMethod == "POST")
                {
                    //if (ddlApplication.SelectedValue.ToString() == "All")
                    //{

                    string values = FetchAllDemandsforPortfolio(ddlPortfolio.SelectedValue.ToString());
                    string val1 = ddlApplication.SelectedValue;

                    if (!values.Contains(val1) && val1.ToLower() != "all")
                    {
                        btnInfo.Visible = false;
                    }
                    else if (values == string.Empty)
                    {
                        btnInfo.Visible = false;
                    }
                    else
                    {
                        ClientScript.RegisterHiddenField("TotalDemands", values);
                        ClientScript.RegisterHiddenField("Application", ddlApplication.SelectedValue.ToString());
                        btnInfo.Visible = true;
                        grdinfo.Visible = false;
                    }




                    //ClientScript.RegisterHiddenField("ApplicationName", ddlApplication.SelectedValue.ToString());
                    // }
                    //else if (ddlApplication.SelectedValue.ToString() != "All")
                    //{
                    //    FetchSingleApplicationData(ddlPortfolio.SelectedValue.ToString(), ddlApplication.SelectedValue.ToString());
                    //}
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msg + "');</script>", false);
            }
        }
        
        protected string FetchAllDemandsforPortfolio(string Portfolio)
        {
            DataTable dtfinal = new DataTable();
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Int32 currentYear = DateTime.Now.Year;
            Int32 currentMonth = DateTime.Now.Month;
            if (currentMonth == 1 || currentMonth == 2 || currentMonth == 3)
            {
                currentYear--;
            }
            else
            {
            }
            DataTable allDemandsData = userstore.fetchAllDemandsPortfoilioWise(Portfolio,currentYear);
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            string result = string.Empty;

            if (allDemandsData != null)
            {
                allDemandsData.Columns.Add("MonthNum");
                allDemandsData.Columns.Add("Count", typeof(int));
                foreach (DataRow r in allDemandsData.Rows)
                {
                    if (r["GoLiveDate"] != null && r["GoLiveDate"].ToString() != string.Empty)
                        r["MonthNum"] = DateTime.Parse(r["GoLiveDate"].ToString()).ToString("MM");
                    else
                        r["MonthNum"] = "0";
                }
                var _result = from r1 in allDemandsData.AsEnumerable()
                              group r1 by new
                              {
                                  Application = r1.Field<string>("Application"),
                                  Portfolio = r1.Field<string>("Portfolio"),
                                  Month = r1.Field<string>("GoLiveMonth"),
                                  Month1 = r1.Field<string>("MonthNum")
                                  // Count = r1.Field<int>("Count")
                              }
                                  into g

                                  select new
                                  {
                                      Application = g.Key.Application,
                                      Portfolio = g.Key.Portfolio,
                                      Month = g.Key.Month,
                                      Month1 = g.Key.Month1,
                                      Count = g.Count()

                                  };
                DataTable dtnew = new DataTable();
                dtnew.Columns.Add("Application");
                dtnew.Columns.Add("Portfolio");
                dtnew.Columns.Add("Month");
                dtnew.Columns.Add("Count");
                dtnew.Columns.Add("MonthtNum");


                foreach (var item in _result)
                {
                    dtnew.Rows.Add(item.Application, item.Portfolio, item.Month, item.Count, item.Month1);
                }

                DataView view = new DataView(dtnew);
                DataTable distinctValues = view.ToTable(true, "Application");

                DataView dvSort = dtnew.DefaultView;
                dvSort.Sort = "MonthtNum asc";
                DataTable sortedDT = dvSort.ToTable();


                dtfinal.Columns.Add("Application");
                dtfinal.Columns.Add("Count");
                int zero = 0;

                string str = string.Empty;
                foreach (DataRow r in distinctValues.Rows)
                {
                    DataRow dtrowFinal = dtfinal.NewRow();
                    Dictionary<int, string> CountList = new Dictionary<int, string>();
                    foreach (DataRow r1 in sortedDT.Rows)
                    {
                        if (r["Application"].ToString().Trim() == r1["Application"].ToString().Trim())
                        {
                            // str = str + "," + r1["Count"].ToString();
                           

                            if (r1["MonthtNum"].ToString() == "04")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(4) && CountList[4].ToString() == "0")
                                {
                                    CountList[4] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(4, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(4))
                                {
                                    CountList.Add(4, zero.ToString());
                                }

                            }

                            if (r1["MonthtNum"].ToString() == "05")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(5) && CountList[5].ToString() == "0")
                                {
                                    CountList[5] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(5, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(5))
                                {
                                    CountList.Add(5, zero.ToString());
                                }

                            }

                            if (r1["MonthtNum"].ToString() == "06")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(6) && CountList[6].ToString() == "0")
                                {
                                    CountList[6] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(6, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(6))
                                {
                                    CountList.Add(6, zero.ToString());
                                }

                            }

                            if (r1["MonthtNum"].ToString() == "07")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(7) && CountList[7].ToString() == "0")
                                {
                                    CountList[7] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(7, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(7))
                                {
                                    CountList.Add(7, zero.ToString());
                                }

                            }

                            if (r1["MonthtNum"].ToString() == "08")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(8) && CountList[8].ToString() == "0")
                                {
                                    CountList[8] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(8, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(8))
                                {
                                    CountList.Add(8, zero.ToString());
                                }

                            }

                            if (r1["MonthtNum"].ToString() == "09")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(9) && CountList[9].ToString() == "0")
                                {
                                    CountList[9] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(9, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(9))
                                {
                                    CountList.Add(9, zero.ToString());
                                }

                            }

                            if (r1["MonthtNum"].ToString() == "10")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(10) && CountList[10].ToString() == "0")
                                {
                                    CountList[10] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(10, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(10))
                                {
                                    CountList.Add(10, zero.ToString());
                                }

                            }

                            if (r1["MonthtNum"].ToString() == "11")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(11) && CountList[11].ToString() == "0")
                                {
                                    CountList[11] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(11, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(11))
                                {
                                    CountList.Add(11, zero.ToString());
                                }

                            }

                            if (r1["MonthtNum"].ToString() == "12")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(12) && CountList[12].ToString() == "0")
                                {
                                    CountList[12] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(12, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(12))
                                {
                                    CountList.Add(12, zero.ToString());
                                }

                            }
                            if (r1["MonthtNum"].ToString() == "01")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(1) && CountList[1].ToString() == "0")
                                {
                                    CountList[1] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(1, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(1))
                                {
                                    CountList.Add(1, zero.ToString());
                                }

                            }




                            if (r1["MonthtNum"].ToString() == "02")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(2) && CountList[2].ToString() == "0")
                                {
                                    CountList[2] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(2, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(2))
                                {
                                    CountList.Add(2, zero.ToString());
                                }

                            }


                            if (r1["MonthtNum"].ToString() == "03")
                            {
                                // dtrowFinal["Count"] = r1["Count"].ToString() + ",";
                                if (CountList.ContainsKey(3) && CountList[3].ToString() == "0")
                                {
                                    CountList[3] = r1["Count"].ToString();
                                }
                                else
                                {
                                    CountList.Add(3, r1["Count"].ToString());
                                }

                            }
                            else
                            {
                                // dtrowFinal["Count"] = zero + ",";
                                if (!CountList.ContainsKey(3))
                                {
                                    CountList.Add(3, zero.ToString());
                                }

                            }
                        }


                    }

                    string CountValue = string.Empty;
                    foreach (int key in CountList.Keys)
                    {
                        if (key == 03)
                            CountValue += CountList[key].ToString();
                        else
                            CountValue += CountList[key].ToString() + ",";
                    }
                    dtrowFinal["Count"] = CountValue;
                    dtrowFinal["Application"] = r["Application"].ToString();
                    dtfinal.Rows.Add(dtrowFinal);
                }

                Dictionary<string, object> row;
                foreach (DataRow dr in dtfinal.Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (DataColumn col in dtfinal.Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }
                 result = serializer.Serialize(rows);
            }
            else 
            {
                result = string.Empty;
                btnInfo.Visible = false;
            }

            return result;
          
        
        }



        protected void FetchSingleApplicationData(string Portfolio, string application)
        {
            DataTable allDemandsData = userstore.fetchDemandApplicationData(Portfolio, application);
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();

            string portfolio = ddlPortfolio.SelectedValue.ToString();
            BusinessClass bclass = new BusinessClass();
            DataTable dtAllApps = bclass.FetchApplicationData(portfolio);

            DataView dvSingleAppData = allDemandsData.DefaultView;
            DataTable dtSingleAppData = new DataTable();
            dtSingleAppData.Columns.Add("Application");
            dtSingleAppData.Columns.Add("Month");
            dtSingleAppData.Columns.Add("Count", typeof(int));

            DataTable dtAllMonths = new DataTable();
            dtAllMonths.Columns.Add("Month");
            dtAllMonths.Rows.Add("Jan");
            dtAllMonths.Rows.Add("Feb");
            dtAllMonths.Rows.Add("Mar");
            dtAllMonths.Rows.Add("Apr");
            dtAllMonths.Rows.Add("May");
            dtAllMonths.Rows.Add("Jun");
            dtAllMonths.Rows.Add("Jul");
            dtAllMonths.Rows.Add("Aug");
            dtAllMonths.Rows.Add("Sep");
            dtAllMonths.Rows.Add("Oct");
            dtAllMonths.Rows.Add("Nov");
            dtAllMonths.Rows.Add("Dec");

            string serializedData = "";
            if (allDemandsData != null)
            {
                foreach (DataRow drMonth in dtAllMonths.Rows)
                {
                    dvSingleAppData.RowFilter = " GoLiveMonth = " + "'" + "" + drMonth["Month"].ToString() + "" + "'";
                    DataTable dt_Temp = dvSingleAppData.ToTable();
                    dtSingleAppData.Rows.Add(application, drMonth["Month"].ToString(), dt_Temp.Rows.Count);

                    dt_Temp.Clear();
                }
                //DataTable dtConverted = Convert(dtSingleAppData);


               
                //DataRow row = dtConverted.Rows[2];

                //var stringArray = row.ItemArray.Cast<string>().ToArray();

                //serializedData = serializer.Serialize(stringArray);


                var query = (from row in dtSingleAppData.AsEnumerable()
                             group row by new
                             {
                                 name = row.Field<string>("Month"),
                                 value = row.Field<int>("Count"),
                             } into g

                             select new
                             {
                                 name = g.Key.name,
                                 y = g.Key.value,

                             }).ToArray();

                if (query.Length > 0)
                {
                    serializedData = new JavaScriptSerializer().Serialize(query);
                }


                
            }
            else
            {
                serializedData = string.Empty;
                btnInfo.Visible = false;
            }
            ClientScript.RegisterHiddenField("SingleApplicationData", serializedData);

        }

        protected DataTable Convert(DataTable dtOriginal)
        {
            DataTable dt2 = new DataTable();
            for (int i = 0; i <= dtOriginal.Rows.Count; i++)
            {
                dt2.Columns.Add();
            }
            for (int i = 0; i < dtOriginal.Columns.Count; i++)
            {
                dt2.Rows.Add();
                dt2.Rows[i][0] = dtOriginal.Columns[i].ColumnName;
            }
            for (int i = 0; i < dtOriginal.Columns.Count; i++)
            {
                for (int j = 0; j < dtOriginal.Rows.Count; j++)
                {
                    dt2.Rows[i][j + 1] = dtOriginal.Rows[j][i];
                }
            }
            return dt2;
        }
        protected void imgbtnLogOut_Click(Object sender, EventArgs e)
        {
            Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/LogOut.aspx");
        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdinfo.PageIndex = e.NewPageIndex;
                this.BindGrid();
            }
            catch (Exception ex) { }
        }
        protected void btnInfo_Click(Object sender, EventArgs e)
        {
            grdinfo.PageIndex = 0;
            try
            {               
                BindGrid();
                grdinfo.Visible = true;
            }
            catch (Exception ex) { }
        }
        private void BindGrid()
        {
            DataTable dt = new DataTable();
            Int32 currentYear = DateTime.Now.Year;
            Int32 currentMonth = DateTime.Now.Month;
            if (currentMonth == 1 || currentMonth == 2 || currentMonth == 3)
            {
                currentYear--;
            }
            else
            {
            }
            try
            {
                dt = userstore.fetchDemandsGrid(ddlPortfolio.SelectedValue, ddlApplication.SelectedValue, currentYear);
                if (dt != null)
                {
                    grdinfo.DataSource = dt;
                    grdinfo.DataBind();
               
                grdinfo.Visible = true;
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
}
