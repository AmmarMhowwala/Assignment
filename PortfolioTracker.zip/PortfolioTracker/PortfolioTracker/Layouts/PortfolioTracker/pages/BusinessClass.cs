﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.Data;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Web.UI;



namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
    class BusinessClass
    {
        public DataTable FetchPortfolioData(string portfolioId)
        {
            DataTable portfolioOptions = new DataTable();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["PortfolioApplicationMaster"];
                        SPQuery oQuery = new SPQuery();

                        oQuery.ViewFields = "<FieldRef Name='Portfolio'/>";
                        oQuery.ViewFieldsOnly = true;
                        oQuery.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + portfolioId + "</Value></Eq></Where>";
                        DataTable dtcamltest = list.GetItems(oQuery).GetDataTable();
                        DataView dtview = new DataView(dtcamltest);
                        portfolioOptions = dtview.ToTable(true, "Portfolio");


                        //SPListItemCollection collListItems = list.GetItems(oQuery);
                        //portfolioOptions = collListItems.GetDataTable();
                    }
                }
            });
            return portfolioOptions;

        }

        public DataTable FetchApplicationData(string portfolio)
        {
            DataTable applications = new DataTable();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["PortfolioApplicationMaster"];
                        SPQuery oQuery = new SPQuery();

                        oQuery.ViewFields = "<FieldRef Name='Application'/>";
                        oQuery.ViewFieldsOnly = true;
                        oQuery.Query = "<Where><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + portfolio + "</Value></Eq></Where>";
                        applications = list.GetItems(oQuery).GetDataTable();




                        //SPListItemCollection collListItems = list.GetItems(oQuery);
                        //portfolioOptions = collListItems.GetDataTable();
                    }
                }
            });
            return applications;

        }

        public DataTable FetchAllDemandsData(string portfolio)
        {
            DataTable allDemands = new DataTable();

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["EffortsList"];
                        SPQuery oQuery = new SPQuery();

                        oQuery.ViewFields = "<FieldRef Name='CRDemandNo'/>";
                        oQuery.ViewFieldsOnly = true;
                        oQuery.Query = "<Where><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + portfolio + "</Value></Eq></Where>";
                        allDemands = list.GetItems(oQuery).GetDataTable();


                        //SPListItemCollection collListItems = list.GetItems(oQuery);
                        //portfolioOptions = collListItems.GetDataTable();
                    }
                }
            });
            return allDemands;


        }

        public DataTable FetchDemandsByApplication(string applicationName)
        {
            DataTable demands = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();

                            oQuery.ViewFields = "<FieldRef Name='CRDemandNo'/>";
                            oQuery.ViewFieldsOnly = true;
                            oQuery.Query = "<Where><Eq><FieldRef Name='Application'/><Value Type='Text'>" + applicationName + "</Value></Eq></Where>";
                            demands = list.GetItems(oQuery).GetDataTable();


                            //SPListItemCollection collListItems = list.GetItems(oQuery);
                            //portfolioOptions = collListItems.GetDataTable();
                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return demands;
        }

        public DataTable fetchAllEffortsPortfoilioWise(string Portfolio)
        {
            DataTable allEfforts = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();

                            oQuery.ViewFields = "<FieldRef Name='Application'/> <FieldRef Name='CRDemandNo'/> <FieldRef Name='TotalEfforts'/>";
                            oQuery.ViewFieldsOnly = true;
                            oQuery.Query = "<Where><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + Portfolio + "</Value></Eq></Where>";
                            allEfforts = list.GetItems(oQuery).GetDataTable();


                            //SPListItemCollection collListItems = list.GetItems(oQuery);
                            //portfolioOptions = collListItems.GetDataTable();
                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return allEfforts;

        }

        public DataTable fetchAllEffortsApplicationWise(string portfolio, string application)
        {
            DataTable Efforts = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();

                            oQuery.ViewFields = "<FieldRef Name='Application'/><FieldRef Name='GoLiveMonth'/>";
                            oQuery.ViewFieldsOnly = true;
                            oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + portfolio + "</Value></Eq><Eq><FieldRef Name='Application'/><Value Type='Text'>" + application + "</Value></Eq></And></Where>";
                            Efforts = list.GetItems(oQuery).GetDataTable();


                            //SPListItemCollection collListItems = list.GetItems(oQuery);
                            //portfolioOptions = collListItems.GetDataTable();
                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return Efforts;

        }

        public DataTable fetchAllDemandsPortfoilioWise(string Portfolio,int year)
        {
            DataTable allEfforts = new DataTable();
            int GoLiveyear = Convert.ToInt32(year);
            string startdate = string.Empty;
            string enddate = string.Empty;
            startdate = GoLiveyear + "-04-01";
            enddate = GoLiveyear + 1 + "-03-31";
            try
            {

                //SPSecurity.RunWithElevatedPrivileges(delegate()
                //{
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["EffortsList"];
                        SPQuery oQuery = new SPQuery();

                        oQuery.ViewFields = "<FieldRef Name='Application'/> <FieldRef Name='Portfolio'/> <FieldRef Name='GoLiveMonth'/> <FieldRef Name='GoLiveDate'/>";
                        oQuery.ViewFieldsOnly = true;
                        //oQuery.Query = "<Where><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + Portfolio + "</Value></Eq></Where>";
                        //oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + "</Value></Eq><And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate + "</Value></Geq><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate + "</Value></Leq></And></And></Where>";
                        oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Text'>" + Portfolio + "</Value></Eq><And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + startdate + "</Value></Geq><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + enddate + "</Value></Leq></And></And></Where>";
                        allEfforts = list.GetItems(oQuery).GetDataTable();
                        // allEfforts.Columns[2].ColumnName = "GoLiveDate";


                        //SPListItemCollection collListItems = list.GetItems(oQuery);
                        //portfolioOptions = collListItems.GetDataTable();
                    }
                }
                //});
            }
            catch (Exception ex)
            {
            }
            return allEfforts;

        }


        public DataTable fetchEffortsRoleWise(string portfolio, string application, string demandCR)
        {
            DataTable efforts = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();

                            oQuery.ViewFields = "<FieldRef Name='BAEfforts'/> <FieldRef Name='DeveloperEfforts'/><FieldRef Name='SITEfforts'/><FieldRef Name='SecurityEfforts'/>";
                            oQuery.ViewFieldsOnly = true;
                            oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + portfolio + "</Value></Eq><And><Eq><FieldRef Name='Application'/><Value Type='Text'>" + application + "</Value></Eq><Eq><FieldRef Name='CRDemandNo'/><Value Type='Text'>" + demandCR + "</Value></Eq></And></And></Where>";
                            efforts = list.GetItems(oQuery).GetDataTable();


                            //SPListItemCollection collListItems = list.GetItems(oQuery);
                            //portfolioOptions = collListItems.GetDataTable();
                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return efforts;
        }

        public DataTable fetchDataforGridView(string portfolio, string application, string dmNo, string year, List<ListItem> selected, string drilldownAppl,string currentPage)
        {
            DataTable dtGridViewData = new DataTable();
            string startdate1 = string.Empty;
            string enddate1 = string.Empty;
            string startdate2 = string.Empty;
            string enddate2 = string.Empty;
            try
            {
                int GoLiveyear = Convert.ToInt32(year);

                if (selected.Count == 0)
                {
                    startdate1 = GoLiveyear + "-04-01";
                    enddate1 = GoLiveyear + 1 + "-03-31";
                }

                if (selected.Count == 1)
                {
                    if (selected[0].ToString() == "Q1")
                    {
                        startdate1 = GoLiveyear + "-04-01";
                        // startdate1 = "4/1/" + GoLiveyear;
                        enddate1 = GoLiveyear + "-06-30";
                        //enddate1 = "6/30/" + GoLiveyear;
                    }

                    else if (selected[0].ToString() == "Q2")
                    {
                        startdate1 = GoLiveyear + "-07-1";
                        enddate1 = GoLiveyear + "-09-30";
                    }

                    else if (selected[0].ToString() == "Q3")
                    {
                        startdate1 = GoLiveyear + "-10-01";
                        enddate1 = GoLiveyear + "-12-31";
                    }

                    else if (selected[0].ToString() == "Q4")
                    {
                        startdate1 = GoLiveyear + 1 + "-01-01";
                        enddate1 = GoLiveyear + 1 + "-03-31";
                    }
                }



                if (selected.Count == 2)
                {
                    if (selected[0].ToString() == "Q1")
                    {
                        startdate1 = GoLiveyear + "-04-01";

                        if (selected[1].ToString() == "Q2")
                            enddate1 = GoLiveyear + "-09-30";

                        else if (selected[1].ToString() == "Q3")
                        {
                            enddate1 = GoLiveyear + "-06-30";
                            startdate2 = GoLiveyear + "-10-01";
                            enddate2 = GoLiveyear + "-12-31";
                        }
                        else
                        {
                            enddate1 = GoLiveyear + "-06-30";
                            startdate2 = GoLiveyear + 1 + "-01-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }

                    }

                    else if (selected[0].ToString() == "Q2")
                    {
                        startdate1 = GoLiveyear + "-07-01";

                        if (selected[1].ToString() == "Q3")
                            enddate1 = GoLiveyear + "-12-31";
                        else if (selected[1].ToString() == "Q4")
                        {
                            enddate1 = GoLiveyear + "-09-30";
                            startdate2 = GoLiveyear + 1 + "-01-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }
                    }

                    else if (selected[0].ToString() == "Q3")
                    {
                        startdate1 = GoLiveyear + "-10-01";

                        if (selected[1].ToString() == "Q4")
                            enddate1 = GoLiveyear + 1 + "-03-31";
                    }
                }

                if (selected.Count == 3)
                {
                    if (selected[0].ToString() == "Q1")
                    {
                        startdate1 = GoLiveyear + "-04-01";

                        if (selected[1].ToString() == "Q2" && selected[2].ToString() == "Q3")
                            enddate1 = GoLiveyear + "-12-31";

                        if (selected[1].ToString() == "Q3" && selected[2].ToString() == "Q4")
                        {
                            enddate1 = GoLiveyear + "-06-30";
                            startdate2 = GoLiveyear + "-10-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }

                        if (selected[1].ToString() == "Q2" && selected[2].ToString() == "Q4")
                        {
                            enddate1 = GoLiveyear + "-09-30";
                            startdate2 = GoLiveyear + 1 + "-01-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }

                    }

                    else if (selected[0].ToString() == "Q2")
                    {
                        startdate1 = GoLiveyear + "-07-01";
                        enddate1 = GoLiveyear + 1 + "-03-31";
                    }

                }

                if (selected.Count == 4)
                {
                    startdate1 = GoLiveyear + "-04-01";
                    enddate1 = GoLiveyear + 1 + "-03-31";

                }

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();

                            if (portfolio != "All" && application == "All" && dmNo == "All")
                            {
                                //oQuery.ViewFields = "<FieldRef Name='Application'/> <FieldRef Name='CRDemandNo'/> <FieldRef Name='TotalEfforts'/>";
                                //oQuery.ViewFieldsOnly = true;
                                if (startdate2 == string.Empty && enddate2 == string.Empty)
                                {
                                    if (currentPage == "DrillDownPage" && drilldownAppl!=string.Empty)
                                    {
                                        //if (drilldownAppl == string.Empty)
                                        //    oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + "</Value></Eq><And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + "</Value></Geq><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + "</Value></Leq></And></And></Where>";
                                        //else
                                            oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + @"</Value></Eq>
                                                <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + drilldownAppl + @"</Value></Eq>
                                                <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + "</Value></Leq></And></And></And></Where>";
                                    }
                                    else if(currentPage=="DrillUpPage" || currentPage==string.Empty)
                                        oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + "</Value></Eq><And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + "</Value></Geq><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + "</Value></Leq></And></And></Where>";
                                }
                                else
                                {
                                    if (currentPage == "DrillUpPage"|| currentPage==string.Empty)
                                        oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + @"</Value></Eq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                    <Or><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + @"</Value></Leq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate2 + @"</Value></Geq>
                                                    <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate2 + "</Value></Leq></And></Or></And></And></Where>";
                                    else if(currentPage == "DrillDownPage" && drilldownAppl!=string.Empty)
                                        oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + @"</Value></Eq>
                                                    <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + drilldownAppl + @"</Value></Eq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                    <Or><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + @"</Value></Leq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate2 + @"</Value></Geq>
                                                    <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + enddate2 + @"</Value></Leq></And></Or></And></And></And></Where>";

                                }
                                dtGridViewData = list.GetItems(oQuery).GetDataTable();

                            }
                            else if (portfolio != "All" && application != "All" && dmNo == "All")
                            {
                                //oQuery.ViewFields = "<FieldRef Name='CRDemandNo'/> <FieldRef Name='TotalEfforts'/>";
                                //oQuery.ViewFieldsOnly = true;
                                if (startdate2 == string.Empty && enddate2 == string.Empty)
                                    oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + @"</Value></Eq>
                                                <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                                <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + "</Value></Leq></And></And></And></Where>";
                                else
                                    oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + @"</Value></Eq>
                                                    <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                    <Or><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + @"</Value></Leq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate2 + @"</Value></Geq>
                                                    <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + enddate2 + @"</Value></Leq></And></Or></And></And></And></Where>";
                                dtGridViewData = list.GetItems(oQuery).GetDataTable();
                            }
                            else if (portfolio != "All" && application != "All" && dmNo != "All")
                            {
                                //oQuery.ViewFields = "<FieldRef Name='Application'/> <FieldRef Name='Portfolio'/> <FieldRef Name='GoLive_x0020_Date'/>";
                                //oQuery.ViewFieldsOnly = true;
                                if (startdate2 == string.Empty && enddate2 == string.Empty)
                                    oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + @"</Value></Eq>
                                            <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                            <And><Eq><FieldRef Name='CRDemandNo' /><Value Type='Text'>" + dmNo + @"</Value></Eq>
                                            <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                            <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + enddate1 + @"</Value></Leq></And></And></And></And></Where>";
                                else
                                    oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + @"</Value></Eq>
                                                <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                                <And><Eq><FieldRef Name='CRDemandNo' /><Value Type='Text'>" + dmNo + @"</Value></Eq>
                                                <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                <Or><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + @"</Value></Leq>
                                                <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate2 + @"</Value></Geq>
                                                <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate2 + @"</Value></Leq></And></Or></And></And></And></And></Where>";
                                dtGridViewData = list.GetItems(oQuery).GetDataTable();
                                // dtGridViewData.Columns[2].ColumnName = "GoLiveDate";
                            }

                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }

            return dtGridViewData;
        }

        public DataTable FetchDefects(string portfolio, string application, string demand, string type)
        {
            DataTable dt = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();
                            if (type == "1")
                            {
                                oQuery.ViewFields = "<FieldRef Name='BADefects'/><FieldRef Name='SITDefects'/><FieldRef Name='VFQADefects'/><FieldRef Name='UATDefects'/><FieldRef Name='PostProdDefects'/>";
                                oQuery.ViewFieldsOnly = true;
                            }
                            else if (type == "0")
                            {
                                oQuery.ViewFields = "<FieldRef Name='ID'/><FieldRef Name='Portfolio'/><FieldRef Name='Application'/><FieldRef Name='CRDemandNo'/><FieldRef Name='DeveloperAllocated'/><FieldRef Name='BADefects'/><FieldRef Name='SITDefects'/><FieldRef Name='VFQADefects'/><FieldRef Name='UATDefects'/><FieldRef Name='PostProdDefects'/><FieldRef Name='TotalDefects'/>";
                                oQuery.ViewFieldsOnly = true;
                            }
                            oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio'/><Value Type='Choice'>" + portfolio + "</Value></Eq><And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + "</Value></Eq><Eq><FieldRef Name='CRDemandNo' /><Value Type='Text'>" + demand + "</Value></Eq></And></And></Where>";
                            dt = list.GetItems(oQuery).GetDataTable();
                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return dt;
        }

        public DataTable getCausalAnalysisData(string portfolio, string application, string demand)
        {
            DataTable dt = new DataTable();
            DataTable dtCausal = new DataTable();
            string id = string.Empty;
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                        {
                            using (SPWeb web = site.OpenWeb())
                            {
                                SPList list = web.Lists["EffortsList"];
                                SPQuery oQuery = new SPQuery();
                                oQuery.ViewFields = "<FieldRef Name='ID'/>";
                                oQuery.ViewFieldsOnly = true;
                                oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio'/><Value Type='Choice'>" + portfolio + "</Value></Eq><And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + "</Value></Eq><Eq><FieldRef Name='CRDemandNo' /><Value Type='Text'>" + demand + "</Value></Eq></And></And></Where>";
                                dt = list.GetItems(oQuery).GetDataTable();
                                if (dt != null)
                                {
                                    if (dt.Rows.Count > 0)
                                    {
                                        id = dt.Rows[0]["ID"].ToString();
                                    }
                                }

                                SPList defectList = web.Lists["DefectDetails"];
                                SPQuery dQuery = new SPQuery();
                                dQuery.ViewFields = "<FieldRef Name='CausalAnalysis'/><FieldRef Name='Category'/>";
                                dQuery.ViewFieldsOnly = true;
                                dQuery.Query = "<Where><Eq><FieldRef Name='EffortListID'/><Value Type='Choice'>" + id + "</Value></Eq></Where>";
                                dtCausal = defectList.GetItems(dQuery).GetDataTable();
                            }
                        }
                    });
            }
            catch (Exception ex)
            {
            }
            return dtCausal;
        }

        public DataTable GetDefectInfo(string defectId)
        {
            DataTable dt = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["DefectDetails"];
                            SPQuery oQuery = new SPQuery();
                            oQuery.ViewFields = "<FieldRef Name='Title'/><FieldRef Name='CausalAnalysis'/><FieldRef Name='Severity'/><FieldRef Name='Category'/><FieldRef Name='Status'/>";
                            oQuery.ViewFieldsOnly = true;

                            oQuery.Query = "<Where><Eq><FieldRef Name='EffortListID' /><Value Type='Lookup'>" + defectId + "</Value></Eq></Where>";
                            dt = list.GetItems(oQuery).GetDataTable();
                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return dt;
        }

        public DataTable FetchUserDetails(string username)
        {
            DataTable userDetails = new DataTable();
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["UserList"];
                            SPQuery oQuery = new SPQuery();



                            // oQuery.ViewFields = "<FieldRef Name='BAEfforts'/><FieldRef Name='DeveloperEfforts'/><FieldRef Name='SITEfforts'/><FieldRef Name='SecurityEfforts'/><FieldRef Name='TotalEfforts'/>";
                            // oQuery.ViewFieldsOnly = true;
                            oQuery.Query = "<Where><Eq><FieldRef Name='UserName'/><Value Type='Text'>" + username + "</Value></Eq></Where>";
                            userDetails = list.GetItems(oQuery).GetDataTable();




                            //SPListItemCollection collListItems = list.GetItems(oQuery);
                            //portfolioOptions = collListItems.GetDataTable();
                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }

            return userDetails;
        }


        public DataTable fetchAllEffortsPortWise(string Portfolio, string application, string demandCR, string year, List<ListItem> selected)
        {
            DataTable allEfforts = new DataTable();
            string startdate1 = string.Empty;
            string enddate1 = string.Empty;
            string startdate2 = string.Empty;
            string enddate2 = string.Empty;
            try
            {

                int GoLiveyear = Convert.ToInt32(year);

                if (selected.Count == 0)
                {
                    startdate1 = GoLiveyear + "-04-01";
                    enddate1 = GoLiveyear + 1 + "-03-31";
                }

                if (selected.Count == 1)
                {
                    if (selected[0].ToString() == "Q1")
                    {
                        startdate1 = GoLiveyear + "-04-01";
                        // startdate1 = "4/1/" + GoLiveyear;
                        enddate1 = GoLiveyear + "-06-30";
                        //enddate1 = "6/30/" + GoLiveyear;
                    }

                    else if (selected[0].ToString() == "Q2")
                    {
                        startdate1 = GoLiveyear + "-07-1";
                        enddate1 = GoLiveyear + "-09-30";
                    }

                    else if (selected[0].ToString() == "Q3")
                    {
                        startdate1 = GoLiveyear + "-10-01";
                        enddate1 = GoLiveyear + "-12-31";
                    }

                    else if (selected[0].ToString() == "Q4")
                    {
                        startdate1 = GoLiveyear + 1 + "-01-01";
                        enddate1 = GoLiveyear + 1 + "-03-31";
                    }
                }



                if (selected.Count == 2)
                {
                    if (selected[0].ToString() == "Q1")
                    {
                        startdate1 = GoLiveyear + "-04-01";

                        if (selected[1].ToString() == "Q2")
                            enddate1 = GoLiveyear + "-09-30";

                        else if (selected[1].ToString() == "Q3")
                        {
                            enddate1 = GoLiveyear + "-06-30";
                            startdate2 = GoLiveyear + "-10-01";
                            enddate2 = GoLiveyear + "-12-31";
                        }
                        else
                        {
                            enddate1 = GoLiveyear + "-06-30";
                            startdate2 = GoLiveyear + 1 + "-01-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }

                    }

                    else if (selected[0].ToString() == "Q2")
                    {
                        startdate1 = GoLiveyear + "-07-01";

                        if (selected[1].ToString() == "Q3")
                            enddate1 = GoLiveyear + "-12-31";
                        else if (selected[1].ToString() == "Q4")
                        {
                            enddate1 = GoLiveyear + "-09-30";
                            startdate2 = GoLiveyear + 1 + "-01-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }
                    }

                    else if (selected[0].ToString() == "Q3")
                    {
                        startdate1 = GoLiveyear + "-10-01";

                        if (selected[1].ToString() == "Q4")
                            enddate1 = GoLiveyear + 1 + "-03-31";
                    }
                }

                if (selected.Count == 3)
                {
                    if (selected[0].ToString() == "Q1")
                    {
                        startdate1 = GoLiveyear + "-04-01";

                        if (selected[1].ToString() == "Q2" && selected[2].ToString() == "Q3")
                            enddate1 = GoLiveyear + "-12-31";

                        if (selected[1].ToString() == "Q3" && selected[2].ToString() == "Q4")
                        {
                            enddate1 = GoLiveyear + "-06-30";
                            startdate2 = GoLiveyear + "-10-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }

                        if (selected[1].ToString() == "Q2" && selected[2].ToString() == "Q4")
                        {
                            enddate1 = GoLiveyear + "-09-30";
                            startdate2 = GoLiveyear + 1 + "-01-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }

                    }

                    else if (selected[0].ToString() == "Q2")
                    {
                        startdate1 = GoLiveyear + "-07-01";
                        enddate1 = GoLiveyear + 1 + "-03-31";
                    }

                }

                if (selected.Count == 4)
                {
                    startdate1 = GoLiveyear + "-04-01";
                    enddate1 = GoLiveyear + 1 + "-03-31";

                }



                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {

                            SPList list = web.Lists["EffortsList"];
                            if (demandCR == "All")
                            {
                                if (application == "All")
                                {
                                    SPQuery oQuery = new SPQuery();

                                    oQuery.ViewFields = "<FieldRef Name='Application'/> <FieldRef Name='CRDemandNo'/> <FieldRef Name='TotalEfforts'/>";
                                    oQuery.ViewFieldsOnly = true;
                                    if (startdate2 == string.Empty && enddate2 == string.Empty)
                                    {
                                        
                                        oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + "</Value></Eq><And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + "</Value></Geq><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + "</Value></Leq></And></And></Where>";
                                       }
                                    else
                                        oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + @"</Value></Eq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                    <Or><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + @"</Value></Leq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate2 + @"</Value></Geq>
                                                    <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate2 + "</Value></Leq></And></Or></And></And></Where>";
                                    //oQuery.Query = "<Where><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + Portfolio + "</Value></Eq></Where>";
                                    allEfforts = list.GetItems(oQuery).GetDataTable();
                                }
                                else
                                {
                                    SPQuery oQuery = new SPQuery();
                                    oQuery.ViewFields = "<FieldRef Name='CRDemandNo'/> <FieldRef Name='TotalEfforts'/>";
                                    oQuery.ViewFieldsOnly = true;
                                    if (startdate2 == string.Empty && enddate2 == string.Empty)
                                        oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + @"</Value></Eq>
                                                <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                                <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + "</Value></Leq></And></And></And></Where>";
                                    else
                                        oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + @"</Value></Eq>
                                                    <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                    <Or><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + @"</Value></Leq>
                                                    <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate2 + @"</Value></Geq>
                                                    <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + enddate2 + @"</Value></Leq></And></Or></And></And></And></Where>";
                                    allEfforts = list.GetItems(oQuery).GetDataTable();
                                }
                            }
                            else if (application != "All" && demandCR != "All")
                            {
                                SPQuery oQuery = new SPQuery();

                                oQuery.ViewFields = "<FieldRef Name='BAEfforts'/> <FieldRef Name='DeveloperEfforts'/><FieldRef Name='SITEfforts'/><FieldRef Name='SecurityEfforts'/>";
                                oQuery.ViewFieldsOnly = true;
                                if (startdate2 == string.Empty && enddate2 == string.Empty)
                                    oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + @"</Value></Eq>
                                            <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                            <And><Eq><FieldRef Name='CRDemandNo' /><Value Type='Text'>" + demandCR + @"</Value></Eq>
                                            <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                            <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + enddate1 + @"</Value></Leq></And></And></And></And></Where>";
                                else
                                    oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + @"</Value></Eq>
                                                <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                                <And><Eq><FieldRef Name='CRDemandNo' /><Value Type='Text'>" + demandCR + @"</Value></Eq>
                                                <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                                <Or><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + @"</Value></Leq>
                                                <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate2 + @"</Value></Geq>
                                                <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate2 + @"</Value></Leq></And></Or></And></And></And></And></Where>";
                                allEfforts = list.GetItems(oQuery).GetDataTable();

                            }


                            //SPListItemCollection collListItems = list.GetItems(oQuery);
                            //portfolioOptions = collListItems.GetDataTable();
                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return allEfforts;

        }

        //public DataTable fetchEffortsRoleWise(string portfolio, string application, string demandCR)
        //{
        //    DataTable efforts = new DataTable();
        //    try
        //    {

        //        SPSecurity.RunWithElevatedPrivileges(delegate()
        //        {
        //            using (SPSite site = new SPSite(SPContext.Current.Site.Url))
        //            {
        //                using (SPWeb web = site.OpenWeb())
        //                {
        //                    SPList list = web.Lists["EffortsList"];
        //                    SPQuery oQuery = new SPQuery();

        //                    oQuery.ViewFields = "<FieldRef Name='BAEfforts'/> <FieldRef Name='DeveloperEfforts'/><FieldRef Name='SITEfforts'/><FieldRef Name='SecurityEfforts'/>";
        //                    oQuery.ViewFieldsOnly = true;
        //                    oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + portfolio + "</Value></Eq><And><Eq><FieldRef Name='Application'/><Value Type='Text'>" + application + "</Value></Eq><Eq><FieldRef Name='CRDemandNo'/><Value Type='Text'>" + demandCR + "</Value></Eq></And></And></Where>";
        //                    efforts = list.GetItems(oQuery).GetDataTable();


        //                    //SPListItemCollection collListItems = list.GetItems(oQuery);
        //                    //portfolioOptions = collListItems.GetDataTable();
        //                }
        //            }
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    return efforts;
        //}


        public DataTable FetchResourceWiseEffortsForApp(string portfolio, string application, string year, List<ListItem> selected)
        {
            DataTable resourceEfforts = new DataTable();
            string startdate1 = string.Empty;
            string enddate1 = string.Empty;
            string startdate2 = string.Empty;
            string enddate2 = string.Empty;
            try
            {

                int GoLiveyear = Convert.ToInt32(year);

                if (selected.Count == 0)
                {
                    startdate1 = GoLiveyear + "-04-01";
                    enddate1 = GoLiveyear + 1 + "-03-31";
                }

                if (selected.Count == 1)
                {
                    if (selected[0].ToString() == "Q1")
                    {
                        startdate1 = GoLiveyear + "-04-01";
                        // startdate1 = "4/1/" + GoLiveyear;
                        enddate1 = GoLiveyear + "-06-30";
                        //enddate1 = "6/30/" + GoLiveyear;
                    }

                    else if (selected[0].ToString() == "Q2")
                    {
                        startdate1 = GoLiveyear + "-07-1";
                        enddate1 = GoLiveyear + "-09-30";
                    }

                    else if (selected[0].ToString() == "Q3")
                    {
                        startdate1 = GoLiveyear + "-10-01";
                        enddate1 = GoLiveyear + "-12-31";
                    }

                    else if (selected[0].ToString() == "Q4")
                    {
                        startdate1 = GoLiveyear + 1 + "-01-01";
                        enddate1 = GoLiveyear + 1 + "-03-31";
                    }
                }



                if (selected.Count == 2)
                {
                    if (selected[0].ToString() == "Q1")
                    {
                        startdate1 = GoLiveyear + "-04-01";

                        if (selected[1].ToString() == "Q2")
                            enddate1 = GoLiveyear + "-09-30";

                        else if (selected[1].ToString() == "Q3")
                        {
                            enddate1 = GoLiveyear + "-06-30";
                            startdate2 = GoLiveyear + "-10-01";
                            enddate2 = GoLiveyear + "-12-31";
                        }
                        else
                        {
                            enddate1 = GoLiveyear + "-06-30";
                            startdate2 = GoLiveyear + 1 + "-01-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }

                    }

                    else if (selected[0].ToString() == "Q2")
                    {
                        startdate1 = GoLiveyear + "-07-01";

                        if (selected[1].ToString() == "Q3")
                            enddate1 = GoLiveyear + "-12-31";
                        else if (selected[1].ToString() == "Q4")
                        {
                            enddate1 = GoLiveyear + "-09-30";
                            startdate2 = GoLiveyear + 1 + "-01-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }
                    }

                    else if (selected[0].ToString() == "Q3")
                    {
                        startdate1 = GoLiveyear + "-10-01";

                        if (selected[1].ToString() == "Q4")
                            enddate1 = GoLiveyear + 1 + "-03-31";
                    }
                }

                if (selected.Count == 3)
                {
                    if (selected[0].ToString() == "Q1")
                    {
                        startdate1 = GoLiveyear + "-04-01";

                        if (selected[1].ToString() == "Q2" && selected[2].ToString() == "Q3")
                            enddate1 = GoLiveyear + "-12-31";

                        if (selected[1].ToString() == "Q3" && selected[2].ToString() == "Q4")
                        {
                            enddate1 = GoLiveyear + "-06-30";
                            startdate2 = GoLiveyear + "-10-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }

                        if (selected[1].ToString() == "Q2" && selected[2].ToString() == "Q4")
                        {
                            enddate1 = GoLiveyear + "-09-30";
                            startdate2 = GoLiveyear + 1 + "-01-01";
                            enddate2 = GoLiveyear + 1 + "-03-31";
                        }

                    }

                    else if (selected[0].ToString() == "Q2")
                    {
                        startdate1 = GoLiveyear + "-07-01";
                        enddate1 = GoLiveyear + 1 + "-03-31";
                    }

                }

                if (selected.Count == 4)
                {
                    startdate1 = GoLiveyear + "-04-01";
                    enddate1 = GoLiveyear + 1 + "-03-31";

                }

                string site1 = SPContext.Current.Site.Url;
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(site1))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();



                            oQuery.ViewFields = "<FieldRef Name='BAEfforts'/><FieldRef Name='DeveloperEfforts'/><FieldRef Name='SITEfforts'/><FieldRef Name='SecurityEfforts'/><FieldRef Name='TotalEfforts'/>";
                            oQuery.ViewFieldsOnly = true;
                            if (startdate2 == string.Empty && enddate2 == string.Empty)
                                oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + @"</Value></Eq>
                                            <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                            <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                            <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + @"</Value></Leq></And></And></And></Where>";
                            else
                                oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + portfolio + @"</Value></Eq>
                                            <And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + application + @"</Value></Eq>
                                            <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate1 + @"</Value></Geq>
                                            <Or><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate1 + @"</Value></Leq>
                                            <And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate2 + @"</Value></Geq>
                                            <Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate2 + @"</Value></Leq></And></Or></And></And></And></Where>";
                            resourceEfforts = list.GetItems(oQuery).GetDataTable();




                            //SPListItemCollection collListItems = list.GetItems(oQuery);
                            //portfolioOptions = collListItems.GetDataTable();
                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return resourceEfforts;
        }
        public DataTable fetchDemandsGrid(string Portfolio, string Application,int year)
        {
            DataTable allEfforts = new DataTable();
            int GoLiveyear = Convert.ToInt32(year);
            string startdate = string.Empty;
            string enddate = string.Empty;
            startdate = GoLiveyear + "-04-01";
            enddate = GoLiveyear + 1 + "-03-31";
            try
            {

                //SPSecurity.RunWithElevatedPrivileges(delegate()
                //{
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["EffortsList"];
                        SPQuery oQuery = new SPQuery();

                        oQuery.ViewFields = "<FieldRef Name='Portfolio'/> <FieldRef Name='Application'/> <FieldRef Name='CRDemandNo' /> <FieldRef Name='GoLiveMonth'/> ";
                        oQuery.ViewFieldsOnly = true;
                        if (Application.ToLower() == "all")
                        {
                            //oQuery.Query = "<Where><Eq><FieldRef Name='Portfolio'/><Value Type='Choice'>" + Portfolio + "</Value></Eq></Where>";
                            oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + "</Value></Eq><And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + startdate + "</Value></Geq><Leq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>" + enddate + "</Value></Leq></And></And></Where>";
                        }
                        else
                        {
                            //oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + "</Value></Eq><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + Application + "</Value></Eq></And></Where>";
                            oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Choice'>" + Portfolio + "</Value></Eq><And><Eq><FieldRef Name='Application' /><Value Type='Choice'>" + Application + "</Value></Eq><And><Geq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + startdate + "</Value></Geq><Neq><FieldRef Name='GoLiveDate' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + enddate + "</Value></Neq></And></And></And></Where>";
                        }
                        allEfforts = list.GetItems(oQuery).GetDataTable();




                    }
                }
                //});
            }
            catch (Exception ex)
            {
            }
            return allEfforts;

        }
        public DataTable fetchDemandApplicationData(string portfolio, string application)
        {
            DataTable Efforts = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();

                            if (portfolio != "ALL" && application != "ALL")
                            {

                                oQuery.ViewFields = "<FieldRef Name='Application'/><FieldRef Name='GoLiveMonth'/>";
                                oQuery.ViewFieldsOnly = true;
                                oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + portfolio + "</Value></Eq><Eq><FieldRef Name='Application'/><Value Type='Text'>" + application + "</Value></Eq></And></Where>";
                                Efforts = list.GetItems(oQuery).GetDataTable();

                            }
                            else
                            {
                                oQuery.ViewFields = "<FieldRef Name='Application'/><FieldRef Name='GoLiveMonth'/>";
                                oQuery.ViewFieldsOnly = true;
                                oQuery.Query = "<Where><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + portfolio + "</Value></Eq></Where>";
                                Efforts = list.GetItems(oQuery).GetDataTable();

                            }

                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return Efforts;

        }

        #region Bulk Upload : Bhavna

        public int insertBulkUploadDataToEfortList(DataTable dtEffortExcelData)
        {
            int fileUploaded = 0;
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["EffortsList"];

                        site.AllowUnsafeUpdates = true;
                        web.AllowUnsafeUpdates = true;

                        SPQuery oQuery = new SPQuery();

                        if (dtEffortExcelData != null)
                        {

                            foreach (DataRow dr in dtEffortExcelData.Rows)
                            {
                                SPListItem ItemEfforList = list.AddItem();

                                ItemEfforList["Portfolio"] = dr["Portfolio"];
                                ItemEfforList["Application"] = dr["Application"];
                                ItemEfforList["CRDemandNo"] = dr["CR Demand No."];
                                ItemEfforList["BAAllocatedDate"] = Convert.ToDateTime(dr["BA Allocated Date"].ToString());
                                ItemEfforList["ConstructionStartDate"] = Convert.ToDateTime(dr["Construction Start Date"]);
                                ItemEfforList["BAAllocated"] = dr["BA Allocated"];
                                ItemEfforList["SITEfforts"] = dr["SIT Efforts"];
                                ItemEfforList["SecurityTesters"] = dr["Security Testers"];
                                ItemEfforList["SecurityEfforts"] = dr["Security Efforts"];
                                // ItemEfforList["TotalEfforts"] = dr["Total Efforts"];
                                ItemEfforList["BADefects"] = dr["BA Defects"];
                                ItemEfforList["SITDefects"] = dr["SIT Defects"];
                                ItemEfforList["VFQADefects"] = dr["VF QA Defects"];
                                ItemEfforList["PostProdDefects"] = dr["Post Prod Defects"];
                                // ItemEfforList["TotalDefects"] = dr["Total Defects"];
                                ItemEfforList["UATDefects"] = dr["UAT Defects"];
                                ItemEfforList["DeveloperAllocated"] = dr["Developers Allocated"];
                                ItemEfforList["GoLiveDate"] = Convert.ToDateTime(dr["Go Live Date"]);//dr["Go Live Date"];
                                ItemEfforList["BAEfforts"] = dr["BA Efforts"];
                                ItemEfforList["DeveloperEfforts"] = dr["Developer Efforts"];
                                ItemEfforList["SITTesters"] = dr["SIT Testers"];
                                ItemEfforList.Update();
                                fileUploaded = 1;


                            }
                        }

                    }
                }
            });
            return fileUploaded;
        }

        public int insertBulkUploadDataToDefectList(DataTable dtEffortDefectData, string effortListId)
        {
            int fileUploaded = 0;
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["DefectDetails"];

                        site.AllowUnsafeUpdates = true;
                        web.AllowUnsafeUpdates = true;

                        SPQuery oQuery = new SPQuery();

                        if (dtEffortDefectData != null)
                        {
                            foreach (DataRow dr in dtEffortDefectData.Rows)
                            {
                                SPListItem ItemEfforList = list.AddItem();

                                ItemEfforList["EffortListID"] = effortListId;
                                ItemEfforList["Defect"] = dr["Defect"];
                                ItemEfforList["CausalAnalysis"] = dr["Causal Analysis"];
                                ItemEfforList["Severity"] = dr["Severity"];
                                ItemEfforList["Category"] = dr["Category"];
                                ItemEfforList["Status"] = dr["Status"];
                                ItemEfforList.Update();
                                fileUploaded = 1;

                            }
                        }

                    }
                }
            });
            return fileUploaded;
        }

        public DataTable fetchDataforBulkUploadGrid(string portfolio, string application)
        {
            DataTable dtGridData = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();

                            oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + portfolio + "</Value></Eq><Eq><FieldRef Name='Application'/><Value Type='Text'>" + application + "</Value></Eq></And></Where><OrderBy><FieldRef Name='Created' Ascending='False' /></OrderBy>";
                            dtGridData = list.GetItems(oQuery).GetDataTable();



                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return dtGridData;
        }

        //public DataTable fetchEffortsRoleWise(string portfolio, string application, string demandCR)
        //{
        //    DataTable efforts = new DataTable();
        //    try
        //    {

        //        SPSecurity.RunWithElevatedPrivileges(delegate()
        //        {
        //            using (SPSite site = new SPSite(SPContext.Current.Site.Url))
        //            {
        //                using (SPWeb web = site.OpenWeb())
        //                {
        //                    SPList list = web.Lists["EffortsList"];
        //                    SPQuery oQuery = new SPQuery();

        //                    oQuery.ViewFields = "<FieldRef Name='BAEfforts'/> <FieldRef Name='DeveloperEfforts'/><FieldRef Name='SITEfforts'/><FieldRef Name='SecurityEfforts'/>";
        //                    oQuery.ViewFieldsOnly = true;
        //                    oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio'/><Value Type='Text'>" + portfolio + "</Value></Eq><And><Eq><FieldRef Name='Application'/><Value Type='Text'>" + application + "</Value></Eq><Eq><FieldRef Name='CRDemandNo'/><Value Type='Text'>" + demandCR + "</Value></Eq></And></And></Where>";
        //                    efforts = list.GetItems(oQuery).GetDataTable();


        //                    //SPListItemCollection collListItems = list.GetItems(oQuery);
        //                    //portfolioOptions = collListItems.GetDataTable();
        //                }
        //            }
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    return efforts;
        //}

        public int updateBulkUploadDataToEffortList(int id, string BAAllocated, string SITEfforts, string SecurityTesters, string SecurityEfforts,
        string BADefects, string SITDefects, string VFQADefects, string PostProdDefects, string UATDefects, string DeveloperAllocated, string BAEfforts, string DeveloperEfforts, string SITTesters)
        {
            int i = 0;

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["EffortsList"];

                        site.AllowUnsafeUpdates = true;
                        web.AllowUnsafeUpdates = true;

                        SPQuery oQuery = new SPQuery();

                        // SPListItem ItemEfforList = list.AddItem();

                        SPListItem itemToUpdate = list.GetItemById(id);

                        // itemToUpdate["BAAllocatedDate"] = Convert.ToDateTime(BAAllocatedDate);
                        //  itemToUpdate["ConstructionStartDate"] = Convert.ToDateTime(ConstructionStartDate);
                        itemToUpdate["BAAllocated"] = BAAllocated;
                        itemToUpdate["SITEfforts"] = SITEfforts;
                        itemToUpdate["SecurityTesters"] = SecurityTesters;
                        itemToUpdate["SecurityEfforts"] = SecurityEfforts;
                        // itemToUpdate["TotalEfforts"] = TotalEfforts;
                        itemToUpdate["BADefects"] = BADefects;
                        itemToUpdate["SITDefects"] = SITDefects;
                        itemToUpdate["VFQADefects"] = VFQADefects;
                        itemToUpdate["PostProdDefects"] = PostProdDefects;
                        //  itemToUpdate["TotalDefects"] = TotalDefects;
                        itemToUpdate["UATDefects"] = UATDefects;
                        itemToUpdate["DeveloperAllocated"] = DeveloperAllocated;
                        //  itemToUpdate["GoLiveDate"] = Convert.ToDateTime(GoLiveDate);
                        itemToUpdate["BAEfforts"] = BAEfforts;
                        itemToUpdate["DeveloperEfforts"] = DeveloperEfforts;
                        itemToUpdate["SITTesters"] = SITTesters;

                        itemToUpdate.Update();
                        i = 1;

                    }
                }
            });
            return i;
        }

        public int updateBulkUploadDataToDefectList(int id, string Causal, string Severity, string Category, string Status)
        {
            int i = 0;

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["DefectDetails"];

                        site.AllowUnsafeUpdates = true;
                        web.AllowUnsafeUpdates = true;

                        SPQuery oQuery = new SPQuery();

                        // SPListItem ItemEfforList = list.AddItem();

                        SPListItem itemToUpdate = list.GetItemById(id);
                        // itemToUpdate["BAAllocated"] = Defect;

                        itemToUpdate["CausalAnalysis"] = Causal;
                        itemToUpdate["Severity"] = Severity;
                        itemToUpdate["Category"] = Category;
                        itemToUpdate["Status"] = Status;

                        itemToUpdate.Update();
                        i = 1;

                    }
                }
            });
            return i;
        }

        public DataTable fetchDataforBulkUploadDefectGrid(string portfolio, string application, string CrDemandNo)
        {
            DataTable dtGridData = new DataTable();
            DataTable dtDefectGridData = new DataTable();
            DataTable dtDefectTempData = new DataTable();
          
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();

                            SPQuery oQueryDefect = new SPQuery();

                            oQuery.ViewFields = "<FieldRef Name='ID'/>";
                            oQuery.ViewFieldsOnly = true;
                            oQuery.Query = "<Where><And><Eq><FieldRef Name='Portfolio' /><Value Type='Text'>" + portfolio + "</Value></Eq><And><Eq><FieldRef Name='Application' /><Value Type='Text'>" + application + "</Value></Eq><Eq><FieldRef Name='CRDemandNo' /><Value Type='Text'>" + CrDemandNo + "</Value></Eq></And></And></Where><OrderBy><FieldRef Name='Created' Ascending='False' /></OrderBy>";
                            dtGridData = list.GetItems(oQuery).GetDataTable();
                            if (dtGridData != null)
                            {
                                if (dtGridData.Rows.Count > 0)
                                {
                                    string id = dtGridData.Rows[0]["ID"].ToString();



                                    SPList listDefect = web.Lists["DefectDetails"];

                                    oQueryDefect.Query = "<Where><Eq><FieldRef Name='EffortListID' /><Value Type='Lookup'>" + id + "</Value></Eq></Where>";
                                    dtDefectTempData = listDefect.GetItems(oQueryDefect).GetDataTable();
                                }
                            }
                           

                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return dtDefectTempData;
        }

        public DataTable FetchCausalData()
        {
            string type = "Causal";
            DataTable dtCausalData = new DataTable();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["CausalAnalysisMaster"];
                        SPQuery oQuery = new SPQuery();

                        oQuery.ViewFields = "<FieldRef Name='Value'/>";
                        oQuery.ViewFieldsOnly = true;

                        oQuery.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + type + "</Value></Eq></Where>";
                        dtCausalData = list.GetItems(oQuery).GetDataTable();
                    }
                }
            });
            return dtCausalData;

        }

        public DataTable FetchSeverityData()
        {
            string type = "Severity";
            DataTable dtCausalData = new DataTable();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["CausalAnalysisMaster"];
                        SPQuery oQuery = new SPQuery();

                        oQuery.ViewFields = "<FieldRef Name='Value'/>";
                        oQuery.ViewFieldsOnly = true;

                        oQuery.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + type + "</Value></Eq></Where>";
                        dtCausalData = list.GetItems(oQuery).GetDataTable();

                    }
                }
            });
            return dtCausalData;

        }

        public DataTable FetchStatusData()
        {
            string type = "Status";
            DataTable dtCausalData = new DataTable();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["CausalAnalysisMaster"];
                        SPQuery oQuery = new SPQuery();

                        oQuery.ViewFields = "<FieldRef Name='Value'/>";
                        oQuery.ViewFieldsOnly = true;

                        oQuery.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + type + "</Value></Eq></Where>";
                        dtCausalData = list.GetItems(oQuery).GetDataTable();

                    }
                }
            });
            return dtCausalData;

        }

        public DataTable FetchCategoryData()
        {
            string type = "Category";
            DataTable dtCausalData = new DataTable();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["CausalAnalysisMaster"];
                        SPQuery oQuery = new SPQuery();

                        oQuery.ViewFields = "<FieldRef Name='Value'/>";
                        oQuery.ViewFieldsOnly = true;

                        oQuery.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + type + "</Value></Eq></Where>";
                        dtCausalData = list.GetItems(oQuery).GetDataTable();

                    }
                }
            });
            return dtCausalData;

        }

        public StringBuilder ValidateDefectListData(DataTable dtDefectListData,string CRDemandNo)
        {
            string postProdEffortList = string.Empty;
            string uatEffortList = string.Empty;
            string BaEffortList = string.Empty;
            string sitEffortList = string.Empty;
            string vfQaEffortList = string.Empty;

            string postProdDefectExcelData = string.Empty;
            string vfQaDefectExcelData = string.Empty;
            string uatDefectExcelData = string.Empty;
            string sitDefectExcelData = string.Empty;
            string BaDefectExcelData = string.Empty;

            string postProdDefectListData = string.Empty;
            string vfQaDefectListData = string.Empty;
            string uatDefectListData = string.Empty;
            string sitDefectListData = string.Empty;
            string BaDefectListData = string.Empty;

            StringBuilder errorMsg = new StringBuilder();
           
            DataView dvDefectDatafromList = null;
            DataView dvDefectDatafromFile = null;
            DataTable defectDatafromList = fetchAllDefectData(string.Empty);
           
            DataTable dtCategoryWiseDefectCount = fetchAllDefectData(CRDemandNo);

            #region Fetching Category Wise Count from Effort List

            DataTable allTypeDefectCount = fetchAllEffortsData(CRDemandNo);
            if (allTypeDefectCount != null) 
            {
                if (allTypeDefectCount.Rows.Count > 0)
                {
                     postProdEffortList = allTypeDefectCount.Rows[0]["PostProdDefects"].ToString();
                     uatEffortList      = allTypeDefectCount.Rows[0]["UATDefects"].ToString();
                     BaEffortList       = allTypeDefectCount.Rows[0]["BADefects"].ToString();
                     sitEffortList      = allTypeDefectCount.Rows[0]["SITDefects"].ToString();
                     vfQaEffortList     = allTypeDefectCount.Rows[0]["VFQADefects"].ToString();
                }
            }

            #endregion

            #region Check if Defect count in effort list is in accordance with Causal Data in Excel

            if (dtDefectListData != null)
            {
                if (dtDefectListData.Rows.Count > 0)
                {
                    DataTable dtCategory = FetchCategoryData();
                    DataTable dtFinal = new DataTable();
                    dtFinal.Columns.Add("Category");
                    dtFinal.Columns.Add("Count");

                  

                    foreach (DataRow drCat in dtCategory.Rows)
                    {
                        DataView dvDefectData = new DataView(dtDefectListData);
                        dvDefectData.RowFilter = "Category=" + "'" + "" + drCat["Value"].ToString() + "" + "'";
                        DataTable dtTemp = dvDefectData.ToTable();
                        dtFinal.Rows.Add(drCat["Value"].ToString(), dtTemp.Rows.Count);
                        dtTemp.Clear();
                    }

                    for (int i = 0; i <= dtFinal.Rows.Count - 1; i++)
                    {
                        if (dtFinal.Rows[i]["Category"].ToString() == "BA Defects")
                        {
                             BaDefectExcelData = dtFinal.Rows[i]["Count"].ToString();
                        }
                        if (dtFinal.Rows[i]["Category"].ToString() == "SIT Defects")
                        {
                            sitDefectExcelData = dtFinal.Rows[i]["Count"].ToString();
                        }

                        if (dtFinal.Rows[i]["Category"].ToString() == "UAT Defects")
                        {
                            uatDefectExcelData = dtFinal.Rows[i]["Count"].ToString();
                        }

                        if (dtFinal.Rows[i]["Category"].ToString() == "VF-QA Defects")
                        {
                            vfQaDefectExcelData = dtFinal.Rows[i]["Count"].ToString();
                        }

                        if (dtFinal.Rows[i]["Category"].ToString() == "POST PROD Defects")
                        {
                            postProdDefectExcelData = dtFinal.Rows[i]["Count"].ToString();
                        }
                    }

                }
            }
            if (Convert.ToInt32(postProdEffortList) < Convert.ToInt32(postProdDefectExcelData))
            {   
                errorMsg.Append("Count of Post-Prod Defects in Effort List is "+postProdEffortList+" .Please enter equal or less Causal Data. ");
            }
            if (Convert.ToInt32(vfQaEffortList) < Convert.ToInt32(vfQaDefectExcelData))
            {
                errorMsg.Append("Count of VF-QA Defects in Effort List is " + vfQaEffortList + " .Please enter equal or less Causal Data. ");
            }
            if (Convert.ToInt32(sitEffortList) < Convert.ToInt32(sitDefectExcelData))
            {
                errorMsg.Append("Count of SIT Defects in Effort List is " + sitEffortList + " .Please enter equal or less Causal Data. ");
            }
            if (Convert.ToInt32(BaEffortList) < Convert.ToInt32(BaDefectExcelData))
            {
                errorMsg.Append("Count of BA Defects in Effort List is " + BaEffortList + " .Please enter equal or less Causal Data. ");
            }
            if (Convert.ToInt32(uatEffortList) < Convert.ToInt32(uatDefectExcelData))
            {
                errorMsg.Append("Count of UAT Defects in Effort List is " + uatEffortList + " .Please enter equal or less Causal Data. ");
            }

            #endregion

            #region Check if Defect count in effort list is in accordance with Causal Data in List

            if (dtCategoryWiseDefectCount != null)
            {
                if (dtCategoryWiseDefectCount.Rows.Count > 0)
                {
                    DataTable dtCategory = FetchCategoryData();
                    DataTable dtFinalList = new DataTable();
                    dtFinalList.Columns.Add("Category");
                    dtFinalList.Columns.Add("Count");



                    foreach (DataRow drCat in dtCategory.Rows)
                    {
                        DataView dvDefectDataList = new DataView(dtCategoryWiseDefectCount);
                        dvDefectDataList.RowFilter = "Category=" + "'" + "" + drCat["Value"].ToString() + "" + "'";
                        DataTable dtTemp = dvDefectDataList.ToTable();
                        dtFinalList.Rows.Add(drCat["Value"].ToString(), dtTemp.Rows.Count);
                        dtTemp.Clear();
                    }

                    for (int i = 0; i <= dtFinalList.Rows.Count - 1; i++)
                    {
                        if (dtFinalList.Rows[i]["Category"].ToString() == "BA Defects")
                        {
                            BaDefectListData = dtFinalList.Rows[i]["Count"].ToString();
                        }
                        if (dtFinalList.Rows[i]["Category"].ToString() == "SIT Defects")
                        {
                            sitDefectListData = dtFinalList.Rows[i]["Count"].ToString();
                        }

                        if (dtFinalList.Rows[i]["Category"].ToString() == "UAT Defects")
                        {
                            uatDefectListData = dtFinalList.Rows[i]["Count"].ToString();
                        }

                        if (dtFinalList.Rows[i]["Category"].ToString() == "VF-QA Defects")
                        {
                            vfQaDefectListData = dtFinalList.Rows[i]["Count"].ToString();
                        }

                        if (dtFinalList.Rows[i]["Category"].ToString() == "POST PROD Defects")
                        {
                            postProdDefectListData = dtFinalList.Rows[i]["Count"].ToString();
                        }
                    }

                }
                else
                {
                    postProdDefectListData = "0";
                    vfQaDefectListData = "0";
                    uatDefectListData = "0";
                    sitDefectListData = "0";
                    BaDefectListData = "0";
                }
            }
            else
            {
                postProdDefectListData = "0";
                vfQaDefectListData = "0";
                uatDefectListData = "0";
                sitDefectListData = "0";
                BaDefectListData = "0";
            }
            if (Convert.ToInt32(postProdEffortList) < Convert.ToInt32(postProdDefectExcelData) + Convert.ToInt32(postProdDefectListData))
            {
                errorMsg.Append("Count of Post-Prod Defects in Effort List is " + postProdEffortList + " .Please enter equal or less Causal Data. ");
            }
            if (Convert.ToInt32(vfQaEffortList) < Convert.ToInt32(vfQaDefectExcelData) + Convert.ToInt32(vfQaDefectListData))
            {
                errorMsg.Append("Count of VF-QA Defects in Effort List is " + vfQaEffortList + " .Please enter equal or less Causal Data. ");
            }
            if (Convert.ToInt32(sitEffortList) < Convert.ToInt32(sitDefectExcelData) + Convert.ToInt32(sitDefectListData))
            {
                errorMsg.Append("Count of SIT Defects in Effort List is " + sitEffortList + " .Please enter equal or less Causal Data. ");
            }
            if (Convert.ToInt32(BaEffortList) < Convert.ToInt32(BaDefectExcelData) + Convert.ToInt32(BaDefectListData))
            {
                errorMsg.Append("Count of BA Defects in Effort List is " + BaEffortList + " .Please enter equal or less Causal Data. ");
            }
            if (Convert.ToInt32(uatEffortList) < Convert.ToInt32(uatDefectExcelData) + Convert.ToInt32(uatDefectListData))
            {
                errorMsg.Append("Count of UAT Defects in Effort List is " + uatEffortList + " .Please enter equal or less Causal Data. ");
            }
            #endregion

            if (defectDatafromList != null)
            {
                if (defectDatafromList.Rows.Count > 0)
                {
                     dvDefectDatafromList = new DataView(defectDatafromList);
                }
            }
            
            if (dtDefectListData != null)
            {
                DataTable dtCausalData = FetchCausalData();
                DataTable dtSeverityData = FetchSeverityData();
                DataTable dtStatusData = FetchStatusData();
                DataTable dtCategoryData = FetchCategoryData();

                dvDefectDatafromFile = new DataView(dtDefectListData);

               

                foreach (DataRow dr in dtDefectListData.Rows)
                {
                    if (dvDefectDatafromFile != null)
                    {
                        dvDefectDatafromFile.RowFilter = "Defect =" + "'" + "" + dr["Defect"].ToString() + "" + "'";
                    }
                    if (dvDefectDatafromList != null)
                    {
                        dvDefectDatafromList.RowFilter = "Title =" + "'" + "" + dr["Defect"].ToString() + "" + "'";
                    }

                    if (dr["Defect"].ToString() == string.Empty || dr["Causal Analysis"].ToString() == string.Empty || dr["Severity"].ToString() == string.Empty || dr["Category"].ToString() == string.Empty || dr["Status"].ToString() == string.Empty)
                    {
                        errorMsg.Append("All fields are mandatory.Please fill all fields and try again.");
                        break;
                    }
                   
                    else
                    {

                        if (dvDefectDatafromList != null)
                        {
                            if (dvDefectDatafromList.Count > 0)
                            {
                                errorMsg.Append("Defect with Defect value " + dr["Defect"].ToString() + " already exists.Please enter unique values and try again.");
                                break;
                            }
                        }
                        if (dvDefectDatafromFile != null)
                        {
                            if (dvDefectDatafromFile.Count > 1)
                            {
                                errorMsg.Append("Defect with Defect value " + dr["Defect"].ToString() + " already exists in the file.Please enter unique values and try again.");
                                break;
                            }
                        }
                        if ((dr["Defect"].ToString().Trim()).Count() > 1500)
                        {
                            errorMsg.Append("Defect cannot be of more than 1500 characters.");
                        }
                        DataView dvCausal = new DataView(dtCausalData);
                        dvCausal.RowFilter = "Value=" + "'" + "" + dr["Causal Analysis"].ToString() + "" + "'";

                        DataView dvSeverity = new DataView(dtSeverityData);
                        dvSeverity.RowFilter = "Value=" + "'" + "" + dr["Severity"].ToString() + "" + "'";

                        DataView dvStatus = new DataView(dtStatusData);
                        dvStatus.RowFilter = "Value=" + "'" + "" + dr["Status"].ToString() + "" + "'";

                        DataView dvCategory = new DataView(dtCategoryData);
                        dvCategory.RowFilter = "Value=" + "'" + "" + dr["Category"].ToString() + "" + "'";


                        if (Regex.IsMatch(dr["Defect"].ToString(), @"^[a-zA-Z0-9]+$"))
                        {
                            if (dvCausal != null)
                            {
                                if (dvCausal.Count > 0)
                                {
                                    if (dvSeverity != null)
                                    {
                                        if (dvSeverity.Count > 0)
                                        {
                                            if (dvCategory != null)
                                            {
                                                if (dvCategory.Count > 0)
                                                {
                                                    if (dvStatus != null)
                                                    {
                                                        if (dvStatus.Count > 0)
                                                        {

                                                        }
                                                        else { errorMsg.Append("Status is invalid at " + dr["Defect"].ToString() + "."); }
                                                    }
                                                    else { errorMsg.Append("Status is invalid at " + dr["Defect"].ToString() + "."); }
                                                }
                                                else { errorMsg.Append("Category is invalid at " + dr["Defect"].ToString() + "."); }
                                            }
                                            else { errorMsg.Append("Category is invalid at " + dr["Defect"].ToString() + "."); }
                                        }
                                        else { errorMsg.Append("Severity is invalid at " + dr["Defect"].ToString() + "."); }
                                    }
                                    else { errorMsg.Append("Severity is invalid at " + dr["Defect"].ToString() + "."); }

                                }
                                else { errorMsg.Append("Causal is invalid at " + dr["Defect"].ToString() + "."); }
                            }
                            else { errorMsg.Append("Causal is invalid at " + dr["Defect"].ToString() + "."); }
                        }
                        else { errorMsg.Append("Defect with value "+  dr["Defect"].ToString() +" is invalid."); }

                    }
                }
            }


            return errorMsg;
        }

        public StringBuilder validateEffortList(DataTable dtEffortListData, string portfolioId)
        {
            int isDataValid = 0;
            StringBuilder errorMsg = new StringBuilder();

            DataView dvEffortDataformList = null;
            DataTable dtPortfolioData = FetchPortfolioData(portfolioId);

            //check unique entries from list:-
            DataTable dtAllCrDemandData = fetchAllEffortsData(string.Empty);
            if (dtAllCrDemandData != null)
            {
                if (dtAllCrDemandData.Rows.Count > 0)
                {
                    dvEffortDataformList = new DataView(dtAllCrDemandData);
                }
            }
         
            if (dtEffortListData != null)
            {
                //check unique values in excel file:-
                DataTable dtCrDemand = new DataTable();
                dtCrDemand.Columns.Add("CRDemandNo");

                DataView dvEffortDatafromFile = new DataView(dtEffortListData);
                dtCrDemand = dvEffortDatafromFile.ToTable("Selected", false, "CR Demand No.");
                dtCrDemand.Columns["CR Demand No."].ColumnName = "CRDemandNo";
                DataView uniqueCrDemand = new DataView(dtCrDemand);

                foreach (DataRow drEffort in dtEffortListData.Rows)
                {
                    if (uniqueCrDemand != null)
                    {
                        uniqueCrDemand.RowFilter = "CRDemandNo =" + "'" + "" + drEffort["CR Demand No."].ToString() + "" + "'";
                    }
                    if (dvEffortDataformList != null)
                    {
                        dvEffortDataformList.RowFilter = "CRDemandNo =" + "'" + "" + drEffort["CR Demand No."].ToString() + "" + "'";
                    }

                 

                    if (drEffort["Portfolio"].ToString() == string.Empty || drEffort["Application"].ToString() == string.Empty || drEffort["CR Demand No."].ToString() == string.Empty
                                    || drEffort["BA Allocated"].ToString() == string.Empty || drEffort["SIT Efforts"].ToString() == string.Empty || drEffort["Security Testers"].ToString() == string.Empty
                                    || drEffort["Security Testers"].ToString() == string.Empty || drEffort["Security Efforts"].ToString() == string.Empty || drEffort["BA Defects"].ToString() == string.Empty
                                    || drEffort["SIT Defects"].ToString() == string.Empty || drEffort["VF QA Defects"].ToString() == string.Empty || drEffort["Post Prod Defects"].ToString() == string.Empty
                                    || drEffort["UAT Defects"].ToString() == string.Empty || drEffort["Developers Allocated"].ToString() == string.Empty || drEffort["BA Efforts"].ToString() == string.Empty
                                    || drEffort["Developer Efforts"].ToString() == string.Empty || drEffort["SIT Testers"].ToString() == string.Empty || drEffort["BA Allocated Date"].ToString() == string.Empty
                                    || drEffort["Construction Start Date"].ToString() == string.Empty || drEffort["Go Live Date"].ToString() == string.Empty)
                    {
                        isDataValid = 0;
                        errorMsg.Append("All fields are mandatory.Please fill all fields and try again.");
                        break;
                    }
                   
                    else
                    {
                        if (uniqueCrDemand != null)
                        {
                            if (uniqueCrDemand.Count > 1)
                            {
                                errorMsg.Append("CR Demand No. " + drEffort["CR Demand No."] + " already exists in the uploaded file.Please enter unique values and try again.");
                                break;
                            }

                        }
                        if (dvEffortDataformList != null)
                        {
                            if (dvEffortDataformList.Count > 0)
                            {
                                errorMsg.Append("CR Demand No. " + drEffort["CR Demand No."] + " already exists.Please enter unique values and try again.");
                                break;
                            }

                        }

                        DataView dvPortfolio = new DataView(dtPortfolioData);
                        dvPortfolio.RowFilter = "Portfolio=" + "'" + "" + drEffort["Portfolio"].ToString() + "" + "'";

                        if (dvPortfolio != null)
                        {
                            if (dvPortfolio.Count > 0)
                            {
                                DataTable dtApplicationData = FetchApplicationData(drEffort["Portfolio"].ToString());

                                DataView dvApplication = new DataView(dtApplicationData);
                                dvApplication.RowFilter = "Application=" + "'" + "" + drEffort["Application"].ToString() + "" + "'";

                                if (dvApplication != null)
                                {
                                    if (dvApplication.Count > 0)
                                    {
                                        if (Regex.IsMatch(drEffort["CR Demand No."].ToString(), @"^[a-zA-Z0-9]+$") )
                                        {
                                            if (Regex.IsMatch(drEffort["BA Allocated"].ToString(), @"^[a-zA-Z,\s]+$"))
                                            {
                                                if (Regex.IsMatch(drEffort["Developers Allocated"].ToString(), @"^[a-zA-Z,\s]+$"))
                                                {
                                                    if (Regex.IsMatch(drEffort["SIT Testers"].ToString(), @"^[a-zA-Z,\s]+$"))
                                                    {

                                                        if (Regex.IsMatch(drEffort["Security Testers"].ToString(), @"^[a-zA-Z,\s]+$"))
                                                        {

                                                            if (Regex.IsMatch(drEffort["BA Efforts"].ToString(), @"^\d+\.?\d{0,2}$"))
                                                            {
                                                                if (Regex.IsMatch(drEffort["Developer Efforts"].ToString(), @"^\d+\.?\d{0,2}$"))
                                                                {
                                                                    if (Regex.IsMatch(drEffort["SIT Efforts"].ToString(), @"^\d+\.?\d{0,2}$"))
                                                                    {

                                                                        if (Regex.IsMatch(drEffort["Security Efforts"].ToString(), @"^\d+\.?\d{0,2}$"))
                                                                        {

                                                                            if (Regex.IsMatch(drEffort["BA Defects"].ToString(), "^[0-9]*$"))
                                                                            {
                                                                                if (Regex.IsMatch(drEffort["SIT Defects"].ToString(), "^[0-9]*$"))
                                                                                {
                                                                                    if (Regex.IsMatch(drEffort["VF QA Defects"].ToString(), "^[0-9]*$"))
                                                                                    {
                                                                                        if (Regex.IsMatch(drEffort["UAT Defects"].ToString(), "^[0-9]*$"))
                                                                                        {
                                                                                            if (Regex.IsMatch(drEffort["Post Prod Defects"].ToString(), "^[0-9]*$"))
                                                                                            {
                                                                                                if (Regex.IsMatch(drEffort["Go Live Date"].ToString(), @"^[a-zA-Z0-9]+$"))
                                                                                                {
                                                                                                    errorMsg.Append("Go Live Date is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    if (Regex.IsMatch(drEffort["BA Allocated Date"].ToString(), @"^[a-zA-Z0-9]+$"))
                                                                                                    {
                                                                                                        errorMsg.Append("BA Allocated Date is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                                                                                    }
                                                                                                    else
                                                                                                    {
                                                                                                        if (Regex.IsMatch(drEffort["Construction Start Date"].ToString(), @"^[a-zA-Z0-9]+$"))
                                                                                                        {
                                                                                                            errorMsg.Append("Construction Start Date is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            string Date = DateTime.Parse(drEffort["Go Live Date"].ToString()).ToString("MM/dd/yyyy");
                                                                                                            DateTime date;

                                                                                                            string Date1 = DateTime.Parse(drEffort["BA Allocated Date"].ToString()).ToString("MM/dd/yyyy");
                                                                                                            DateTime date1;

                                                                                                            string Date2 = DateTime.Parse(drEffort["Construction Start Date"].ToString()).ToString("MM/dd/yyyy");
                                                                                                            DateTime date2;

                                                                                                            string todaysDate = DateTime.Now.ToString("MM/dd/yyyy");

                                                                                                            DateTime dtGoLiveDate = DateTime.Parse(Date);
                                                                                                            DateTime dtBaAllo = DateTime.Parse(Date1);
                                                                                                            DateTime dtConstruction = DateTime.Parse(Date2);
                                                                                                            DateTime todays = DateTime.Parse(todaysDate);
                                                                                                            DateTime lessDate = DateTime.Parse("1/1/2010");

                                                                                                            if (DateTime.TryParseExact(Date, "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.NoCurrentDateDefault, out date))
                                                                                                            {
                                                                                                                if ((DateTime.TryParseExact(Date1, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out date1)) == true)
                                                                                                                {

                                                                                                                    if ((DateTime.TryParseExact(Date2, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out date2)) == true)
                                                                                                                    {
                                                                                                                        if (dtConstruction >= todays)
                                                                                                                       {
                                                                                                                           errorMsg.Append("Construction Start Date at " + drEffort["CR Demand No."].ToString() + " cannot be greater than today's date.");

                                                                                                                       }
                                                                                                                        else if (dtConstruction < lessDate)
                                                                                                                        {
                                                                                                                            errorMsg.Append("Construction Start Date at " + drEffort["CR Demand No."].ToString() + " cannot be less than 1/1/2010.");
                                                                                                                        }

                                                                                                                        if (dtBaAllo >= todays)
                                                                                                                        {
                                                                                                                            errorMsg.Append("BA Allocated Start Date at " + drEffort["CR Demand No."].ToString() + " cannot be greater than today's date.");

                                                                                                                        }
                                                                                                                        else if (dtBaAllo < lessDate)
                                                                                                                        {
                                                                                                                            errorMsg.Append("BA Allocated Start Date at " + drEffort["CR Demand No."].ToString() + " cannot be less than 1/1/2010.");
                                                                                                                        }

                                                                                                                        if (dtGoLiveDate > todays)
                                                                                                                        {
                                                                                                                            errorMsg.Append("Go Live Start Date at " + drEffort["CR Demand No."].ToString() + " cannot be greater than today's date.");

                                                                                                                        }
                                                                                                                        else if (dtGoLiveDate < lessDate)
                                                                                                                        {
                                                                                                                            errorMsg.Append("Go Live Start Date at " + drEffort["CR Demand No."].ToString() + " cannot be less than 1/1/2010.");
                                                                                                                        }
                                                                                                                        if ((drEffort["CR Demand No."].ToString().Trim()).Count() > 1500)
                                                                                                                        {
                                                                                                                            errorMsg.Append("CR Demand No. cannot be of more than 1500 characters.");
                                                                                                                        }
                                                                                                                        if ((drEffort["BA Allocated"].ToString().Trim()).Count() > 1500)
                                                                                                                        {
                                                                                                                            errorMsg.Append("BA Allocated cannot be of more than 1500 characters at " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        if ((drEffort["Developers Allocated"].ToString().Trim()).Count() > 1500)
                                                                                                                        {
                                                                                                                            errorMsg.Append("Developers Allocated cannot be of more than 1500 characters at " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        if ((drEffort["SIT Testers"].ToString().Trim()).Count() > 1500)
                                                                                                                        {
                                                                                                                            errorMsg.Append("SIT Testers cannot be of more than 1500 characters at " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        if ((drEffort["Security Testers"].ToString().Trim()).Count() > 1500)
                                                                                                                        {
                                                                                                                            errorMsg.Append("Security Testers cannot be of more than 1500 characters at " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        if ((drEffort["BA Efforts"].ToString().Count()) > 5)
                                                                                                                        {
                                                                                                                            errorMsg.Append("BA Efforts cannot be more than 9999 PDs for " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        else if ((drEffort["BA Efforts"].ToString().Count()) <= 5)
                                                                                                                        {
                                                                                                                            if (Convert.ToDecimal(drEffort["BA Efforts"].ToString()) > 9999)
                                                                                                                            {
                                                                                                                                errorMsg.Append("BA Efforts cannot be more than 9999 PDs for " + drEffort["CR Demand No."] + " .");
                                                                                                                            }
                                                                                                                        }
                                                                                                                        //
                                                                                                                        //{
                                                                                                                        //    errorMsg.Append("BA Efforts cannot be more than 9999 PDs for " + drEffort["CR Demand No."] + " .");
                                                                                                                        //}
                                                                                                                        if ((drEffort["Developer Efforts"].ToString().Count()) > 5)
                                                                                                                        {
                                                                                                                            errorMsg.Append("Developer Efforts cannot be more than 9999 PDs for " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        else if ((drEffort["Developer Efforts"].ToString().Count()) <= 5)
                                                                                                                        {
                                                                                                                            if (Convert.ToDouble(drEffort["Developer Efforts"].ToString()) > 9999.00)
                                                                                                                            {
                                                                                                                                errorMsg.Append("Developer Efforts cannot be more than 9999 PDs for " + drEffort["CR Demand No."] + " .");
                                                                                                                            }
                                                                                                                        }
                                                                                                                        if ((drEffort["Security Efforts"].ToString().Count()) > 5)
                                                                                                                        {
                                                                                                                            errorMsg.Append("Security Efforts cannot be more than 9999 PDs for " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        else if ((drEffort["Security Efforts"].ToString().Count()) <= 5)
                                                                                                                        {
                                                                                                                            if (Convert.ToDouble(drEffort["Security Efforts"].ToString()) > 9999.00)
                                                                                                                            {
                                                                                                                                errorMsg.Append("Security Efforts cannot be more than 9999 PDs for " + drEffort["CR Demand No."] + " .");
                                                                                                                            }
                                                                                                                        }
                                                                                                                        if ((drEffort["SIT Efforts"].ToString().Count()) > 5)
                                                                                                                        {
                                                                                                                            errorMsg.Append("SIT Efforts cannot be more than 9999 PDs for " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        else if ((drEffort["SIT Efforts"].ToString().Count()) <= 5)
                                                                                                                        {

                                                                                                                            if (Convert.ToDouble(drEffort["SIT Efforts"].ToString()) > 9999.00)
                                                                                                                            {
                                                                                                                                errorMsg.Append("SIT Efforts cannot be more than 9999 PDs for " + drEffort["CR Demand No."] + " .");
                                                                                                                            }
                                                                                                                        }
                                                                                                                        if ((drEffort["BA Defects"].ToString().Count()) > 6)
                                                                                                                        {
                                                                                                                            errorMsg.Append("BA Defects cannot be more than 99999 for " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        else if ((drEffort["BA Defects"].ToString().Count()) <= 6)
                                                                                                                        {
                                                                                                                            if (Convert.ToInt32(drEffort["BA Defects"].ToString()) > 99999)
                                                                                                                            {
                                                                                                                                errorMsg.Append("BA Defects cannot be more than 99999 for " + drEffort["CR Demand No."] + " .");
                                                                                                                            }
                                                                                                                        }
                                                                                                                        if ((drEffort["SIT Defects"].ToString().Count()) > 6)
                                                                                                                        {
                                                                                                                            errorMsg.Append("SIT Defects cannot be more than 99999 for " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        else if ((drEffort["SIT Defects"].ToString().Count()) <= 6)
                                                                                                                        {
                                                                                                                            if (Convert.ToInt32(drEffort["SIT Defects"].ToString()) > 99999)
                                                                                                                            {
                                                                                                                                errorMsg.Append("SIT Defects cannot be more than 99999 for " + drEffort["CR Demand No."] + " .");
                                                                                                                            }
                                                                                                                        }
                                                                                                                        if ((drEffort["VF QA Defects"].ToString().Count()) > 6)
                                                                                                                        {
                                                                                                                            errorMsg.Append("VF QA Defects cannot be more than 99999 for " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        else if ((drEffort["VF QA Defects"].ToString().Count()) <= 6)
                                                                                                                        {
                                                                                                                            if (Convert.ToInt32(drEffort["VF QA Defects"].ToString()) > 99999)
                                                                                                                            {
                                                                                                                                errorMsg.Append("VF QA Defects cannot be more than 99999 for " + drEffort["CR Demand No."] + " .");
                                                                                                                            }
                                                                                                                        }
                                                                                                                        if ((drEffort["UAT Defects"].ToString().Count()) > 6)
                                                                                                                        {
                                                                                                                            errorMsg.Append("UAT Defects cannot be more than 99999 for " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        else if ((drEffort["UAT Defects"].ToString().Count()) <= 6)
                                                                                                                        {
                                                                                                                            if (Convert.ToInt32(drEffort["UAT Defects"].ToString()) > 99999)
                                                                                                                            {
                                                                                                                                errorMsg.Append("UAT Defects cannot be more than 99999 for " + drEffort["CR Demand No."] + " .");
                                                                                                                            }
                                                                                                                        }
                                                                                                                        if (drEffort["BA Allocated"].ToString().ToUpper() == "NA" && Convert.ToDouble(drEffort["BA Efforts"].ToString()) != 0.00)
                                                                                                                        {
                                                                                                                            errorMsg.Append("BA Efforts cannot be greater than 0 if BA Allocated is NA at " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        if (drEffort["Developers Allocated"].ToString().ToUpper() == "NA" && Convert.ToDouble(drEffort["Developer Efforts"].ToString()) != 0.00)
                                                                                                                        {
                                                                                                                            errorMsg.Append("Developer Efforts cannot be greater than 0 if Developers Allocated is NA at " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        if (drEffort["Security Testers"].ToString().ToUpper() == "NA" && Convert.ToDouble(drEffort["Security Efforts"].ToString()) != 0.00)
                                                                                                                        {
                                                                                                                            errorMsg.Append("Security Efforts cannot be greater than 0 if Security Testers is NA at " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                        if (drEffort["SIT Testers"].ToString().ToUpper() == "NA" && Convert.ToDouble(drEffort["SIT Efforts"].ToString()) != 0.00)
                                                                                                                        {
                                                                                                                            errorMsg.Append("SIT Efforts cannot be greater than 0 if SIT Testers is NA at " + drEffort["CR Demand No."] + " .");
                                                                                                                        }
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        isDataValid = 0;
                                                                                                                        errorMsg.Append("Construction Start Date is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                                                                                                    }
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    isDataValid = 0;
                                                                                                                    errorMsg.Append("BA Allocated Date is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                                                                                                }
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                isDataValid = 0;
                                                                                                                errorMsg.Append("Go Live Date is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                                                                                            }
                                                                                                        }
                                                                                                        //else
                                                                                                        //   {
                                                                                                        //      errorMsg.Append("Construction Start Date is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                                                                                        //  }
                                                                                                    }
                                                                                                    //else
                                                                                                    //{
                                                                                                    //    errorMsg.Append("BA Allocated Date is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                                                                                    //}
                                                                                                }
                                                                                                //else
                                                                                                //{

                                                                                                //    errorMsg.Append("Go Live Date is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                                                                                //}


                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                isDataValid = 0;
                                                                                                errorMsg.Append("Post Prod Defects is invalid at " + drEffort["CR Demand No."].ToString() + ".");

                                                                                            }

                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            isDataValid = 0;
                                                                                            errorMsg.Append("UAT Defects is invalid at " + drEffort["CR Demand No."].ToString() + ".");

                                                                                        }


                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        isDataValid = 0;
                                                                                        errorMsg.Append("VF QA Defects is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                                                                    }


                                                                                }
                                                                                else
                                                                                {
                                                                                    isDataValid = 0;
                                                                                    errorMsg.Append("SIT Defects is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                                                                }


                                                                            }
                                                                            else
                                                                            {
                                                                                isDataValid = 0;
                                                                                errorMsg.Append("BA Defects is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                                                            }

                                                                        }
                                                                        else
                                                                        {
                                                                            isDataValid = 0;
                                                                            errorMsg.Append("Security Efforts is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        isDataValid = 0;
                                                                        errorMsg.Append("SIT Efforts is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                                                    }

                                                                }
                                                                else
                                                                {
                                                                    isDataValid = 0;
                                                                    errorMsg.Append("Developer Efforts is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                                                }

                                                            }
                                                            else
                                                            {
                                                                isDataValid = 0;
                                                                errorMsg.Append("BA Efforts is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                                            }
                                                        }
                                                        else
                                                        {
                                                            isDataValid = 0;
                                                            errorMsg.Append("Security Testers is invalid at" + drEffort["CR Demand No."].ToString() + ".");


                                                        }
                                                    }
                                                    else
                                                    {
                                                        isDataValid = 0;
                                                        errorMsg.Append("SIT Testers is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                                    }

                                                }
                                                else
                                                {
                                                    isDataValid = 0;
                                                    errorMsg.Append("Developer Allocated is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                                }

                                            }
                                            else
                                            {
                                                isDataValid = 0;
                                                errorMsg.Append("BA Allocated is invalid at " + drEffort["CR Demand No."].ToString() + ".");


                                            }
                                        }
                                        else
                                        {
                                            isDataValid = 0;
                                            errorMsg.Append("CR Demand No. with value " + drEffort["CR Demand No."].ToString() + " is invalid.");

                                        }
                                    }
                                    else
                                    {
                                        errorMsg.Append("Application is invalid at " + drEffort["CR Demand No."].ToString() + ".");
                                    }
                                }
                                else { errorMsg.Append("Application is invalid at " + drEffort["CR Demand No."].ToString() + "."); }
                            }
                            else
                            {
                                isDataValid = 0;
                                errorMsg.Append("Portfolio is invalid at " + drEffort["CR Demand No."].ToString() + ".");

                            }
                        }
                        else { errorMsg.Append("Portfolio is invalid at " + drEffort["CR Demand No."].ToString() + "."); }
                    }
                }

            }

            return errorMsg;
        }

        public void changeEffortListOnDefectCategoryChange(string portfolio, string application, string CrDemandNo,int EffortListID)
        {
            DataTable dtDefectData = fetchDataforBulkUploadDefectGrid(portfolio, application, CrDemandNo);
            if(dtDefectData != null)
            {
                if(dtDefectData.Rows.Count>0)
                {
            DataTable dtCategory = FetchCategoryData();
            DataTable dtFinal = new DataTable();
            dtFinal.Columns.Add("Category");
            dtFinal.Columns.Add("Count");

            string postProd = string.Empty;
            string uat = string.Empty;
            string Ba = string.Empty;
            string sit = string.Empty;
            string vfQa = string.Empty;
                foreach (DataRow drCat in dtCategory.Rows)
                {
                    DataView dvDefectData = new DataView(dtDefectData);
                    dvDefectData.RowFilter = "Category=" + "'" + "" + drCat["Value"].ToString() + "" + "'";
                    DataTable dtTemp = dvDefectData.ToTable();
                    dtFinal.Rows.Add(drCat["Value"].ToString(),dtTemp.Rows.Count);
                    dtTemp.Clear();
                }

                //var queryIT = (from row in dtIT.AsEnumerable()
                //               group row by new
                //               {
                //                   name = row.Field<string>("Status"),
                //                   value = row.Field<int>("Count"),
                //               } into g

                //               select new
                //               {
                //                   name = g.Key.name,
                //                   y = g.Key.value,

                //               }).ToArray();

            //if (dtDefectData != null) 
            //{
            //    DataView dvDefectData = new DataView(dtDefectData);

            //    foreach (DataRow dr in dtDefectData.Rows)
            //    {

            //    }            
            //}


            //var groupedData = (from b in dtDefectData.AsEnumerable()
            //                   group b by b.Field<string>("Category") into g
            //                   select new
            //                   {
            //                       Category = g.Key,
            //                       Count = g.Count()
            //                   }).ToArray();


                for (int i = 0; i <= dtFinal.Rows.Count-1; i++)
                {
                    if (dtFinal.Rows[i]["Category"].ToString() == "BA Defects")
                    {
                        Ba = dtFinal.Rows[i]["Count"].ToString();
                    }
                    if (dtFinal.Rows[i]["Category"].ToString() == "SIT Defects")
                    {
                        sit = dtFinal.Rows[i]["Count"].ToString();
                    }

                    if (dtFinal.Rows[i]["Category"].ToString() == "UAT Defects")
                    {
                        uat = dtFinal.Rows[i]["Count"].ToString();
                    }

                    if (dtFinal.Rows[i]["Category"].ToString() == "VF-QA Defects")
                    {
                        vfQa = dtFinal.Rows[i]["Count"].ToString();
                    }

                    if (dtFinal.Rows[i]["Category"].ToString() == "POST PROD Defects")
                    {
                        postProd = dtFinal.Rows[i]["Count"].ToString();
                    }
                }

                int updated = updateEffortListforDefectCategory(EffortListID, Ba,sit,vfQa,postProd,uat);
        
                }
            }


        }


        public int updateEffortListforDefectCategory(int id, string BADefects, string SITDefects, string VFQADefects, string PostProdDefects, string UATDefects)
        {
            int i = 0;

            string postProdEffortList = string.Empty;
            string uatEffortList = string.Empty;
            string BaEffortList = string.Empty;
            string sitEffortList = string.Empty;
            string vfQaEffortList = string.Empty;

            #region Fetching Category Wise Count from Effort List

            DataTable allTypeDefectCount = fetchAllEffortsData(id.ToString());
            if (allTypeDefectCount != null)
            {
                if (allTypeDefectCount.Rows.Count > 0)
                {
                    postProdEffortList = allTypeDefectCount.Rows[0]["PostProdDefects"].ToString();
                    uatEffortList = allTypeDefectCount.Rows[0]["UATDefects"].ToString();
                    BaEffortList = allTypeDefectCount.Rows[0]["BADefects"].ToString();
                    sitEffortList = allTypeDefectCount.Rows[0]["SITDefects"].ToString();
                    vfQaEffortList = allTypeDefectCount.Rows[0]["VFQADefects"].ToString();
                }
            }

            #endregion

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["EffortsList"];

                        site.AllowUnsafeUpdates = true;
                        web.AllowUnsafeUpdates = true;

                        SPQuery oQuery = new SPQuery();

                        SPListItem itemToUpdate = list.GetItemById(id);

                        if (Convert.ToInt32(BaEffortList) < Convert.ToInt32(BADefects))
                        {
                            itemToUpdate["BADefects"] = BADefects;
                        }
                        if (Convert.ToInt32(sitEffortList) < Convert.ToInt32(SITDefects))
                        {
                            itemToUpdate["SITDefects"] = SITDefects;
                        }
                        if (Convert.ToInt32(vfQaEffortList) < Convert.ToInt32(VFQADefects))
                        {
                            itemToUpdate["VFQADefects"] = VFQADefects;
                        }
                        if (Convert.ToInt32(postProdEffortList) < Convert.ToInt32(PostProdDefects))
                        {
                            itemToUpdate["PostProdDefects"] = PostProdDefects;
                        }
                        if (Convert.ToInt32(uatEffortList) < Convert.ToInt32(UATDefects))
                        {
                            itemToUpdate["UATDefects"] = UATDefects;
                        }
                        itemToUpdate.Update();
                        i = 1;

                    }
                }
            });
            return i;
        }

        public DataTable fetchAllEffortsData(string CrDemandNo)
        {
            DataTable allEfforts = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["EffortsList"];
                            SPQuery oQuery = new SPQuery();
                            if (CrDemandNo == string.Empty)
                            {
                                oQuery.ViewFields = "<FieldRef Name='CRDemandNo'/>";
                                oQuery.ViewFieldsOnly = true;
                                oQuery.Query = "<OrderBy><FieldRef Name='Created' Ascending='False' /></OrderBy>";
                            }
                            else if (CrDemandNo != string.Empty)
                            {
                                oQuery.ViewFields = "<FieldRef Name='BADefects'/><FieldRef Name='SITDefects'/><FieldRef Name='VFQADefects'/><FieldRef Name='UATDefects'/><FieldRef Name='PostProdDefects'/>";
                                oQuery.ViewFieldsOnly = true;
                                oQuery.Query = "<Where><Eq><FieldRef Name='ID' /><Value Type='Counter'>"+CrDemandNo+"</Value></Eq></Where>";
                               
                            }
                            allEfforts = list.GetItems(oQuery).GetDataTable();

                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return allEfforts;

        }

        public DataTable fetchAllDefectData(string effortListID)
        {
            DataTable allDefects = new DataTable();
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["DefectDetails"];
                            SPQuery oQuery = new SPQuery();
                            if (effortListID == string.Empty)
                            {
                                oQuery.ViewFields = "<FieldRef Name='Title'/>";
                                oQuery.ViewFieldsOnly = true;
                                oQuery.Query = "";
                            }
                            else if (effortListID != string.Empty)
                            {
                                oQuery.ViewFields = "<FieldRef Name='Category'/>";
                                oQuery.ViewFieldsOnly = true;
                                oQuery.Query = "<Where><Eq><FieldRef Name='EffortListID' /><Value Type='Lookup'>" + effortListID + "</Value></Eq></Where>";
                            }
                            allDefects = list.GetItems(oQuery).GetDataTable();

                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return allDefects;

        }

        public int deleteDefectGrid(int defectId)
        {
            int deleted = 0;
            try
            {

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists["DefectDetails"];

                            site.AllowUnsafeUpdates = true;
                            web.AllowUnsafeUpdates = true;
                            SPQuery oQuery = new SPQuery();
                            SPListItem itemToDelete = list.GetItemById(defectId);
                            itemToDelete.Delete();
                            deleted = 1;

                        }
                    }
                });
            }
            catch (Exception ex)
            {
            }
            return deleted;
        }

        #endregion
    }
}
