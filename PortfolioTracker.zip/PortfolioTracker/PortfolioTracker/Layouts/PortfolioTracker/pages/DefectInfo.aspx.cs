﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Data;

namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
    public partial class DefectInfo : LayoutsPageBase
    {
        string userRole = string.Empty;
        string userName = string.Empty;
        DataTable userSession = new DataTable();
        string portfolioId = string.Empty;
        string defectId = string.Empty;
        BusinessClass bcObj = new BusinessClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserDetails"] == null)
                {
                    Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/ErrorPage.aspx");
                }
                if (Session["DefectCausalData"] != null)
                {
                    string result = Session["DefectCausalData"].ToString();

                    if (result != string.Empty)
                    {
                        ClientScript.RegisterHiddenField("masterData", result);
                    }
                }
                if (!IsPostBack)
                {
                    //Session["PortfolioID"] = "1";
                    //if (Session["PortfolioID"] != null)
                    //{
                    //    portfolioId = Session["PortfolioID"].ToString();
                    //}
                    if (Session["UserDetails"] != null)
                    {
                        userSession = (DataTable)Session["UserDetails"];
                        if (userSession != null)
                        {
                            if (userSession.Rows.Count > 0)
                            {
                                userRole = userSession.Rows[0]["Role"].ToString();
                                userName = userSession.Rows[0]["Name"].ToString();
                                portfolioId = userSession.Rows[0]["Title"].ToString();

                                lblloggedInUser.Text = "Welcome," + userName + " | " + userRole;

                                if (Session["DefectCausalData"] != null)
                                {
                                    string result = Session["DefectCausalData"].ToString();

                                    if (result != string.Empty)
                                    {
                                        ClientScript.RegisterHiddenField("masterData", result);
                                    }
                                }
                            }
                        }


                    }
                    defectId = Request.QueryString["ID"] != null ? Request.QueryString["ID"].ToString() : string.Empty;
                    BindGrid();
                }
            }
            catch (Exception ex) { 
            }
        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                if (ViewState["griddata"] != null)
                {
                  //  BindGrid();
                    grdGetDefectInfo.DataSource=(ViewState["griddata"]);
                    grdGetDefectInfo.PageIndex = e.NewPageIndex;
                    grdGetDefectInfo.DataBind();
                }
               
                
            }
            catch (Exception ex)
            { }
        }
        private void BindGrid() {
            try
            {
                DataTable dt = bcObj.GetDefectInfo(defectId);

                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        grdGetDefectInfo.DataSource = dt;
                        grdGetDefectInfo.DataBind();
                        lblMsg.Visible = false;
                        ViewState["griddata"] = dt;
                    }
                    else
                    {
                        grdGetDefectInfo.DataSource = null;
                        grdGetDefectInfo.DataBind();
                        lblMsg.Visible = true;
                    }
                }
                else {

                    grdGetDefectInfo.DataSource = null;
                    grdGetDefectInfo.DataBind();
                    lblMsg.Visible = true;
                }
                   
             
               
            }
            catch (Exception ex) { }
        }
    }
}
