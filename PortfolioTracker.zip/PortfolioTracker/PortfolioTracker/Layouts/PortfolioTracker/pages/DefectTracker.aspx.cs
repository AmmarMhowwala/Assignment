﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Data;
using System.Web.UI.WebControls;
using System.Text;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;
using System.Web.UI;

namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
    public partial class DefectTracker : LayoutsPageBase
    {
        string portfolioId = string.Empty;
        string userRole = string.Empty;
        string userName = string.Empty;
        DataTable userSession = new DataTable();
        BusinessClass bcObj = new BusinessClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            try {
                //Response.Cache.SetCacheability(HttpCacheability.NoCache);
                //Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
                //Response.Cache.SetNoStore();
                if (Session["UserDetails"] == null)
                {
                    Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/ErrorPage.aspx");
                }
                if (Session["DefectCausalData"] != null)
                {
                    string result = Session["DefectCausalData"].ToString();

                    if (result != string.Empty)
                    {
                        ClientScript.RegisterHiddenField("masterData", result);
                    }
                }
                if (!IsPostBack)
                {
                    if (Session["UserDetails"] != null)
                    {
                        userSession = (DataTable)Session["UserDetails"];
                        if (userSession != null)
                        {
                            if (userSession.Rows.Count > 0)
                            {
                                userRole = userSession.Rows[0]["Role"].ToString();
                                userName = userSession.Rows[0]["Name"].ToString();
                                portfolioId = userSession.Rows[0]["Title"].ToString();
                                
                                lblloggedInUser.Text = "Welcome," + userName + " | " + userRole;

                                //if (Session["DefectCausalData"] != null)
                                //{
                                //    string result = Session["DefectCausalData"].ToString();

                                //    if (result != string.Empty)
                                //    {
                                //        ClientScript.RegisterHiddenField("masterData", result);
                                //    }
                                //}
                            }
                        }


                    }
                    //Session["PortfolioID"] = "1";
                    //if (Session["PortfolioID"] != null)
                    //{
                    //    portfolioId = Session["PortfolioID"].ToString();
                    //}
                    populateDropdown(portfolioId);
                    btnGetInfo.Visible = false;
                   
                }
                else
                {
                    if (Request.Form["__EVENTTARGET"] == "_EVENTARGS")
                    {
                        if (HttpContext.Current.Request.HttpMethod == "POST")
                        {
                            string defectDtls = GetDefectDataINJson();
                            ClientScript.RegisterHiddenField("DefectDtls", defectDtls);
                          
                        }
                    }
                    
                }
               
            }
            catch (Exception ex) { 
            
            }
            
        }

        private void populateDropdown(string portfolioId)
        {
            try
            {

                Session["DefectCausalData"] = null;
                ClientScript.RegisterHiddenField("DropdownChange", "true");
                DataTable dtPortfolio = bcObj.FetchPortfolioData(portfolioId);
                ddlPortfolio.DataSource = dtPortfolio;
                ddlPortfolio.DataTextField = "Portfolio";
                ddlPortfolio.DataValueField = "Portfolio";
                ddlPortfolio.DataBind();
                ListItem item = new ListItem("Select");
                ddlPortfolio.Items.Insert(0, item);
                ddlApplication.Items.Insert(0, item);
                ddlDemand.Items.Insert(0, item);
                btnGetInfo.Visible = false;
                grdGetInfo.Visible = false;

            }
            catch (Exception ex)
            {

            }
          
        }
        protected void ApplicationDataUpdate(Object sender, EventArgs e) 
        {
            try
            {
                Session["DefectCausalData"] = null;
                ClientScript.RegisterHiddenField("DropdownChange", "true");
                ddlDemand.Items.Clear();
                ddlApplication.Items.Clear();
                DataTable dtApplication = bcObj.FetchApplicationData(ddlPortfolio.SelectedValue.Trim());
                ddlApplication.DataSource = dtApplication;
                ddlApplication.DataTextField = "Application";
                ddlApplication.DataValueField = "Application";
                ddlApplication.DataBind();
                ddlApplication.Items.Insert(0, "Select");
                ddlDemand.Items.Insert(0, "Select");
                btnGetInfo.Visible = false;
                grdGetInfo.Visible = false;

            }
            catch (Exception ex)
            {

            }
           
          
        }
        protected void DemandDataUpdate(Object sender, EventArgs e) 
        {
            try
            {
                Session["DefectCausalData"] = null;
                ClientScript.RegisterHiddenField("DropdownChange", "true");
                ddlDemand.Items.Clear();
                DataTable dtDemand = bcObj.FetchDemandsByApplication(ddlApplication.SelectedValue.Trim());
                ddlDemand.DataSource = dtDemand;
                ddlDemand.DataTextField = "CRDemandNo";
                ddlDemand.DataValueField = "CRDemandNo";
                ddlDemand.DataBind();
                ddlDemand.Items.Insert(0, "Select");
                btnGetInfo.Visible = false;
                grdGetInfo.Visible = false;
            }
            catch (Exception ex)
            {

            }
           
           
        }
        protected void DataUpdate(Object sender, EventArgs e) 
        {
            try
            {
                Session["DefectCausalData"] = null;
                ClientScript.RegisterHiddenField("DropdownChange", "true");
                btnGetInfo.Visible = false;
                grdGetInfo.Visible = false;
            }
            catch (Exception ex)
            {

            }
           
           
        }
        

        protected void btnView_Click(Object sender, EventArgs e)
        {
            
            try
            {
                string msg = ddlSelectionCheck();
                if (msg == string.Empty)
                {
                    if (HttpContext.Current.Request.HttpMethod == "POST")
                    {
                        string defectDtls = GetDefectDataINJson();
                        ClientScript.RegisterHiddenField("DefectDtls", defectDtls);
                        if (defectDtls == string.Empty)
                        {
                            btnGetInfo.Visible = false;
                        }
                        else
                        {
                            btnGetInfo.Visible = true;
                        }
                        grdGetInfo.Visible = false;
                        FetchAllDefect();
                    }

                }
                else
                { 
                ScriptManager.RegisterStartupScript(this.Page,this.GetType(),"err","<script type='text/javascript'>alert('"+ msg +"');</script>",false);
                }
            }
            catch (Exception ex) { 
            
            }
        
        }

        private string GetCausalAnalysisInJson()
        {
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
            List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
            try
            {
                DataTable dt = bcObj.getCausalAnalysisData(ddlPortfolio.SelectedValue, ddlApplication.SelectedValue, ddlDemand.SelectedValue);
                
                Dictionary<string, object> childRow;
                foreach (DataRow row in dt.Rows)
                {
                    childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in dt.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    parentRow.Add(childRow);
                }
            }
            catch (Exception ex) { }
            return jsSerializer.Serialize(parentRow);   
                     
        }

        private string GetDefectDataINJson()
        {
            string values = string.Empty;
            DataTable dt = new DataTable();
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            //List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            //Dictionary<string, object> row;
            try
            {
                dt = bcObj.FetchDefects(ddlPortfolio.SelectedValue, ddlApplication.SelectedValue, ddlDemand.SelectedValue, "1");
                DataTable dtFinal = new DataTable();
                dtFinal.Columns.Add("DefectType", typeof(string));
                dtFinal.Columns.Add("NoOfDefects", typeof(int));

                foreach (DataRow row in dt.Rows)
                {
                    if (Convert.ToInt32(row["BADefects"]) == 0 && Convert.ToInt32(row["SITDefects"]) == 0 && Convert.ToInt32(row["VFQADefects"]) == 0 && Convert.ToInt32(row["PostProdDefects"]) == 0)
                    {
                     values = string.Empty;
                    }
                    else
                    {
                        foreach (DataColumn col in dt.Columns)
                        {
                            dtFinal.Rows.Add(col.ColumnName, row[col]);
                        }

                        var query = (from dr in dtFinal.AsEnumerable()
                                     group dr by new
                                     {
                                         name = dr.Field<string>("DefectType"),
                                         value = dr.Field<int>("NoOfDefects")

                                     } into g

                                     select new
                                     {
                                         name = g.Key.name,
                                         y = g.Key.value,
                                     }).ToArray();

                        if (query.Length > 0)
                        {
                            values = new JavaScriptSerializer().Serialize(query);
                            btnGetInfo.Visible = true;
                            grdGetInfo.Visible = true;

                        }
                        else
                        {
                            values = "";
                            btnGetInfo.Visible = false;
                            grdGetInfo.Visible = false;
                        }

                    }
                   
                       
                }
            }
            catch (Exception ex)
            {
            }
            return values;
        }

        private string ddlSelectionCheck()
        {
           
            StringBuilder msg = new StringBuilder();
            try
            {
                if (ddlPortfolio.SelectedValue == "Select" || ddlApplication.SelectedValue == "Select" || ddlDemand.SelectedValue == "Select")
                {
                    msg.Append("Please select dropdown values before proceeding.");
                }
                else
                {
                    msg.Append(string.Empty);
                }
            }
            catch (Exception ex) { }
            
            return msg.ToString();
        }

        protected void btnGetInfo_Click(Object sender, EventArgs e)
        {
            grdGetInfo.PageIndex = 0;
            try
            {
                if (HttpContext.Current.Request.HttpMethod == "POST")
                {
                    string defectDtls = GetDefectDataINJson();
                    ClientScript.RegisterHiddenField("DefectDtls", defectDtls);
                    leftSec.Attributes.Add("class", "secChng");
                    FetchAllDefect();
                }
                BindGrid();
                grdGetInfo.Visible = true;
            }
            catch (Exception ex) { }
        }

        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdGetInfo.PageIndex = e.NewPageIndex;
                this.BindGrid();
            }
            catch (Exception ex) { }
        }

        private void BindGrid()
        {
            DataTable dt = new DataTable();
            try 
            {
                dt = bcObj.FetchDefects(ddlPortfolio.SelectedValue, ddlApplication.SelectedValue, ddlDemand.SelectedValue, "0");

                if (dt != null)
                {
                    grdGetInfo.DataSource = dt;
                    grdGetInfo.DataBind();
                }
            }
            catch (Exception ex)
            {
            }
        }

        protected void FetchAllDefect()
        {
            
            string result = string.Empty;
            try
            {
                DataTable dtDefects = bcObj.getCausalAnalysisData(ddlPortfolio.SelectedValue, ddlApplication.SelectedValue, ddlDemand.SelectedValue);
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();

                if (dtDefects != null)
                {
                    if (dtDefects.Rows.Count > 0)
                    {
                        result = calculateCausalWiseData(Constant.causalAnalysis, "BA Defects", dtDefects) + "---" +
                                 calculateCausalWiseData(Constant.causalAnalysis, "SIT Defects", dtDefects) + "---" +
                                 calculateCausalWiseData(Constant.causalAnalysis, "UAT Defects", dtDefects) + "---" +
                                 calculateCausalWiseData(Constant.causalAnalysis, "VF-QA Defects", dtDefects) + "---" +
                                 calculateCausalWiseData(Constant.causalAnalysis, "POST PROD Defects", dtDefects);
                    }
                    
                }
                Session["DefectCausalData"] = result;
                ClientScript.RegisterHiddenField("masterData", result);
            }
            catch (Exception ex) { }
        }

        protected string calculateCausalWiseData(string[] causalAnalysis, string phases, DataTable dtMaster)
        {
            string values = string.Empty;
            DataTable dtDefectType = new DataTable();
            dtDefectType.Columns.Add("Causal");
            dtDefectType.Columns.Add("Phases");
            dtDefectType.Columns.Add("Count", typeof(int));

            try
            {
                foreach (string causal in causalAnalysis)
                {
                    DataView dv_temp = dtMaster.DefaultView;
                    dv_temp.RowFilter = "CausalAnalysis = " + "'" + causal + "'" + " AND Category =" + "'" + phases + "'";
                    DataTable dt_Temp = dv_temp.ToTable();
                    dtDefectType.Rows.Add(causal, phases, dt_Temp.Rows.Count);
                    dtDefectType.AcceptChanges();
                }

                


                var query = (from row in dtDefectType.AsEnumerable()
                             group row by new
                             {
                                 Causal = row.Field<string>("Causal"),
                                 name = row.Field<string>("Phases"),
                                 value = row.Field<int>("Count")


                             } into g

                             select new
                             {
                                 Causal = g.Key.Causal,
                                 name = g.Key.name,
                                 y = g.Key.value,
                             }).ToArray();

                if (query.Length > 0)
                {
                    values = new JavaScriptSerializer().Serialize(query);
                }
                else
                {
                    values = "0";
                }
            }
            catch (Exception ex)
            {

            }
            return values;
        }

        protected void lnkDefectInfo_Click(Object sender, EventArgs e)
        {
            try
            {
                if (HttpContext.Current.Request.HttpMethod == "POST")
                {
                    string defectDtls = GetDefectDataINJson();
                    ClientScript.RegisterHiddenField("DefectDtls", defectDtls);
                    leftSec.Attributes.Add("class", "secChng");
                    FetchAllDefect();
                }
                LinkButton lnkbtn = sender as LinkButton;
                GridViewRow row = (GridViewRow)lnkbtn.NamingContainer;
                Label lblID = (Label)row.FindControl("lblID");
                string rowId = lblID.Text;
                string url = SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/DefectInfo.aspx?ID=" + rowId;
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>portal_modalDialogClosedCallback('Defect Info','" + url + "')</script>", false);
            }
            catch (Exception ex) { }
        }

        protected void imgbtnLogOut_Click(Object sender, EventArgs e)
        {
            Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/LogOut.aspx");
        }
      
       
    }
}
