﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
    public partial class UploadDefectAnalysis : LayoutsPageBase
    {
        string TempFolderForAddEdit = "C:\\PortfolioTrackerAttachments\\";
        string bulkUpldErrMsg = "The uploaded file format is not supported.";
        string successMsg = "File successfully uploaded.To view or update the data,Please select required fields and click on View.";
        string errorMsg = "Your file could not be uploaded.Please check all fields and try again. ";
        string portfolioId = string.Empty;
        string effortListId = string.Empty;
        string userRole = string.Empty;
        string userName = string.Empty;
        DataTable userSession = new DataTable();
        string defectId = string.Empty;
        int excelRowColCount = 5;
        int fileUploaded = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserDetails"] == null)
                {
                    Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/ErrorPage.aspx");
                }

                if (!IsPostBack)
                {
                    if (Session["UserDetails"] != null)
                    {
                        userSession = (DataTable)Session["UserDetails"];
                        if (userSession != null)
                        {
                            if (userSession.Rows.Count > 0)
                            {
                                userRole = userSession.Rows[0]["Role"].ToString();
                                userName = userSession.Rows[0]["Name"].ToString();
                                portfolioId = userSession.Rows[0]["Title"].ToString();

                                lblloggedInUser.Text = "Welcome," + userName + " | " + userRole;
                            }
                        }


                    }

                }
                effortListId = Request.QueryString["ID"] != null ? Request.QueryString["ID"].ToString() : string.Empty;
            }
            catch (Exception ex)
            {
            }
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            //Save the uploaded Excel file.
            BusinessClass bClass = new BusinessClass();

            string strFileType = System.IO.Path.GetExtension(upldDefectList.FileName).ToString().ToLower();

            if (strFileType != string.Empty)
            {
                if (strFileType != ".xls" && strFileType != ".xlsx")
                {

                    lblMsg.Visible = true;
                    lblMsg.Text = bulkUpldErrMsg;
                }
                else
                {
                    if (upldDefectList.FileName.Trim() == string.Empty)
                    {
                        lblMsg.Text = bulkUpldErrMsg;
                    }
                    else
                    {
                        string filePath = TempFolderForAddEdit + Path.GetFileName(upldDefectList.PostedFile.FileName);
                        upldDefectList.SaveAs(filePath);

                        //Open the Excel file in Read Mode using OpenXml.
                        using (SpreadsheetDocument doc = SpreadsheetDocument.Open(filePath, false))
                        {
                            //Read the first Sheet from Excel file.
                            Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();

                            //Get the Worksheet instance.
                            Worksheet worksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;

                            //Fetch all the rows present in the Worksheet.
                            IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Descendants<Row>();


                            //Create a new DataTable.
                            DataTable dt = new DataTable();

                            //Loop through the Worksheet rows.
                            foreach (Row row in rows)
                            {
                                //Use the first row to add columns to DataTable.
                                if (row.RowIndex.Value == 1)
                                {

                                    foreach (Cell cell in row.Descendants<Cell>())
                                    {
                                        string tempColName = GetValue(doc, cell);

                                        if (tempColName.Trim() == "Defect" || tempColName.Trim() == "Causal Analysis" || tempColName.Trim() == "Severity" || tempColName.Trim() == "Category" || tempColName.Trim() == "Status")
                                        {
                                            dt.Columns.Add(tempColName);
                                        }
                                        else
                                        {
                                            lblMsg.Visible = true;
                                            lblMsg.Text = "File not in correct template.Please download template and try again.";
                                            break;
                                        }
                                    }
                                    if (dt == null)
                                    {
                                        lblMsg.Visible = true;
                                        lblMsg.Text = "File not in correct template.Please download template and try again.";
                                        break;
                                    }
                                    else
                                    {
                                        if (dt.Columns.Count == excelRowColCount)
                                        {
                                            string defect = dt.Columns[0].ToString() != null && dt.Columns[0].ToString() != string.Empty ? dt.Columns[0].ToString() : string.Empty;
                                            string causal = dt.Columns[1].ToString() != null && dt.Columns[1].ToString() != string.Empty ? dt.Columns[1].ToString() : string.Empty;
                                            string severity = dt.Columns[2].ToString() != null && dt.Columns[2].ToString() != string.Empty ? dt.Columns[2].ToString() : string.Empty;
                                            string category = dt.Columns[3].ToString() != null && dt.Columns[3].ToString() != string.Empty ? dt.Columns[3].ToString() : string.Empty;
                                            string status = dt.Columns[4].ToString() != null && dt.Columns[4].ToString() != string.Empty ? dt.Columns[4].ToString() : string.Empty;

                                            if (defect == "Defect" && causal == "Causal Analysis" && severity == "Severity" && category == "Category" && status == "Status")
                                            {

                                            }

                                            else
                                            {
                                                lblMsg.Visible = true;
                                                lblMsg.Text = "File not in correct template.Please download template and try again.";
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            lblMsg.Visible = true;
                                            lblMsg.Text = "File not in correct template.Please download template and try again.";
                                            break;

                                        }

                                    }
                                }
                                else
                                {
                                    //Add rows to DataTable.
                                    if (dt != null)
                                    {
                                        dt.Rows.Add();
                                        int i = 0;
                                       
                                            foreach (Cell cell in row.Descendants<Cell>())
                                            {
                                                if (i <= 4)
                                                {
                                                    if (i == 1 || i == 4)
                                                    {
                                                        string TitleCased = GetValue(doc, cell);

                                                        TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                                                        TitleCased = textInfo.ToTitleCase(TitleCased.ToLower());
                                                        dt.Rows[dt.Rows.Count - 1][i] = TitleCased;

                                                    }
                                                    else if( i == 2 )
                                                    {
                                                        dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell).ToUpper();
                                                    }
                                                    else if(i == 3)
                                                    {
                                                        string category = GetValue(doc, cell);
                                                        int charLocation = category.IndexOf("Defects", StringComparison.Ordinal);

                                                        if (charLocation > 0)
                                                        {
                                                            string catUpper = category.Substring(0, charLocation);
                                                            string finalCategory = catUpper.ToUpper() + "" + "Defects";
                                                            dt.Rows[dt.Rows.Count - 1][i] = finalCategory;
                                                        }
                                                        else 
                                                        {
                                                            dt.Rows[dt.Rows.Count - 1][i] = category;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell);
                                                    }
                                                i++;
                                                }
                                        }
                                    }
                                }
                            }

                            if (dt != null)
                            {
                                if (dt.Columns.Count == excelRowColCount)
                                {
                                    if (dt.Rows.Count > 0)
                                    {
                                        if (dt.Rows.Count <= 50)
                                        {

                                            StringBuilder err = bClass.ValidateDefectListData(dt,effortListId);
                                            string errString = err.ToString();

                                            if (errString == string.Empty)
                                            {
                                                fileUploaded = bClass.insertBulkUploadDataToDefectList(dt, effortListId);

                                                if (fileUploaded == 1)
                                                {
                                                    lblMsg.Visible = true;
                                                    lblMsg.Text = successMsg;
                                                }
                                                else
                                                {
                                                    lblMsg.Visible = true;
                                                    lblMsg.Text = errorMsg;

                                                }
                                            }
                                            else
                                            {
                                                lblMsg.Visible = true;
                                                lblMsg.Text = errString;
                                            }
                                        }
                                        else
                                        {

                                            lblMsg.Visible = true;
                                            lblMsg.Text = "The file cannot have more than 50 rows";
                                        }
                                    }
                                    else
                                    {
                                        lblMsg.Visible = true;
                                        lblMsg.Text = "The file cannot be empty.Please enter data and upload again";
                                    }
                                }
                                else
                                {
                                    lblMsg.Visible = true;
                                    lblMsg.Text = "File not in correct template.Please download template and try again.";
                                }
                            }

                        }
                        //Delete file from temp folder:-
                        FileInfo file = new FileInfo(filePath);
                        if (file.Exists)
                        {
                            file.Delete();
                        }
                    }
                }
            }
            else
            {
                lblMsg.Visible = true;
                lblMsg.Text = "Please select a file to upload.";
            }

        }

        private string GetValue(SpreadsheetDocument doc, Cell cell)
        {
            string value = cell.CellValue.InnerText;

            string cellType = cell.DataType;

            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return doc.WorkbookPart.SharedStringTablePart.SharedStringTable.ChildElements.GetItem(int.Parse(value)).InnerText;
            }
            return value;
        }

    }
}
