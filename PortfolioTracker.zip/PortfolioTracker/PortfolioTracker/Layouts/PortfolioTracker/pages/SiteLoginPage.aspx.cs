﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Data;
using System.Text;

namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
    public partial class SiteLoginPage : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["UserDetails"] == null)
            {
                LoginButton.Disabled = false;
            }
            else 
            {
                LoginButton.Disabled = true;
            }
        }

        protected void loginApplication(object sender, EventArgs e)
        {
            lblErrorMsg.Text = string.Empty;
            BusinessClass userstore=new BusinessClass();
            StringBuilder sbErrorMessages = new StringBuilder();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            if (username == string.Empty || password == string.Empty)
                sbErrorMessages.Append("Username or Password cannot be null");
           
            DataTable loginDetails = new DataTable();
            loginDetails = null;
            if (username != string.Empty && password != string.Empty)
            {
                loginDetails = userstore.FetchUserDetails(username);



                if (loginDetails != null)
                {
                    if (loginDetails.Rows[0]["Password"].ToString() == password)

                    //if (username.Equals("admin") && password.Equals("admin"))
                    {
                        Session["UserDetails"] = loginDetails;
                        //Response.Redirect("~/pages/HomePage.aspx", false);
                        Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/HomePage.aspx");
                    }


                    else
                    {
                        sbErrorMessages.Append("The password does not match with the username");
                    }
                }
                else
                    sbErrorMessages.Append("This username does not exist!");
            }
            //Session.Add("UserDetails", loginDetails);
           
            lblErrorMsg.Text = sbErrorMessages.ToString();
            lblErrorMsg.CssClass = "error";
            lblErrorMsg.Visible = true;
        }
            
    }
}
