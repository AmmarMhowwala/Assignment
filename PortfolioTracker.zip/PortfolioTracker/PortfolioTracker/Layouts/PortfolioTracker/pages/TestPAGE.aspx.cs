﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
    public partial class TestPAGE : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
