﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;
using System.IO;
using System.Collections.Generic;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Web.UI;
using System.Globalization;
using System.Text.RegularExpressions;


namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{

    public partial class BulkUpload : LayoutsPageBase
    {
        #region Variables

        BusinessClass bClass = new BusinessClass();
        string TempFolderForAddEdit = "C:\\PortfolioTrackerAttachments\\";
        string bulkUpldErrMsg = "The uploaded file format is not supported.";
        string portfolioId = string.Empty;
        string successMsg = "File successfully uploaded.To view or update the data,Please select required fields and click on View.";
        string errorMsg = "Your file could not be uploaded.Please check all fields and try again. ";
        string BaAllocatedDate = "BA Allocated Date";
        string constructionStartDate = "Construction Start Date";
        string goLiveDate = "Go Live Date";
        string locBaAllocatedDate = string.Empty;
        string locConstructionStartDate = string.Empty;
        string locGoLiveDate = string.Empty;
        string userRole = string.Empty;
        string userName = string.Empty;
        int fileUploaded = 0;
        int excelRowColCount = 19;
        int counter = 0;

        int BaDefects = 0;
        int sitDefects = 0;
        int uatDefects = 0;
        int vfQaDefects = 0;
        int postProdDefects = 0;

        DataTable userSession = new DataTable();

        #endregion

        #region Page Load

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserDetails"] == null)
                {
                    Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/ErrorPage.aspx");
                }

                if (Session["UserDetails"] != null)
                {
                    userSession = (DataTable)Session["UserDetails"];
                    if (userSession != null)
                    {
                        if (userSession.Rows.Count > 0)
                        {
                            portfolioId = userSession.Rows[0]["Title"].ToString();
                           // msgBox.Visible = true;
                           // lblNodata.Visible = true;
                        }
                    }
                }

                if (!IsPostBack)
                {

                    if (Session["UserDetails"] != null)
                    {
                        userSession = (DataTable)Session["UserDetails"];
                        if (userSession != null)
                        {
                            if (userSession.Rows.Count > 0)
                            {
                                userRole = userSession.Rows[0]["Role"].ToString();
                                userName = userSession.Rows[0]["Name"].ToString();
                                portfolioId = userSession.Rows[0]["Title"].ToString();

                                lblloggedInUser.Text = "Welcome," + userName + " | " + userRole;
                                msgBox.Visible = true;
                                lblNodata.Visible = true;
                            }
                        }

                        Response.Buffer = true;
                        Response.CacheControl = "no-cache";
                        Response.AddHeader("Pragma", "no-cache");
                        Response.Expires = -1441;
                        Response.AppendHeader("Cache-Control","no-store");

                      
                    }

                    //Session["PortfolioID"] = "1";
                    //if (Session["PortfolioID"] != null)
                    //{
                    //    portfolioId = Session["PortfolioID"].ToString();
                    //}
                    populateDropdown(portfolioId);
                    //divGrid.Visible = false;
                    divCrDemandNo.Visible = false;
                    msgBox.Visible = true;
                    lblNodata.Visible = true;
                    //grdDefectData.Visible = false;
                    //grdEffortBulkUpload.Visible = false;

                }

                else
                {
                    if (Request.Form["__EVENTTARGET"] == "_EVENTARGS")
                    {
                        if (HttpContext.Current.Request.HttpMethod == "POST")
                        {


                        }
                    }

                }

            }
            catch (Exception ex)
            {

            }
        }

        #endregion

        #region Dropdowns : Bind and Change Events

        private void populateDropdown(string portfolioId)
        {
            try
            {
                DataTable dtType = new DataTable();
                dtType.Columns.Add("Type");
                dtType.Rows.Add("Effort List");
                dtType.Rows.Add("Defect List");
                ddlType.DataSource = dtType;
                ddlType.DataTextField = "Type";
                ddlType.DataValueField = "Type";
                ddlType.DataBind();

                DataTable dtPortfolio = bClass.FetchPortfolioData(portfolioId);
                ddlPortfolio.DataSource = dtPortfolio;
                ddlPortfolio.DataTextField = "Portfolio";
                ddlPortfolio.DataValueField = "Portfolio";
                ddlPortfolio.DataBind();
                ListItem item = new ListItem("Select");

                //Insert "Select at first position"
                ddlType.Items.Insert(0, item);
                ddlPortfolio.Items.Insert(0, item);
                ddlApplication.Items.Insert(0, item);
                ddlCrDemandNo.Items.Insert(0, item);
                //grdDefectData.Visible = false;
                //grdEffortBulkUpload.Visible = false;
                msgBox.Visible = true;
                lblNodata.Visible = true;
                lblErrorMessage.Visible = false;
               

            }
            catch (Exception ex)
            {

            }

        }

        protected void ApplicationDataUpdate(Object sender, EventArgs e)
        {
            try
            {


                ddlApplication.Items.Clear();
                DataTable dtApplication = bClass.FetchApplicationData(ddlPortfolio.SelectedValue.Trim());
                ddlApplication.DataSource = dtApplication;
                ddlApplication.DataTextField = "Application";
                ddlApplication.DataValueField = "Application";
                ddlApplication.DataBind();
                ddlApplication.Items.Insert(0, "Select");
                ddlCrDemandNo.Items.Clear();
                ddlCrDemandNo.Items.Insert(0, "Select");

                msgBox.Visible = true;
                lblNodata.Visible = true;
                lblgridMsg.Visible = false;
                grdDefectData.Visible = false;
                grdEffortBulkUpload.Visible = false;
                lblErrorMessage.Visible = false;



            }
            catch (Exception ex)
            {

            }


        }

        protected void DemandDataUpdate(Object sender, EventArgs e)
        {
            try
            {
                if (ddlType.SelectedValue.Trim() == "Defect List")
                {
                    ddlCrDemandNo.Items.Clear();
                    DataTable dtDemand = bClass.FetchDemandsByApplication(ddlApplication.SelectedValue.Trim());
                    ddlCrDemandNo.DataSource = dtDemand;
                    ddlCrDemandNo.DataTextField = "CRDemandNo";
                    ddlCrDemandNo.DataValueField = "CRDemandNo";
                    ddlCrDemandNo.DataBind();
                    ddlCrDemandNo.Items.Insert(0, "Select");

                }
                else
                {
                }
               
                lblgridMsg.Visible = false;
                msgBox.Visible = true;
                lblNodata.Visible = true;
                grdDefectData.Visible = false;
                grdEffortBulkUpload.Visible = false;
                lblErrorMessage.Visible = false;
            }
            catch (Exception ex)
            {

            }


        }

        protected void ddlType_OnSelectedIndexChanged(Object sender, EventArgs e)
        {
            try
            {
                //grdDefectData.Visible = false;
                //grdEffortBulkUpload.Visible = false;

                if (ddlType.SelectedValue == "Defect List")
                {
                    divCrDemandNo.Visible = true;

                }
                else
                {
                    divCrDemandNo.Visible = false;
                }
                ddlPortfolio.Items.Clear();
                DataTable dtPortfolio = bClass.FetchPortfolioData(portfolioId);
                ddlPortfolio.DataSource = dtPortfolio;
                ddlPortfolio.DataTextField = "Portfolio";
                ddlPortfolio.DataValueField = "Portfolio";
                ddlPortfolio.DataBind();
                ListItem item = new ListItem("Select");
                ddlPortfolio.Items.Insert(0, item);

                ddlCrDemandNo.Items.Clear();
                ddlCrDemandNo.Items.Insert(0, "Select");

                ddlApplication.Items.Clear();
                ddlApplication.Items.Insert(0, "Select");

                msgBox.Visible = true;
                lblNodata.Visible = true;
                lblgridMsg.Visible = false;
                lblErrorMessage.Visible = false;
                grdDefectData.Visible = false;
                grdEffortBulkUpload.Visible = false;

            }
            catch (Exception ex)
            {

            }


        }

        protected void ddlCrDemandNo_Change(Object sender, EventArgs e)
        {
            msgBox.Visible = true;
            lblNodata.Visible = true;
            lblErrorMessage.Visible = false;
            lblgridMsg.Visible = false;
            grdDefectData.Visible = false;
            grdEffortBulkUpload.Visible = false;

        }

        private string ddlSelectionCheck()
        {

            StringBuilder msg = new StringBuilder();
            try
            {
                if (ddlType.SelectedValue.Trim() == "Effort List")
                {
                    if (ddlPortfolio.SelectedValue == "Select" || ddlApplication.SelectedValue == "Select")
                    {
                        msg.Append("Please select dropdown values before proceeding.");
                    }
                    else
                    {
                        msg.Append(string.Empty);
                    }

                }
                else if (ddlType.SelectedValue.Trim() == "Defect List")
                {
                    if (ddlPortfolio.SelectedValue == "Select" || ddlApplication.SelectedValue == "Select" || ddlCrDemandNo.SelectedValue == "Select")
                    {
                        msg.Append("Please select dropdown values before proceeding.");
                    }
                    else
                    {
                        msg.Append(string.Empty);
                    }
                }
                else
                {
                    if (ddlType.SelectedValue == "Select")
                    {
                        msg.Append("Please select dropdown values before proceeding.");
                    }

                }

            }
            catch (Exception ex) { }

            return msg.ToString();
        }

        #endregion

        #region Button : Click Events and Logout

        protected void btnView_Click(Object sender, EventArgs e)
        {
            grdDefectData.EditIndex = -1;
            grdEffortBulkUpload.EditIndex = -1;
            grdDefectData.PageIndex = 0;
            grdEffortBulkUpload.PageIndex = 0;
            string msg = ddlSelectionCheck();
            if (msg == string.Empty)
            {
                BindGrid(ddlType.SelectedValue.Trim());
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msg + "');</script>", false);
            }

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            grdDefectData.Visible = false;
            grdEffortBulkUpload.Visible = false;
            lblgridMsg.Visible = false;
            lblNodata.Visible = false;
            lblErrorMessage.Visible = false;
           // lblFileUpload.Visible = true;
          //  lblFileUpload.Text = upldEffortList.FileName;
            //divGrid.Visible = false;
            //Save the uploaded Excel file.
            string strFileType = System.IO.Path.GetExtension(upldEffortList.FileName).ToString().ToLower();
            BusinessClass bClass = new BusinessClass();






            if (strFileType != string.Empty)
            {
                if (strFileType != ".xls" && strFileType != ".xlsx")
                {
                    grdDefectData.Visible = false;
                    grdEffortBulkUpload.Visible = false;
                    divGrid.Visible = true;
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.Text = bulkUpldErrMsg;
                }

                else
                {
                    if (upldEffortList.FileName.Trim() == string.Empty)
                    {
                        grdEffortBulkUpload.Visible = false;
                        grdDefectData.Visible = false;
                        lblErrorMessage.Text = bulkUpldErrMsg;
                    }
                    else
                    {
                        string filePath = TempFolderForAddEdit + Path.GetFileName(upldEffortList.PostedFile.FileName);// Server.MapPath(TempFolderForAddEdit) + Path.GetFileName(upldEffortList.PostedFile.FileName);
                        upldEffortList.SaveAs(filePath);

                        //Open the Excel file in Read Mode using OpenXml.
                        using (SpreadsheetDocument doc = SpreadsheetDocument.Open(filePath, false))
                        {
                            //Read the first Sheet from Excel file.
                            Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();

                            //Get the Worksheet instance.
                            Worksheet worksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;

                            //Fetch all the rows present in the Worksheet.
                            IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Descendants<Row>();

                            //Create a new DataTable.
                            DataTable dt = new DataTable();

                            //Loop through the Worksheet rows.
                            foreach (Row row in rows)
                            {
                                //Use the first row to add columns to DataTable.
                                if (row.RowIndex.Value == 1)
                                {
                                    foreach (Cell cell in row.Descendants<Cell>())
                                    {
                                        string tempColName = GetValue(doc, cell);
                                        if (tempColName != string.Empty)
                                        {
                                            if (tempColName.Trim() == "Portfolio" || tempColName.Trim() == "Application" || tempColName.Trim() == "CR Demand No." || tempColName.Trim() == "BA Allocated Date" || tempColName.Trim() == "Construction Start Date" || tempColName == "BA Allocated" || tempColName == "SIT Efforts" || tempColName == "Security Testers" || tempColName == "Security Efforts" || tempColName == "BA Defects" || tempColName == "SIT Defects" || tempColName == "VF QA Defects" || tempColName == "Post Prod Defects" || tempColName == "UAT Defects" || tempColName == "Developers Allocated" || tempColName == "Go Live Date" || tempColName == "BA Efforts" || tempColName == "Developer Efforts" || tempColName == "SIT Testers")
                                            {
                                                dt.Columns.Add(tempColName);
                                            }
                                            else
                                            {
                                                lblErrorMessage.Visible = true;
                                                lblErrorMessage.Text = "File not in correct template.Please download template and try again.";
                                            }
                                        }
                                        else
                                        {
                                            lblErrorMessage.Visible = true;
                                            lblErrorMessage.Text = "File cannot be empty.Please download template and try again.";
                                            break;
                                        }
                                    }
                                    if (dt == null)
                                    {
                                        lblErrorMessage.Visible = true;
                                        lblErrorMessage.Text = "File cannot be empty.Please download template and try again.";
                                    }
                                    else
                                    {
                                        if (dt != null)
                                        {
                                            if (dt.Columns.Count == excelRowColCount)
                                            {
                                                string Portfolio = dt.Columns[0].ToString() != null && dt.Columns[0].ToString() != string.Empty ? dt.Columns[0].ToString() : string.Empty;
                                                string Application = dt.Columns[1].ToString() != null && dt.Columns[1].ToString() != string.Empty ? dt.Columns[1].ToString() : string.Empty;
                                                string crdmno = dt.Columns[2].ToString() != null && dt.Columns[2].ToString() != string.Empty ? dt.Columns[2].ToString() : string.Empty;
                                                string baAlloDate = dt.Columns[3].ToString() != null && dt.Columns[3].ToString() != string.Empty ? dt.Columns[3].ToString() : string.Empty;
                                                string baAllo = dt.Columns[4].ToString() != null && dt.Columns[4].ToString() != string.Empty ? dt.Columns[4].ToString() : string.Empty;
                                                string baEfforts = dt.Columns[5].ToString() != null && dt.Columns[5].ToString() != string.Empty ? dt.Columns[5].ToString() : string.Empty;
                                                string consStartDate = dt.Columns[6].ToString() != null && dt.Columns[6].ToString() != string.Empty ? dt.Columns[6].ToString() : string.Empty;
                                                string devAllocated = dt.Columns[7].ToString() != null && dt.Columns[7].ToString() != string.Empty ? dt.Columns[7].ToString() : string.Empty;
                                                string devEfforts = dt.Columns[8].ToString() != null && dt.Columns[8].ToString() != string.Empty ? dt.Columns[8].ToString() : string.Empty;
                                                string sitTesters = dt.Columns[9].ToString() != null && dt.Columns[9].ToString() != string.Empty ? dt.Columns[9].ToString() : string.Empty;
                                                string sitEfforts = dt.Columns[10].ToString() != null && dt.Columns[10].ToString() != string.Empty ? dt.Columns[10].ToString() : string.Empty;
                                                string secTesters = dt.Columns[11].ToString() != null && dt.Columns[11].ToString() != string.Empty ? dt.Columns[11].ToString() : string.Empty;
                                                string secEfforts = dt.Columns[12].ToString() != null && dt.Columns[12].ToString() != string.Empty ? dt.Columns[12].ToString() : string.Empty;
                                                string baDefects = dt.Columns[13].ToString() != null && dt.Columns[13].ToString() != string.Empty ? dt.Columns[13].ToString() : string.Empty;
                                                string sitDefects = dt.Columns[14].ToString() != null && dt.Columns[14].ToString() != string.Empty ? dt.Columns[14].ToString() : string.Empty;
                                                string vFqADefects = dt.Columns[15].ToString() != null && dt.Columns[15].ToString() != string.Empty ? dt.Columns[15].ToString() : string.Empty;
                                                string uatDefects = dt.Columns[16].ToString() != null && dt.Columns[16].ToString() != string.Empty ? dt.Columns[16].ToString() : string.Empty;
                                                string postProdDefects = dt.Columns[17].ToString() != null && dt.Columns[17].ToString() != string.Empty ? dt.Columns[17].ToString() : string.Empty;
                                                string goLiveDate = dt.Columns[18].ToString() != null && dt.Columns[18].ToString() != string.Empty ? dt.Columns[18].ToString() : string.Empty;

                                                if (Portfolio == string.Empty && Application == string.Empty && crdmno == string.Empty && baAlloDate == string.Empty && baAllo == string.Empty && consStartDate == string.Empty && sitEfforts == string.Empty && secTesters == string.Empty && secEfforts == string.Empty && baDefects == string.Empty && sitDefects == string.Empty && vFqADefects == string.Empty && postProdDefects == string.Empty && uatDefects == string.Empty && devAllocated == string.Empty && goLiveDate == string.Empty && baEfforts == string.Empty && devEfforts == string.Empty && sitTesters == string.Empty)
                                                {
                                                    lblErrorMessage.Visible = true;
                                                    lblErrorMessage.Text = "File cannot be empty.Please download template and try again.";
                                                }
                                                else
                                                {

                                                    if (Portfolio == "Portfolio" && Application == "Application" && crdmno == "CR Demand No." && baAlloDate == "BA Allocated Date" && baAllo == "BA Allocated" && consStartDate == "Construction Start Date" && sitEfforts == "SIT Efforts" && secTesters == "Security Testers" && secEfforts == "Security Efforts" && baDefects == "BA Defects" && sitDefects == "SIT Defects" && vFqADefects == "VF QA Defects" && postProdDefects == "Post Prod Defects" && uatDefects == "UAT Defects" && devAllocated == "Developers Allocated" && goLiveDate == "Go Live Date" && baEfforts == "BA Efforts" && devEfforts == "Developer Efforts" && sitTesters == "SIT Testers")
                                                    {

                                                    }
                                                    else
                                                    {
                                                        lblErrorMessage.Visible = true;
                                                        lblErrorMessage.Text = "File not in correct template.Please download template and try again.";
                                                        break;

                                                    }
                                                }
                                            }
                                            else
                                            {
                                                lblErrorMessage.Visible = true;
                                                lblErrorMessage.Text = "Column Mismatch.Please download template and try again.";
                                                break;

                                            }
                                        }
                                        else
                                        {
                                            lblErrorMessage.Visible = true;
                                            lblErrorMessage.Text = "File cannot be empty.Please download template and try again.";
                                        }
                                    }
                                }
                                else
                                {
                                    //Add rows to DataTable.
                                    if (dt != null)
                                    {
                                        dt.Rows.Add();
                                        int i = 0;
                                        foreach (Cell cell in row.Descendants<Cell>())
                                        {
                                            // if (i == Convert.ToInt32(locBaAllocatedDate) || i == Convert.ToInt32(locConstructionStartDate) || i == Convert.ToInt32(locGoLiveDate))
                                            if (i <= 18)
                                            {
                                                if(i==0 || i==1)
                                                {
                                                    string TitleCased = GetValue(doc, cell);

                                                    TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                                                    TitleCased = textInfo.ToTitleCase(TitleCased.ToLower());
                                                    dt.Rows[dt.Rows.Count - 1][i] = TitleCased;
                                                }
                                                else if (i == 2)
                                                {
                                                    dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell).ToUpper();
                                                }
                                                else if (i == 3 || i == 6 || i == 18)
                                                {
                                                    dt.Rows[dt.Rows.Count - 1][i] = GetDateValue(doc, cell);
                                                }
                                                else
                                                {
                                                    dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell);
                                                }
                                                
                                                i++;
                                            }
                                            //else
                                            //{
                                            //   // break;
                                            //}
                                        }
                                    }
                                }
                            }

                            if (dt != null)
                            {
                                if (dt.Columns.Count == excelRowColCount)
                                {
                                    if (dt.Rows.Count > 0)
                                    {
                                        if (dt.Rows.Count <= 50)
                                        {
                                            StringBuilder err = bClass.validateEffortList(dt, portfolioId);
                                            string errString = err.ToString();

                                            if (errString == string.Empty)
                                            {
                                                fileUploaded = bClass.insertBulkUploadDataToEfortList(dt);


                                                if (fileUploaded == 1)
                                                {
                                                    divGrid.Visible = true;
                                                    grdDefectData.Visible = false;
                                                    grdEffortBulkUpload.Visible = false;
                                                    lblErrorMessage.Visible = true;
                                                    lblErrorMessage.Text = successMsg;
                                                }
                                                else
                                                {
                                                    divGrid.Visible = true;
                                                    grdDefectData.Visible = false;
                                                    grdEffortBulkUpload.Visible = false;
                                                    lblErrorMessage.Visible = true;
                                                    lblErrorMessage.Text = errorMsg;
                                                }
                                            }
                                            else
                                            {
                                                divGrid.Visible = true;
                                                grdDefectData.Visible = false;
                                                grdEffortBulkUpload.Visible = false;
                                                lblErrorMessage.Visible = true;
                                                lblErrorMessage.Text = errString;
                                            }
                                        }
                                        else
                                        {

                                            lblErrorMessage.Visible = true;
                                            lblErrorMessage.Text = "The file cannot have more than 50 rows";
                                            //break;
                                        }
                                    }
                                    else
                                    {
                                        lblErrorMessage.Visible = true;
                                        lblErrorMessage.Text = "The file cannot be empty.Please enter data and upload again.";
                                    }
                                }
                                else
                                {
                                    lblErrorMessage.Visible = true;
                                    lblErrorMessage.Text = "Column count mismatch.Please enter data and upload again.";

                                }
                            }



                        }
                        //Delete file from temp folder:-
                        FileInfo file = new FileInfo(filePath);
                        if (file.Exists)
                        {
                            file.Delete();
                        }
                    }
                   // lblFileUpload.Visible = false;
                }
            }
            else
            {
                grdDefectData.Visible = false;
                grdEffortBulkUpload.Visible = false;
                divGrid.Visible = true;
                lblErrorMessage.Visible = true;
                lblErrorMessage.Text = "Please select a file to upload.";
            }
        }

        protected void imgbtnLogOut_Click(Object sender, EventArgs e)
        {
            Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/LogOut.aspx");
        }

        #endregion

        #region Grid : Bind and Grid Functions

        protected void BindGrid(string type)
        {
            if (type == "Effort List")
            {
                divGrid.Visible = true;
                grdDefectData.Visible = false;
                lblNodata.Visible = false;
                lblgridMsg.Visible = true;
                lblgridMsg.Text = "Note : *All fields are mandatory.Please fill NA (for text inputs) and 0 (for number and decimal inputs).";
                //Fetch Data and populate Effort Grid:-
                DataTable dtGridExcelData = new DataTable();
                dtGridExcelData = bClass.fetchDataforBulkUploadGrid(ddlPortfolio.SelectedValue.Trim(), ddlApplication.SelectedValue.Trim());



                if (dtGridExcelData != null)
                {
                    if (dtGridExcelData.Rows.Count > 0)
                    {
                        lblErrorMessage.Visible = false;
                        lblNodata.Visible = false;
                        grdEffortBulkUpload.Visible = true;
                        grdEffortBulkUpload.DataSource = dtGridExcelData;
                        grdEffortBulkUpload.DataBind();

                    }
                    else
                    {
                        lblgridMsg.Visible = false;
                        msgBox.Visible = true;
                        lblNodata.Visible = true;
                        lblErrorMessage.Visible = false;
                        grdEffortBulkUpload.Visible = false;

                    }
                }
                else
                {
                    lblgridMsg.Visible = false;
                    msgBox.Visible = true;
                    lblNodata.Visible = true;
                    lblErrorMessage.Visible = false;
                    grdEffortBulkUpload.Visible = false;

                }

            }

            else if (type == "Defect List")
            {
                divGrid.Visible = true;
                grdEffortBulkUpload.Visible = false;
                //Fetch Data and populate Defect Grid:-
                lblgridMsg.Visible = false;
                DataTable dtDefectData = new DataTable();
                dtDefectData = bClass.fetchDataforBulkUploadDefectGrid(ddlPortfolio.SelectedValue.Trim(), ddlApplication.SelectedValue.Trim(), ddlCrDemandNo.SelectedValue.Trim());
                if (dtDefectData != null)
                {
                    if (dtDefectData.Rows.Count > 0)
                    {
                        lblErrorMessage.Visible = false;
                        lblNodata.Visible = false;
                        grdDefectData.Visible = true;
                        grdDefectData.DataSource = dtDefectData;
                        grdDefectData.DataBind();

                    }
                    else
                    {
                        lblgridMsg.Visible = false;
                        lblNodata.Visible = true;
                        msgBox.Visible = true;
                        grdDefectData.Visible = false;

                    }
                }
                else
                {
                    lblgridMsg.Visible = false;
                    lblNodata.Visible = true;
                    msgBox.Visible = true;
                    grdDefectData.Visible = false;
                   
                }

            }
            else
            {
                //divGrid.Visible = false;
                grdEffortBulkUpload.Visible = false;
                grdDefectData.Visible = false;
                lblErrorMessage.Visible = false;
                lblgridMsg.Visible = false;
                msgBox.Visible = true;
                lblNodata.Visible = true;
            }

        }

        #region Grid Functions :Effort List Grid

        protected void grdEffortBulkUpload_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
            grdEffortBulkUpload.EditIndex = -1;
            BindGrid("Effort List");
        }

        protected void grdEffortBulkUpload_OnRowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            int count = 0;
            //Finding the controls from Gridview for the row which is going to update  
            Label id = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("lblID") as Label;

            Label crDemand = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("lblCRDemandNo") as Label;

            //    TextBox BAAllocatedDate = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtBAAllocatedDate") as TextBox;

            //   TextBox ConstructionStartDate = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtConstructionStartDate") as TextBox;

            TextBox BAAllocated = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtBAAllocated") as TextBox;

            TextBox SITEfforts = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtSITEfforts") as TextBox;

            TextBox SecurityTesters = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtSecurityTesters") as TextBox;

            TextBox SecurityEfforts = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtSecurityEfforts") as TextBox;

            //  TextBox TotalEfforts = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtTotalEfforts") as TextBox;

            TextBox BADefects = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtBADefects") as TextBox;

            TextBox SITDefects = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtSITDefects") as TextBox;

            TextBox VFQADefects = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtVFQADefects") as TextBox;

            TextBox PostProdDefects = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtPostProdDefects") as TextBox;

            TextBox UATDefects = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtUATDefects") as TextBox;

            // TextBox TotalDefects = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtTotalDefects") as TextBox;

            TextBox DeveloperAllocated = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtDeveloperAllocated") as TextBox;

            //   TextBox GoLiveDate = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtGoLiveDate") as TextBox;

            TextBox BAEfforts = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtBAEfforts") as TextBox;

            TextBox DeveloperEfforts = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtDeveloperEfforts") as TextBox;

            TextBox SITTesters = grdEffortBulkUpload.Rows[e.RowIndex].FindControl("txtSITTesters") as TextBox;

            if (SITTesters.Text.ToUpper() == "NA" && Convert.ToDouble(SITEfforts.Text) != 0.00)
            {
                string msgSIT = "SIT Efforts cannot be greater than 0 if SIT Testers is NA at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgSIT + "');</script>", false);
                count++;
            }
            else if (BAAllocated.Text.ToUpper() == "NA" && Convert.ToDouble(BAEfforts.Text) != 0.00)
            {
                string msgBA = "BA Efforts cannot be greater than 0 if BA Allocated is NA at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgBA + "');</script>", false);
                count++;
            }
            else if (DeveloperAllocated.Text.ToUpper() == "NA" && Convert.ToDouble(DeveloperEfforts.Text) != 0.00)
            {
                string msgDev = "Developer Efforts cannot be greater than 0 if Developers Allocated is NA at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgDev + "');</script>", false);
                count++;
            }
            else if (SecurityTesters.Text.ToUpper() == "NA" && Convert.ToDouble(SecurityEfforts.Text) != 0.00)
            {
                string msgSec = "Security Efforts cannot be greater than 0 if Security Testers is NA at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgSec + "');</script>", false);
                count++;
            }
            else if (BAEfforts.Text.Trim().Length > 5)
            {
                string msgBAEff = "BA Efforts cannot be greater than 9999 PDs at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgBAEff + "');</script>", false);
                count++;
            }
           if(BAEfforts.Text.Trim().Length <= 5)
            {
                if (Convert.ToDouble(BAEfforts.Text) > 9999.00)
            {
                string msgBAEff = "BA Efforts cannot be greater than 9999 PDs at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgBAEff + "');</script>", false);
                count++;
            }
            }
              if (DeveloperEfforts.Text.Trim().Length > 5)
            {
                string msgDevEff = "Developer Efforts cannot be greater than 9999 PDs at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgDevEff + "');</script>", false);
                count++;
            }
              if(DeveloperEfforts.Text.Trim().Length <= 5)
            {
             if (Convert.ToDouble(DeveloperEfforts.Text) > 9999.00)
            {
                string msgDevEff = "Developer Efforts cannot be greater than 9999 PDs at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgDevEff + "');</script>", false);
                count++;
            }
            }
             if (SecurityEfforts.Text.Trim().Length > 5)
            {
                string msgSecEff = "Security Efforts cannot be greater than 9999 PDs at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgSecEff + "');</script>", false);
                count++;
            }
             if(SecurityEfforts.Text.Trim().Length <= 5)
            {
             if (Convert.ToDouble(SecurityEfforts.Text) > 9999.00)
            {
                string msgSecEff = "Security Efforts cannot be greater than 9999 PDs at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgSecEff + "');</script>", false);
                count++;
            }
            }
            if (SITEfforts.Text.Trim().Length > 5)
            {
                string msgSITEff = "SIT Efforts cannot be greater than 9999 PDs at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgSITEff + "');</script>", false);
                count++;
            }
            if (SITEfforts.Text.Trim().Length <= 5)
            {
             if (Convert.ToDouble(SITEfforts.Text) > 9999.00)
            {
                string msgSITEff = "SIT Efforts cannot be greater than 9999 PDs at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgSITEff + "');</script>", false);
                count++;
            }
             }
             if (BADefects.Text.Trim().Length > 6)
            {
                string msgBADef = "BA defects cannot be greater than 99999 at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgBADef + "');</script>", false);
                count++;
            }
             if (BADefects.Text.Trim().Length <= 6)
            {
                if (Convert.ToInt32(BADefects.Text) > 99999)
                {
                    string msgBADef = "BA defects cannot be greater than 99999 at " + crDemand.Text + " .";
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgBADef + "');</script>", false);
                    count++;

                }
            }
             if (SITDefects.Text.Trim().Length > 6)
            {
                string msgSITDef = "SIT defects cannot be greater than 99999 at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgSITDef + "');</script>", false);
                count++;
            }
             if (SITDefects.Text.Trim().Length <= 6)
            {
                if (Convert.ToInt32(SITDefects.Text) > 99999)
                {
                    string msgSITDef = "SIT defects cannot be greater than 99999 at " + crDemand.Text + " .";
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgSITDef + "');</script>", false);
                    count++;
                }
            }
             if (VFQADefects.Text.Trim().Length > 6)
            {
                string msgVFQQADef = "VFQA defects cannot be greater than 99999 at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgVFQQADef + "');</script>", false);
                count++;
            }
             if (VFQADefects.Text.Trim().Length <= 6)
            {
            if (Convert.ToInt32(VFQADefects.Text) > 99999)
            {
                string msgVFQQADef = "VFQA defects cannot be greater than 99999 at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgVFQQADef + "');</script>", false);
                count++;
            }
            }
             if (UATDefects.Text.Trim().Length > 6)
            {
                string msgUATDef = "UAT defects cannot be greater than 99999 at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgUATDef + "');</script>", false);
                count++;
            }
            else if (UATDefects.Text.Trim().Length <= 6)
            {
                if (Convert.ToInt32(UATDefects.Text) > 99999)
                {
                    string msgUATDef = "UAT defects cannot be greater than 99999 at " + crDemand.Text + " .";
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgUATDef + "');</script>", false);
                    count++;
                }
            }
             if (UATDefects.Text.Trim().Length > 6)
            {
                string msgUATDef = "UAT defects cannot be greater than 99999 at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgUATDef + "');</script>", false);
                count++;
            }
             if (UATDefects.Text.Trim().Length <= 6)
            {
                if (Convert.ToInt32(UATDefects.Text) > 99999)
                {
                    string msgUATDef = "UAT defects cannot be greater than 99999 at " + crDemand.Text + " .";
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgUATDef + "');</script>", false);
                    count++;
                }
            }
            if (PostProdDefects.Text.Trim().Length > 6)
            {
                string msgPostProdDef = "Post Prod defects cannot be greater than 99999 at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgPostProdDef + "');</script>", false);
                count++;
            }
             if (PostProdDefects.Text.Trim().Length <= 6)
            {
             if (Convert.ToInt32(PostProdDefects.Text) > 99999)
            {
                string msgPostProdDef = "Post Prod defects cannot be greater than 99999 at " + crDemand.Text + " .";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + msgPostProdDef + "');</script>", false);
                count++;
            }
            }
            if(count==0)
            {
                int added = bClass.updateBulkUploadDataToEffortList(Convert.ToInt32(id.Text.Trim()), BAAllocated.Text.Trim(), SITEfforts.Text.Trim(), SecurityTesters.Text.Trim(), SecurityEfforts.Text.Trim(),
                BADefects.Text.Trim(), SITDefects.Text.Trim(), VFQADefects.Text, PostProdDefects.Text.Trim(), UATDefects.Text.Trim(), DeveloperAllocated.Text.Trim(), BAEfforts.Text.Trim(), DeveloperEfforts.Text.Trim(), SITTesters.Text.Trim());

                grdEffortBulkUpload.EditIndex = -1;
                BindGrid("Effort List");
            }
           // SetUpdateButtonId();
           
        }

        protected void grdEffortBulkUpload_OnRowEditing(object sender, GridViewEditEventArgs e)
        {
            grdEffortBulkUpload.EditIndex = e.NewEditIndex;
            BindGrid("Effort List");

            //grdEffortBulkUpload.Rows[e.NewEditIndex].Cells[1].Controls[0].Focus();
            grdEffortBulkUpload.Rows[e.NewEditIndex].FindControl("lblPortfolio").Focus();
          
        }

        protected void grdEffortBulkUpload_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label lblBAAllocatedDate = (Label)e.Row.FindControl("lblBAAllocatedDate");
                    DateTime timeBA = Convert.ToDateTime(lblBAAllocatedDate.Text);
                    lblBAAllocatedDate.Text = timeBA.ToString("d");


                    Label lblConstructionStartDate = (Label)e.Row.FindControl("lblConstructionStartDate");
                    DateTime timeConstruction = Convert.ToDateTime(lblConstructionStartDate.Text);
                    lblConstructionStartDate.Text = timeConstruction.ToString("d");



                    Label lblGoLiveDate = (Label)e.Row.FindControl("lblGoLiveDate");
                    DateTime timeGoLive = Convert.ToDateTime(lblGoLiveDate.Text);
                    lblGoLiveDate.Text = timeGoLive.ToString("d");


                    //Label baDefectCount = (Label)e.Row.FindControl("lblBADefects");
                    //BaDefects = Convert.ToInt32(baDefectCount.Text);

                    //Label sitDefectCount = (Label)e.Row.FindControl("lblSITDefects");
                    //sitDefects = Convert.ToInt32(sitDefectCount.Text);

                    //Label uatDefectCount = (Label)e.Row.FindControl("lblUATDefects");
                    //uatDefects = Convert.ToInt32(uatDefectCount.Text);

                    //Label vfqaDefectCount = (Label)e.Row.FindControl("lblVFQADefects");
                    //vfQaDefects = Convert.ToInt32(vfqaDefectCount.Text);

                    //Label postProdDefectCount = (Label)e.Row.FindControl("lblPostProdDefects");
                    //postProdDefects = Convert.ToInt32(postProdDefectCount.Text);




                    Label totalDefectCount = (Label)e.Row.FindControl("lblTotalDefects");

                    if (Convert.ToInt32(totalDefectCount.Text.ToString().Trim()) == 0)
                    {
                        LinkButton lnkbtn = (LinkButton)e.Row.FindControl("lnkDefectAnalysis");
                        lnkbtn.Enabled = false;
                        lnkbtn.Style.Add("color","gray");
                    }

                }
            }
            catch (Exception ex) { }
        }

        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdEffortBulkUpload.EditIndex = -1;
                grdEffortBulkUpload.PageIndex = e.NewPageIndex;
                this.BindGrid("Effort List");
            }
            catch (Exception ex) { }
        }

        protected void lnkDefectAnalysis_Click(Object sender, EventArgs e)
        {
            try
            {
                LinkButton lnkbtn = sender as LinkButton;
                GridViewRow row = (GridViewRow)lnkbtn.NamingContainer;
                Label lblID = (Label)row.FindControl("lblID");
                string rowId = lblID.Text;
                string url = SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/UploadDefectAnalysis.aspx?ID=" + rowId;// +"?BA=" + BaDefects + "?SIT=" + sitDefects + "?=UAT" + uatDefects + "?VFQA=" + vfQaDefects + "?POSTPROD=" + postProdDefects;
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>portal_modalDialogClosedCallback('Upload Defect Analysis','" + url + "')</script>", false);
            }
            catch (Exception ex) { }
        }

        //public void SetUpdateButtonId()
        //{
        //    if (grdEffortBulkUpload.EditIndex != -1)
        //    {
        //        Button updateButton = (Button)grdEffortBulkUpload.Rows[grdEffortBulkUpload.EditIndex].FindControl("btn_Update");
        //        if (updateButton != null)
        //        {
        //            Form.DefaultButton = updateButton.UniqueID;
        //        }
        //    }
        //    else
        //    {
        //        Form.DefaultButton = null;
        //    }
        //}

        #endregion

        #region Grid Functions :Defect List Grid

        protected void grdDefectData_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdDefectData.EditIndex = -1;
                grdDefectData.PageIndex = e.NewPageIndex;
                this.BindGrid("Defect List");
            }
            catch (Exception ex) { }
        }

        protected void grdDefectData_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
            grdDefectData.EditIndex = -1;
            BindGrid("Defect List");
        }

        protected void grdDefectData_OnRowEditing(object sender, GridViewEditEventArgs e)
        {
            grdDefectData.EditIndex = e.NewEditIndex;
            BindGrid("Defect List");
            grdDefectData.Rows[e.NewEditIndex].FindControl("lblIDDefect").Focus();
        }

        protected void grdDefectData_OnRowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            //Finding the controls from Gridview for the row which is going to update

            Label id = grdDefectData.Rows[e.RowIndex].FindControl("lblIDDefect") as Label;

            Label EffortListid = grdDefectData.Rows[e.RowIndex].FindControl("lblIDEffort") as Label;

            string Causal = (grdDefectData.Rows[e.RowIndex].FindControl("ddlCausalAnalysis") as DropDownList).SelectedValue;
            string Severity = (grdDefectData.Rows[e.RowIndex].FindControl("ddlSeverity") as DropDownList).SelectedValue;
            string Category = (grdDefectData.Rows[e.RowIndex].FindControl("ddlCategory") as DropDownList).SelectedValue;
            string Status = (grdDefectData.Rows[e.RowIndex].FindControl("ddlStatus") as DropDownList).SelectedValue;


            int added = bClass.updateBulkUploadDataToDefectList(Convert.ToInt32(id.Text.Trim()), Causal, Severity, Category, Status);
            if (added == 1)
            {
                bClass.changeEffortListOnDefectCategoryChange(ddlPortfolio.SelectedValue.Trim(), ddlApplication.SelectedValue.Trim(), ddlCrDemandNo.SelectedValue.Trim(), Convert.ToInt32(EffortListid.Text.Trim()));

            } 
            grdDefectData.EditIndex = -1;
            BindGrid("Defect List");
        }

        protected void grdDefectData_OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && grdDefectData.EditIndex == e.Row.RowIndex)
            {
                DropDownList ddlCausalAnalysis = (DropDownList)e.Row.FindControl("ddlCausalAnalysis");
                DropDownList ddlSeverity = (DropDownList)e.Row.FindControl("ddlSeverity");
                DropDownList ddlCategory = (DropDownList)e.Row.FindControl("ddlCategory");
                DropDownList ddlStatus = (DropDownList)e.Row.FindControl("ddlStatus");

                DataTable dtCausal = new DataTable();
                dtCausal = bClass.FetchCausalData();
                ddlCausalAnalysis.DataSource = dtCausal;
                ddlCausalAnalysis.DataTextField = "Value";
                ddlCausalAnalysis.DataValueField = "Value";
                ddlCausalAnalysis.DataBind();

                Label selectedCausal = e.Row.FindControl("lblCausalAnalysis") as Label;

                ddlCausalAnalysis.Items.FindByValue(selectedCausal.Text).Selected = true;

                DataTable dtSeverity = new DataTable();
                dtSeverity = bClass.FetchSeverityData();
                ddlSeverity.DataSource = dtSeverity;
                ddlSeverity.DataTextField = "Value";
                ddlSeverity.DataValueField = "Value";
                ddlSeverity.DataBind();

                Label selectedSeverity = e.Row.FindControl("lblSeverity") as Label;
                ddlSeverity.Items.FindByValue(selectedSeverity.Text).Selected = true;

                DataTable dtCategory = new DataTable();
                dtCategory = bClass.FetchCategoryData();
                ddlCategory.DataSource = dtCategory;
                ddlCategory.DataTextField = "Value";
                ddlCategory.DataValueField = "Value";
                ddlCategory.DataBind();

                Label selectedCategory = e.Row.FindControl("lblCategory") as Label;
                ddlCategory.Items.FindByValue(selectedCategory.Text).Selected = true;

                DataTable dtStatus = new DataTable();
                dtStatus = bClass.FetchStatusData();
                ddlStatus.DataSource = dtStatus;
                ddlStatus.DataTextField = "Value";
                ddlStatus.DataValueField = "Value";
                ddlStatus.DataBind();

                Label selectedStatus = e.Row.FindControl("lblStatus") as Label;
                ddlStatus.Items.FindByValue(selectedStatus.Text).Selected = true;
            }
        }

        protected void grdDefectData_OnRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label id = grdDefectData.Rows[e.RowIndex].FindControl("lblIDDefect") as Label;
            Label EffortListid = grdDefectData.Rows[e.RowIndex].FindControl("lblIDEffort") as Label;

            
              
            int deleted = bClass.deleteDefectGrid(Convert.ToInt32(id.Text));
            BindGrid("Defect List");
            if (deleted == 1)
            {
                bClass.changeEffortListOnDefectCategoryChange(ddlPortfolio.SelectedValue.Trim(), ddlApplication.SelectedValue.Trim(), ddlCrDemandNo.SelectedValue.Trim(), Convert.ToInt32(EffortListid.Text.Trim()));

            }
             
        }
           
        #endregion


        #endregion

        #region File Upload and Read

        private string GetValue(SpreadsheetDocument doc, Cell cell)
        {
            string value = string.Empty;

            if (cell != null)
            {
                if (cell.CellValue != null)
                {
                    if (cell.CellValue.InnerText != string.Empty)
                    {
                        value = cell.CellValue.InnerText;

                        string cellType = cell.DataType;

                        if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
                        {
                            return doc.WorkbookPart.SharedStringTablePart.SharedStringTable.ChildElements.GetItem(int.Parse(value)).InnerText;
                        }

                    }
                }
            }

            return value;
        }

        private string GetDateValue(SpreadsheetDocument doc, Cell cell)
        {
            string value = string.Empty;
            string regexDate = "^(?:0?[1-9]|1[0-2])[./-](?:[012]?[0-9]|3[01])[./-](?:[0-9]{2}){1,2}$";
            string convertedTime = string.Empty;
            if(cell != null)
            {
            if (cell.CellValue != null)
            {

                value = cell.CellValue.InnerText;

                if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
                {
                    string notDateValue =  doc.WorkbookPart.SharedStringTablePart.SharedStringTable.ChildElements.GetItem(int.Parse(value)).InnerText;

                    if (Regex.IsMatch(notDateValue,regexDate) == false)
                    {
                        convertedTime = "abc"; 
                    }
                }
                else if (value != null && value != string.Empty)
                {
                    convertedTime = DateTime.FromOADate(Convert.ToDouble(value)).ToString();
                }
                //else
                //{
                //    convertedTime = value;
                //}
               // else //(cell.CellValue.InnerText != string.Empty)
              //  {
                  //  

                   
                       
                        
                        //if ((DateTime.Parse(value).ToString("MM/dd/yyyy")))
                        //{ }
                        //if (Regex.IsMatch(value, regexDate))
                        //{

                          
                        //}
                       

                     
                    //else
                    //{
                    //    convertedTime = value;
                    //}
                  
               // }
            }
        }
            return convertedTime;
        }

        #endregion



        //protected void btnUpload_Click(object sender,EventArgs e)
        //{
        //    HttpPostedFile FileToUpload;
        //    DataTable dt = null;
        //    string fileName = string.Empty;

        //    if (upldEffortList.HasFile)
        //    {
        //        {
        //            try
        //            {
        //                FileToUpload = upldEffortList.PostedFile;
        //                string strFileType = System.IO.Path.GetExtension(FileToUpload.FileName).ToString().ToLower();
        //                string strDirPath = TempFolderForAddEdit;

        //                if (strFileType != ".xls" && strFileType != ".xlsx")
        //                {

        //                    if (FileToUpload.FileName.Trim() != string.Empty)
        //                    {

        //                        lblErrorMessage.Text = bulkUpldErrMsg;
        //                    }
        //                    else
        //                    {
        //                        if (!Directory.Exists(strDirPath))
        //                        {
        //                            DirectoryInfo di = Directory.CreateDirectory(strDirPath);
        //                        }

        //                        string strSep = "\\";
        //                        char[] chrSep = strSep.ToCharArray();
        //                        string[] strFileName1 = FileToUpload.FileName.Split(chrSep);
        //                        int Cnt = strFileName1.GetLength(0) - 1;

        //                       m fileName = strDirPath + strFileName1[strFileName1.Length - 1];
        //                        if (FileToUpload.FileName.Trim() != string.Empty)
        //                            FileToUpload.SaveAs(fileName);



        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {

        //            }
        //        }

        //    }
        //}

    }
}
