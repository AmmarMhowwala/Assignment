﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
    public static class Constant
    {
        public static string[] typeOfDefects = { "BA Defects", "SIT Defects", "UAT Defects", "VF-QA Defects", "POST PROD Defects" };
        public static string[] causalAnalysis = {"Inadequate Input","Inadequate Skill","Inadequate Training","Inadequate Documentation","Inadequate Communication","Inapplicable/Inappropriate Method/Process","Inadequacy Of Tool",
                                                 "Inherited defects","Reviewers Misunderstanding/Rejected","Inadequate Environment/Infrastructure","Inadequate Planning","Inappropriate use of Dp Checklist","Inappropriate Use Of Standards",
                                                 "Lack of Business/Application Knowledge","Inadequate Test Plan/Cases","Inadequate Checklist","Inadequate Self Review","Inadequate Verification Of Csp Or Reusable Components" };

        
















    }
}
