﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.Data;
using System.Web;

namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
    public partial class HomePage : LayoutsPageBase
    {

        string userRole = string.Empty;
        string userName = string.Empty;
        DataTable userSession = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["DefectCausalData"] = null;
            Session["TotalEfforts"] = null;
            Session["ApplicationEfforts"]= null;
            Session["RoleWiseEfforts"] = null;
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();
           
            if (Session["UserDetails"] == null)
            {
                Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/ErrorPage.aspx");
            }
           if(!IsPostBack)
           {
               Session["DefectCausalData"] = null;
               if (Session["UserDetails"] != null)
               {
                   userSession = (DataTable)Session["UserDetails"];
                   if (userSession != null)
                   {
                       if (userSession.Rows.Count > 0)
                       {
                           userRole = userSession.Rows[0]["Role"].ToString();
                           userName = userSession.Rows[0]["Name"].ToString();
                           lblloggedInUser.Text ="Welcome," + userName + " | " + userRole;
                       }
                   }
                 
                     
               }
           }

           RolewiseVisibility();
        }


        protected void RolewiseVisibility()
        {
            if (userRole == "Admin")
            {
                divBulkUpload.Visible = true;
                divDefectTracker.Visible = true;
                divDemandTracker.Visible = true;
                divEffortManagement.Visible = true;
            }
            else if (userRole == "Non Admin")
            {

                divDefectTracker.Visible = true;
                divDemandTracker.Visible = true;
                divEffortManagement.Visible = true;
                divBulkUpload.Visible = false;
            }
            else
            {
                divDefectTracker.Visible = false;
                divDemandTracker.Visible = false;
                divEffortManagement.Visible = false;
                divBulkUpload.Visible = false;
            
            }
        
        }


        protected void imgbtnLogOut_Click(Object sender, EventArgs e)
        {
            Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/LogOut.aspx");
        }
    }
}
