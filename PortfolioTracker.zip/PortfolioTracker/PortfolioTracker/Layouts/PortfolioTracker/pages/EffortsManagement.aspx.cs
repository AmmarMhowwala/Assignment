﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Data;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web;
using System.Text;
using System.Web.Services;
using System.Web.UI;


namespace PortfolioTracker.Layouts.PortfolioTracker.pages
{
   
    public partial class EffortsManagement : LayoutsPageBase
    {
        string userRole = string.Empty;
        string userName = string.Empty;
        DataTable userSession = new DataTable();
        BusinessClass userstore = new BusinessClass();
        static string portfolioNew = string.Empty;
        static string year = string.Empty;
        static List<ListItem> selected = new List<ListItem>();
        string portfolioId = string.Empty;
        static string CurrentPage = string.Empty;
        static string drillDownCategory = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (Session["UserDetails"] == null)
            {
                Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/ErrorPage.aspx");
            }
            if (!IsPostBack)
            {
                if (Session["UserDetails"] != null)
                {
                    userSession = (DataTable)Session["UserDetails"];
                    if (userSession != null)
                    {
                        if (userSession.Rows.Count > 0)
                        {
                            userRole = userSession.Rows[0]["Role"].ToString();
                            userName = userSession.Rows[0]["Name"].ToString();
                            portfolioId = userSession.Rows[0]["Title"].ToString();

                            lblloggedInUser.Text = "Welcome," + userName + " | " + userRole;
                        }
                    }
                    ShowEffortsData();
                    btnGetInfo.Visible = false;
                }

                //if (Session["TotalEfforts"] != null)
                //{
                //    string result = Session["TotalEfforts"].ToString();

                //    if (result != string.Empty)
                //    {
                //        ClientScript.RegisterHiddenField("TotalEfforts", result);
                //    }
                //}

                //if (Session["ApplicationEfforts"] != null)
                //{
                //    string result = Session["ApplicationEfforts"].ToString();

                //    if (result != string.Empty)
                //    {
                //        ClientScript.RegisterHiddenField("ApplicationEfforts", result);
                //    }
                //}
                //if (Session["RoleWiseEfforts"] != null)
                //{
                //    string result = Session["RoleWiseEfforts"].ToString();

                //    if (result != string.Empty)
                //    {
                //        ClientScript.RegisterHiddenField("RoleWiseEfforts", result);
                //    }
                //}


                lblQuarter.Visible = false;
                //Session["PortfolioID"] = "1";
                //if (Session["PortfolioID"] != null)
                //{
                //    portfolioId = Session["PortfolioID"].ToString();
                //}

            }
            
        }
        protected void ShowEffortsData()
        {
            BindPortfolioData();
            BindYearDropdown();
           
        }

        protected void BindYearDropdown()
        {
            btnGetInfo.Visible = false;
            grdEfforts.Visible = false;
            CurrentPage = string.Empty;
            drillDownCategory = string.Empty;
            ddlYear.Items.Clear();
            ddlYear.Items.Add("Select");
            Int32 currentYear = Convert.ToInt32(DateTime.Now.Year.ToString());
            int count = 5;
            while (count > 0)
            {
                ddlYear.Items.Add(new ListItem(currentYear.ToString()));
                currentYear--;
                count--;
            }
            //if(ddlYear.SelectedIndex.ToString()!="Select")
        }

        protected void BindQuarterDropdown(object sender, EventArgs e)
        {
            Session["DefectCausalData"] = null;
            CurrentPage = string.Empty;
            drillDownCategory = string.Empty;
            cblQuarter.Items.Clear();
            btnGetInfo.Visible = false;
            grdEfforts.Visible = false;
            lblQuarter.Visible = false;
            if (ddlYear.SelectedValue.ToString() != "Select")
            {
                cblQuarter.Visible = true;
                lblQuarter.Visible = true;
                cblQuarter.Items.Add(new ListItem("Q1"));
                cblQuarter.Items.Add(new ListItem("Q2"));
                cblQuarter.Items.Add(new ListItem("Q3"));
                cblQuarter.Items.Add(new ListItem("Q4"));
            }

        }

        protected void PortfolioChange(object sender, EventArgs e)
        {
            Session["DefectCausalData"] = null;
            CurrentPage = string.Empty;
            drillDownCategory = string.Empty;
            btnGetInfo.Visible = false;
            grdEfforts.Visible = false;
            ddlYear.SelectedIndex = 0;
            cblQuarter.Visible = false;
            lblQuarter.Visible = false;
            BindApplicationData(ddlPortfolio.SelectedValue.ToString());
            FetchAllDemands();
            

        }

        protected void QuartersReset(object sender, EventArgs e)
        {
            Session["DefectCausalData"] = null;
            btnGetInfo.Visible = false;
            grdEfforts.Visible = false;
            CurrentPage = string.Empty;
            drillDownCategory = string.Empty;

        }


        protected void btn_EffortsData_Click(Object sender, EventArgs e)
        {
            selected.Clear();
            CurrentPage = string.Empty;
            drillDownCategory = string.Empty;
            //lblErrorMsg.Visible = false;
            year=ddlYear.SelectedValue.ToString();
            grdEfforts.Visible = false;
            grdEfforts = null;
           
            if (HttpContext.Current.Request.HttpMethod == "POST")
            {
                bool valid = ValidateInfo();
                
                foreach (ListItem item in cblQuarter.Items)
                    if (item.Selected) selected.Add(item);

                if (valid == true)
                {

                    string values = FetchAllEffortsforAPortfolio(ddlPortfolio.SelectedValue.ToString(), ddlApplication.SelectedValue.ToString(), ddlDemandCR.SelectedValue.ToString(),ddlYear.SelectedValue.ToString(),selected);
                    if (ddlApplication.SelectedValue.ToString() == "All")
                   {
                        if (ddlDemandCR.SelectedValue.ToString() == "All")
                        {
                    //        string values = FetchAllEffortsforAPortfolio(ddlPortfolio.SelectedValue.ToString());
                            Session["TotalEfforts"] = values;
                            ClientScript.RegisterHiddenField("TotalEfforts", values);
                           
                        }

                    }
                    else if (ddlApplication.SelectedValue.ToString() != "All")
                    {
                        if (ddlDemandCR.SelectedValue.ToString() == "All")
                        {
                    //        string values = FetchEffortsApplicationWise(ddlPortfolio.SelectedValue.ToString(), ddlApplication.SelectedValue.ToString());
                            Session["ApplicationEfforts"] = values;
                            ClientScript.RegisterHiddenField("ApplicationEfforts", values);
                            ClientScript.RegisterHiddenField("ApplicationName", ddlApplication.SelectedValue.ToString());
                            
                        }

                            else
                            {
                    //            string values = FetchEffortsRoleWise(ddlPortfolio.SelectedValue.ToString(), ddlApplication.SelectedValue.ToString(), ddlDemandCR.SelectedValue.ToString());
                                Session["RoleWiseEfforts"] = values;
                                ClientScript.RegisterHiddenField("RoleWiseEfforts", values);
                                ClientScript.RegisterHiddenField("CRDemandNo", ddlDemandCR.SelectedValue.ToString());
                              
                            }
                        }
                    if (values == "null")
                        btnGetInfo.Visible = false;
                    else
                    btnGetInfo.Visible = true;
                    }
                }
            
            //lblErrorMsg.Visible = true;
        }

        protected bool ValidateInfo()
        {
            bool valid = true;
            StringBuilder sbErrorMessages = new StringBuilder();
            if (ddlPortfolio.SelectedValue == "Select"|| ddlApplication.SelectedValue == "Select" || ddlDemandCR.SelectedValue.ToString() == "Select" || ddlYear.SelectedValue.ToString()=="Select")
                sbErrorMessages.Append ("Please select dropdown values before proceeding.");

           //lblErrorMsg.Text = sbErrorMessages.ToString();
           // lblErrorMsg.CssClass = "error";
           //.Visible = false;
            //if(lblErrorMsg.Text!="")
                // valid=false;
            if (sbErrorMessages.ToString() != "")
                valid = false;
           if(valid==false)
               ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "err", "<script type='text/javascript'>alert('" + sbErrorMessages + "');</script>", false);
            return valid;

        }

        protected void imgbtnLogOut_Click(Object sender, EventArgs e)
        {
            Response.Redirect(SPContext.Current.Web.Url + @"/_layouts/PortfolioTracker/Pages/LogOut.aspx");
        }


        protected void ApplicationChange(Object sender, EventArgs e)
        {
            Session["DefectCausalData"] = null;
            btnGetInfo.Visible = false;
            grdEfforts.Visible = false;
            FetchDemandsByApplication();
            ddlYear.SelectedIndex = 0;
            ddlDemandCR.SelectedIndex = 0;//check
            cblQuarter.Visible = false;
            lblQuarter.Visible = false;
            CurrentPage = string.Empty;
            drillDownCategory = string.Empty;
        }
        protected void DemandCRChange(Object sender, EventArgs e)
        {
            Session["DefectCausalData"] = null;
            btnGetInfo.Visible = false;
            grdEfforts.Visible = false;
            ddlYear.SelectedIndex = 0;
            cblQuarter.Visible = false;
            lblQuarter.Visible = false;
            CurrentPage = string.Empty;
            drillDownCategory = string.Empty;
            if (ddlApplication.SelectedValue.ToString() != "All" && ddlDemandCR.SelectedValue.ToString() != "All")
            {
                ddlYear.Enabled = false;
                cblQuarter.Enabled = false;
               // lblYear.Visible = false;
               // lblQuarter.Visible = false;
                
            }
            else
            {
                ddlYear.Enabled = true;
                cblQuarter.Enabled = true;
               // lblYear.Visible = true;
              //  lblQuarter.Visible = true;
            }

        }

        protected void BindPortfolioData()
        {

            DataTable portfolioOptions = userstore.FetchPortfolioData(portfolioId);
            ddlPortfolio.Items.Clear();
            ddlPortfolio.Items.Add("Select");
            ddlApplication.Items.Add("Select");
            ddlDemandCR.Items.Add("Select");
            ddlApplication.SelectedIndex = 0;
            ddlDemandCR.SelectedIndex = 0;
            ddlYear.SelectedIndex = 0;

            if (ddlPortfolio != null)
            {
                if (portfolioOptions.Rows.Count > 0)
                {
                    foreach (DataRow dr in portfolioOptions.Rows)
                    {
                        ddlPortfolio.Items.Add(new ListItem(dr[0].ToString()));

                    }

                    ddlPortfolio.SelectedIndex = 0;
                }
            }
        }

        protected void BindApplicationData(string Portfolio)
        {
            try
            {
                ddlApplication.Items.Clear();
                ddlApplication.Items.Add("Select");
                if (Portfolio != "Select")
                {
                DataTable applicationOptions = userstore.FetchApplicationData(ddlPortfolio.SelectedValue.ToString());
                
                
                    if (ddlApplication != null)
                    {
                        ddlApplication.Items.Add("All");
                        if (applicationOptions.Rows.Count > 0)
                        {
                            foreach (DataRow dr in applicationOptions.Rows)
                            {
                                ddlApplication.Items.Add(new ListItem(dr[0].ToString()));

                            }

                            ddlApplication.SelectedIndex = 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            { }
        }


        protected void FetchAllDemands()
        {
           // DataTable allDemands = userstore.FetchAllDemandsData(ddlPortfolio.SelectedValue.ToString());
            ddlDemandCR.Items.Clear();
            ddlDemandCR.Items.Add("Select");
           // ddlDemandCR.Items.Add("All");
            //try
            //{
            //    if (ddlDemandCR != null)
            //    {
            //        if (allDemands.Rows.Count > 0)
            //        {
            //            foreach (DataRow dr in allDemands.Rows)
            //            {
            //                ddlDemandCR.Items.Add(new ListItem(dr[0].ToString()));

            //            }

                      ddlDemandCR.SelectedIndex = 0;
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //}
        }

        protected void FetchDemandsByApplication()
        {
           
            ddlDemandCR.Items.Clear();
            ddlDemandCR.Items.Add("Select");
            DataTable DemandsByApplications = userstore.FetchDemandsByApplication(ddlApplication.SelectedValue.ToString());
            try
            {
                if (ddlApplication.SelectedValue.ToString() != "Select")
                {
                    if (ddlDemandCR != null)
                    {
                        ddlDemandCR.Items.Add("All");
                        if (DemandsByApplications.Rows.Count > 0)
                        {
                            foreach (DataRow dr in DemandsByApplications.Rows)
                            {
                                ddlDemandCR.Items.Add(new ListItem(dr[0].ToString()));

                            }

                            ddlDemandCR.SelectedIndex = 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        protected string FetchAllEffortsforAPortfolio(string Portfolio,string Application, string demandCR,string year,List<ListItem> selected)
        {
            int count=0;
            DataTable allEffortsData = userstore.fetchAllEffortsPortWise(Portfolio, Application, demandCR, year, selected);
            DataTable allEfforts = new DataTable();
            string values = string.Empty;
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            try
            {
                if (Application == "All" && demandCR == "All")
                {
                   
                     portfolioNew=ddlPortfolio.SelectedValue.ToString();
                    if(allEffortsData!=null)
                    {
                        if (allEffortsData.Rows.Count > 0)
                        {
                            DataView view = new DataView(allEffortsData);
                            allEfforts = view.ToTable(true, "Application");
                            allEfforts.Columns.Add("TotalEfforts");
                            allEfforts.Columns.Add("DrillDown");
                            foreach (DataRow dr in allEfforts.Rows)
                            {
                                double effortsCount = 0;
                                foreach (DataRow dr1 in allEffortsData.Rows)
                                {
                                    if (dr1["Application"].ToString() == dr["Application"].ToString())
                                        effortsCount += Convert.ToDouble(dr1["TotalEfforts"]);
                                }
                                dr["TotalEfforts"] = effortsCount;
                                dr["DrillDown"] = dr["Application"].ToString();
                            }






                            Dictionary<string, object> row;
                            foreach (DataRow dr in allEfforts.Rows)
                            {
                                row = new Dictionary<string, object>();
                                foreach (DataColumn col in allEfforts.Columns)
                                {
                                    row.Add(col.ColumnName, dr[col]);
                                }
                                rows.Add(row);
                            }


                        }
                    }

                    else
                        rows = null;
                }
                else if (Application != "All" && demandCR == "All")
                {
                  


                    if(allEffortsData!=null)
                    {
                        if (allEffortsData.Rows.Count > 0)
                        {
                            foreach (DataRow dr1 in allEffortsData.Rows)
                            {
                                if (dr1["TotalEfforts"].ToString() != "0")
                                {
                                    count++;
                                }
                            }
                                    Dictionary<string, object> row;
                                    foreach (DataRow dr in allEffortsData.Rows)
                                    {

                                        row = new Dictionary<string, object>();
                                        foreach (DataColumn col in allEffortsData.Columns)
                                        {
                                            row.Add(col.ColumnName, dr[col]);
                                        }
                                        rows.Add(row);
                                    }

                                }
                            }
                            
                        
                    else
                        rows = null;
                    if (count == 0)
                        rows = null;
                   
                }

                else if (Application != "All" && demandCR != "All")
                {
                    ddlYear.Visible = false;
                    cblQuarter.Visible = false;
                    DataTable finalRoleEfforts = new DataTable();
                    int count1 = 0;
                    finalRoleEfforts.Columns.Add("Category");
                    finalRoleEfforts.Columns.Add("Efforts");
                    finalRoleEfforts.Rows.Add("BA Efforts");
                    finalRoleEfforts.Rows.Add("Developer Efforts");
                    finalRoleEfforts.Rows.Add("SIT Efforts");
                    finalRoleEfforts.Rows.Add("Security Efforts");

                    if (allEffortsData != null)
                    {
                        finalRoleEfforts.Rows[0]["Efforts"] = allEffortsData.Rows[0]["BAEfforts"];
                        finalRoleEfforts.Rows[1]["Efforts"] = allEffortsData.Rows[0]["DeveloperEfforts"];
                        finalRoleEfforts.Rows[2]["Efforts"] = allEffortsData.Rows[0]["SITEfforts"];
                        finalRoleEfforts.Rows[3]["Efforts"] = allEffortsData.Rows[0]["SecurityEfforts"];

                        

                        if (finalRoleEfforts != null)
                        {
                            if (finalRoleEfforts.Rows.Count > 0)
                            {
                                foreach (DataRow dr in finalRoleEfforts.Rows)
                                {
                                    if (dr["Efforts"].ToString() != "0")
                                        count1++;
                                }

                                Dictionary<string, object> row;
                                foreach (DataRow dr in finalRoleEfforts.Rows)
                                {
                                    row = new Dictionary<string, object>();
                                    foreach (DataColumn col in finalRoleEfforts.Columns)
                                    {
                                        row.Add(col.ColumnName, dr[col]);
                                    }
                                    rows.Add(row);
                                }

                            }


                        }
                    }
                    else
                        rows = null;
                    if (count1 == 0)
                        rows = null;

                }

            }
            catch (Exception ex)
            {
            }
            //return allEfforts;
            return serializer.Serialize(rows);

        }

        protected string FetchEffortsApplicationWise(string portfolio, string application)
        {
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            Dictionary<string, object> row;
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            try
            {

                DataTable appEfforts = userstore.fetchAllEffortsApplicationWise(portfolio, application);
                string values = string.Empty;


                if (appEfforts.Rows.Count > 0)
                {

                   
                    foreach (DataRow dr in appEfforts.Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (DataColumn col in appEfforts.Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                  


                }

            }
            catch (Exception ex)
            {
            }
            //return allEfforts;
            return serializer.Serialize(rows);
        }

        protected string FetchEffortsRoleWise(string portfolio, string application, string demandCr)
        {
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            Dictionary<string, object> row;
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            DataTable finalRoleEfforts = new DataTable();
            finalRoleEfforts.Columns.Add("Category");
            finalRoleEfforts.Columns.Add("Efforts");
            finalRoleEfforts.Rows.Add("BA Efforts");
            finalRoleEfforts.Rows.Add("Developer Efforts");
            finalRoleEfforts.Rows.Add("SIT Efforts");
            finalRoleEfforts.Rows.Add("Security Efforts");
            try
            {

                DataTable roleEfforts = userstore.fetchEffortsRoleWise(portfolio, application,demandCr);
                finalRoleEfforts.Rows[0]["Efforts"] = roleEfforts.Rows[0]["BAEfforts"];
                finalRoleEfforts.Rows[1]["Efforts"] = roleEfforts.Rows[0]["DeveloperEfforts"];
                finalRoleEfforts.Rows[2]["Efforts"] = roleEfforts.Rows[0]["SITEfforts"];
                finalRoleEfforts.Rows[3]["Efforts"] = roleEfforts.Rows[0]["SecurityEfforts"];
                

                string values = string.Empty;


                if (finalRoleEfforts.Rows.Count > 0)
                {

                   
                    foreach (DataRow dr in finalRoleEfforts.Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (DataColumn col in finalRoleEfforts.Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                   


                }

            }
            catch (Exception ex)
            {
            }
            return serializer.Serialize(rows);
        }

        [WebMethod]
        public static string GetDrillDownData1(string category)
        {

            //EffortsManagement efforts = new EffortsManagement();
            //efforts.grdEfforts.DataSource = null;
            //efforts.grdEfforts.DataBind();
            //grdEfforts.Visible = false;
            drillDownCategory = category;
            if (drillDownCategory != "DrillUpPage" && drillDownCategory != string.Empty)
            {
                CurrentPage = "DrillDownPage";
                BusinessClass userstore = new BusinessClass();

                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                Dictionary<string, object> row;
                List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                DataTable finalResourceWise = new DataTable();

                finalResourceWise.Columns.Add("Category");
                finalResourceWise.Columns.Add("TotalEfforts");
                finalResourceWise.Rows.Add("BA Efforts");
                finalResourceWise.Rows.Add("Developer Efforts");
                finalResourceWise.Rows.Add("SIT Efforts");
                finalResourceWise.Rows.Add("Security Efforts");
                finalResourceWise.Rows[0]["TotalEfforts"] = 0;
                finalResourceWise.Rows[1]["TotalEfforts"] = 0;
                finalResourceWise.Rows[2]["TotalEfforts"] = 0;
                finalResourceWise.Rows[3]["TotalEfforts"] = 0;
                //string values=string.Empty;
                try
                {

                    DataTable resourceWiseEfforts = userstore.FetchResourceWiseEffortsForApp(portfolioNew, category, year, selected);


                    if (resourceWiseEfforts.Rows.Count > 0)
                    {

                        foreach (DataRow dr1 in resourceWiseEfforts.Rows)
                        {

                            finalResourceWise.Rows[0]["TotalEfforts"] = Convert.ToInt32(finalResourceWise.Rows[0]["TotalEfforts"])+ Convert.ToInt32(dr1["BAEfforts"]);
                            finalResourceWise.Rows[1]["TotalEfforts"] =  Convert.ToInt32(finalResourceWise.Rows[1]["TotalEfforts"])+ Convert.ToInt32(dr1["DeveloperEfforts"]);
                            finalResourceWise.Rows[2]["TotalEfforts"] = Convert.ToInt32(finalResourceWise.Rows[2]["TotalEfforts"]) + Convert.ToInt32(dr1["SITEfforts"]);
                            finalResourceWise.Rows[3]["TotalEfforts"] = Convert.ToInt32(finalResourceWise.Rows[3]["TotalEfforts"]) + Convert.ToInt32(dr1["SecurityEfforts"]);
                        }
                            foreach (DataRow dr in finalResourceWise.Rows)
                            {
                                row = new Dictionary<string, object>();
                                foreach (DataColumn col in finalResourceWise.Columns)
                                {
                                    row.Add(col.ColumnName, dr[col]);
                                }
                                rows.Add(row);
                            }
                        }


                    }

                
                catch (Exception ex)
                {
                }



                //return allEfforts;
                return serializer.Serialize(rows);

            }
            else
            {
                CurrentPage = category;
                return string.Empty;
            }
            
        }

       


        #region Avinash: GridView Data Display

        protected void btnGetInfo_Click(Object sender, EventArgs e)
        {
            selected.Clear();
          
            if (HttpContext.Current.Request.HttpMethod == "POST")
            {

                grdEfforts.PageIndex = 0;
                bool valid = ValidateInfo();

                foreach (ListItem item in cblQuarter.Items)
                    if (item.Selected) selected.Add(item);

                if (valid == true)
                {

                    string values = FetchAllEffortsforAPortfolio(ddlPortfolio.SelectedValue.ToString(), ddlApplication.SelectedValue.ToString(), ddlDemandCR.SelectedValue.ToString(), ddlYear.SelectedValue.ToString(), selected);
                    if (ddlApplication.SelectedValue.ToString() == "All")
                    {
                        if (ddlDemandCR.SelectedValue.ToString() == "All")
                        {
                            //        string values = FetchAllEffortsforAPortfolio(ddlPortfolio.SelectedValue.ToString());
                            ClientScript.RegisterHiddenField("TotalEfforts", values);
                            //if (values == null)
                            //    btnGetInfo.Visible = false;
                        }

                    }
                    else if (ddlApplication.SelectedValue.ToString() != "All")
                    {
                        if (ddlDemandCR.SelectedValue.ToString() == "All")
                        {
                            //        string values = FetchEffortsApplicationWise(ddlPortfolio.SelectedValue.ToString(), ddlApplication.SelectedValue.ToString());
                            ClientScript.RegisterHiddenField("ApplicationEfforts", values);
                            ClientScript.RegisterHiddenField("ApplicationName", ddlApplication.SelectedValue.ToString());
                            //if (values == null)
                            //    btnGetInfo.Visible = false;
                        }

                        else
                        {
                            //            string values = FetchEffortsRoleWise(ddlPortfolio.SelectedValue.ToString(), ddlApplication.SelectedValue.ToString(), ddlDemandCR.SelectedValue.ToString());
                            ClientScript.RegisterHiddenField("RoleWiseEfforts", values);
                            ClientScript.RegisterHiddenField("CRDemandNo", ddlDemandCR.SelectedValue.ToString());
                            //if (values == null)
                            //    btnGetInfo.Visible = false;
                        }
                    }
                    btnGetInfo.Visible = true;
                }
            }
            GridDisplay();
        }

        protected void GridDisplay()
        {
           
                if (ddlApplication.SelectedValue.ToString() != "All")
                {
                    if (ddlDemandCR.SelectedValue.ToString() != "All")
                    {
                        drillDownCategory = string.Empty;
                        CurrentPage = string.Empty;
                    }
                } 
            
            BusinessClass bclass = new BusinessClass();
            DataTable dtGrid = bclass.fetchDataforGridView(ddlPortfolio.SelectedValue, ddlApplication.SelectedValue, ddlDemandCR.SelectedValue, ddlYear.SelectedValue.ToString(), selected,drillDownCategory,CurrentPage);
            grdEfforts.DataSource = dtGrid;
            grdEfforts.DataBind();
            grdEfforts.Visible = true;
           // drillDownCategory = string.Empty;
        }


        protected void grdEfforts_PageIndexChanging(Object sender, GridViewPageEventArgs e)
        {
            grdEfforts.PageIndex = e.NewPageIndex;
            GridDisplay();

        }

        protected void grdEfforts_RowDataBound(Object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {



                    Label lblBAAllocatedDate = (Label)e.Row.FindControl("lblBAAllocatedDate");
                    DateTime timeBA = Convert.ToDateTime(lblBAAllocatedDate.Text);
                    lblBAAllocatedDate.Text = timeBA.ToString("d");


                    Label lblConstructionStartDate = (Label)e.Row.FindControl("lblConstructionStartDate");
                    DateTime timeConstruction = Convert.ToDateTime(lblConstructionStartDate.Text);
                    lblConstructionStartDate.Text = timeConstruction.ToString("d");



                    Label lblGoLiveDate = (Label)e.Row.FindControl("lblGoLiveDate");
                    DateTime timeGoLive = Convert.ToDateTime(lblGoLiveDate.Text);
                    lblGoLiveDate.Text = timeGoLive.ToString("d");

                }
            }
            catch (Exception ex) { }
        }
        #endregion
    }
}
